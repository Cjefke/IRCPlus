dialog tankschat {
  title "Tanks - Enter a message."
  option dbu
  size -1 -1 160 20
  edit "", 2, 4 5 122 11, autohs result limit 200
  button "&Send", 3, 131 5 25 11, ok
  list 1,0 0 0 0,hidedisable
}
alias tankslist tanklist
alias -l O00OO00O {
  var %tanks.OO0O0OOO = 1
  while (1) {
    var %tanks.OOO0OO00 = tanks. $+ %tanks.OO0O0OOO
    if ($sock(%tanks.OOO0OO00)) || (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) inc %tanks.OO0O0OOO
    else break
  }
  if (%tanks.OO0O0OOO > %tanks.OO00OOO0) return 1
  if ($1 !isnum 0-4) tokenize 32 $rand(0,4)
  else %tanksskill = $1
  %tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] = $1
  O0OOO0O0 0 $1 %tanks.OO0O0OOO 0 Skill� $+ $1
}
alias -l O00O0000 {
  var %tanks.O0O0OOO0 = $mouse.x, %tanks.O0O00000 = $mouse.y
  drawtext -rbn @Tanks�request %tanks.0 $iif($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,16,24,39,15),%tanks.12,%tanks.2) Fixedsys 15 16 24 [Yes]
  drawtext -rbn @Tanks�request %tanks.0 $iif($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,64,24,31,15),%tanks.12,%tanks.2) Fixedsys 15 64 24 [No]
  drawdot @Tanks�request
}
alias -l O00OOOO0 {
  var %tanks.O0O0OOO0 = %tanks.OO000OO0
  if ($1) %tanks.O0O0OOO0 = $1
  %tanks.O0O0OOO0 = $int($calc(%tanks.OO0O0000 [ $+ [ %tanks.O0O0OOO0 ] ] /25))
  if (%tanks.O0O0OOO0 < 1) return 1
  if (%tanks.O0O0OOO0 > 5) return 5
  return %tanks.O0O0OOO0
}
on *:sockopen:tanksversion:{
  if ($sockerr) {
    OOO000OO Connection error $sockerr
    return
  }
  sockwrite -n $sockname GET /pdufilie/versions.txt HTTP/1.0
  sockwrite -n $sockname Accept: */*
  sockwrite -n $sockname Host: pages.cthome.net
  sockwrite -n $sockname
}
alias -l O0O0OOO0 {
  if (%tanks.OO000000) O0O0000O
  :0
  var %tanks.OO0O0OOO = %tanks.OO000OO0 + 1, %tanks.OO0000O0, %tanks.OOO00O0O
  while (%tanks.OO0O0OOO <= %tanks.OO00OOO0) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) %tanks.OO0000O0 = %tanks.OO0000O0 %tanks.OO0O0OOO
    inc %tanks.OO0O0OOO
  }
  %tanks.OO0O0OOO = 1
  while (%tanks.OO0O0OOO <= %tanks.OO00OOO0) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) %tanks.OOO00O0O = %tanks.OOO00O0O %tanks.OO0O0OOO
    inc %tanks.OO0O0OOO
  }
  %tanks.OO0000O0 = %tanks.OO0000O0 %tanks.OOO00O0O %tanks.OOO00O0O
  %tanks.OOO00O0O = 1
  while (%tanks.OOO00O0O <= $numtok(%tanks.OO0000O0,32)) {
    %tanks.OO0O0OOO = $gettok(%tanks.OO0000O0,%tanks.OOO00O0O,32)
    if (%tanks.OOO0O000 [ $+ [ %tanks.OO0O0OOO ] ] > 0) && (%tanks.OO0O0OOO != %tanks.OO000OO0) {
      %tanks.OO000OO0 = %tanks.OO0O0OOO
      break
    }
    if (%tanks.OO0O0OOO == %tanks.OO000OO0) {
      %tanks.OO000OO0 = $gettok(%tanks.OO0000O0,$calc(1+%tanks.OOO00O0O),32)
      break
    }
    inc %tanks.OOO00O0O
  }
  var %tanks.OOO0OO00 = tanks. $+ %tanks.OO000OO0
  if (* !iswm $sock(%tanks.OOO0OO00)) && (* !iswm $sock(tanks)) && (%tanks.O00O0O00 [ $+ [ %tanks.OO000OO0 ] ] == 5) %tanks.O00O0O0O = %tanks.OO000OO0
  if (%tanks.OOO0OOO0 > 1) %tanks.O00O0000 = %tanks.O00OOOOO
  OO0000OO 1
  OO00OO0O 1
  tokenize 32 %tanks.OO0O00O0
  var %tanks.OOO00O0O = 0
  while ($1) {
    if (%tanks.OOO0O000 [ $+ [ $1 ] ] > 0) inc %tanks.OOO00O0O
    tokenize 32 $2-
  }
  if (%tanks.OOO00O0O > 1) O0OOOO00
  if (%tanks.OOO00O0O < 2) || ($O0000OO0) {
    if ($O0000OO0 > 1) {
      OOOO00OO
      return
    }
    else {
      O0O0O000
      return
    }
  }
  if (%tankslvr) {
    var %tanks.OO0000OO = 0, %tanks.OOO0OO00 = 0
    tokenize 32 %tanks.OO0O00O0
    while ($1) {
      if (%tanks.OOO0O000 [ $+ [ $1 ] ] > 0) && ($1 != %tanks.OO000OO0) {
        inc %tanks.OOO0OO00
        if ($iif(%tanks.O0000O00 [ $+ [ $1 ] ] < $calc(%tankswidth /2),1,0) != $iif(%tanks.O0000O00 [ $+ [ %tanks.OO000OO0 ] ] < $calc(%tankswidth /2),1,0)) inc %tanks.OO0000OO
      }
      tokenize 32 $2-
    }
    if (%tanks.OO0000OO == 0) && (%tanks.OOO0OO00) {
      %tanks.OO0000OO = 1
      while (%tanks.OO0000OO <= %tanks.OO00OOO0) {
        if (%tanks.O00O0OOO [ $+ [ %tanks.OO0000OO ] ] isnum) && (%tanks.O00O0O00 [ $+ [ %tanks.OO0000OO ] ] isnum 0-4) && (%tanks.OOO0O000 [ $+ [ %tanks.OO0000OO ] ] > 0) && (%tanks.OO00OOOO [ $+ [ %tanks.OO0000OO ] ] != 1) {
          if ($O0OO000O(%tanks.OO0000OO,1)) return
        }
        inc %tanks.OO0000OO
      }
      if ($timer(tanks.OOO00O0O)) .timertanks.OOO00O0O -om 1 $rand(10275,10400) OOO00O0O
    }
  }
}
alias -l socket sockclose $1 | sockopen $1-2 80 | sockmark $1-2
alias tanklist {
  if ($dialog(tanklist)) dialog -x tanklist
  dialog $iif(%tanksontop,-dmo,-dm) tanklist tanklist
}
on *:sockwrite:tanks.*.*:.timer -o 1 15 sockclose $sockname
alias -l OO0OOOOO {
  var %tanks.O00O00OO = 0
  if ($1 isnum) {
    %tanks.O00O00OO = $1
    tokenize 32 $2-
    if (%tanks.O00O00OO > 12500) sockclose tanklist
  }
  if (%tankspublic) && ($sock(tanks.0)) || (action=list* iswm $1) || ($1 == action=remove) || (error=* iswm $1) {
    %tankslisting = $iif(action=list* iswm $1,1,0)
    if ($sock(tanklist)) .timertanks.OO0OOOOO -m 1 250 OO0OOOOO $calc(250+%tanks.O00O00OO) $1-
    else {
      if ($sock(tanks.0)) tokenize 32 $1- $+ &id= $+ %tanksid
      %tankslistsend = $1- $+ &remove= $+ %tanksremove
      if (%tanksbackup) {
        socket tanklist tanks.mircscripts.org
        socket tanklistb tanks.ileet.net
      }
      else {
        socket tanklist tanks.ileet.net
        sockclose tanklistb
      }
    }
  }
}
on *:keydown:@Tank�info:*:{
  if ($keyval !isnum 16-17) window -c @Tank�info
}
on *:dialog:tankschat:dclick:1:dialog -k $dname
alias -l O0O0000O {
  if ($window(@Tanks)) {
    drawrect -rfn @Tanks %tanks.O00OOO00 1 0 %tanks.O0O00O00 %tankswidth 16
    if ($timer(tanks.OO00O0O0)) OO0OO00O
  }
}
alias -l OO00OOO0 {
  %tanks.OO0O0OO0 = 1
  tokenize 32 %tanks.OO0O00O0
  %tanks.OO000OO0 = $ [ $+ [ $rand(1,$0) ] ]
  var %tanks.OOO0OO00 = tanks. $+ %tanks.OO000OO0
  if (* !iswm $sock(%tanks.OOO0OO00)) && (* !iswm $sock(tanks)) {
    if (%tanks.O00O0O00 [ $+ [ %tanks.OO000OO0 ] ] !isnum 0-4) %tanks.O00O0O0O = %tanks.OO000OO0
  }
  while ($1) {
    O0000O00 $1 $O0000O00
    tokenize 32 $2-
  }
  OO0OOO00
}
alias -l OO00O0OO {
  if ($1 isnum 0-1) %tankstahoma = $1
  if (%tankstahoma !isnum 0-1) %tankstahoma = 1
  if (%tankstahoma) {
    %tankschat.O00000O0 = $iif($version < 5.91,13,11)
    %tankschat.O000O00O = Tahoma
    %tankschat.O000OO00 = "Tahoma"
  }
  else {
    %tankschat.O00000O0 = $iif($version < 5.91,13,12)
    %tankschat.O000O00O = MS Sans Serif
    %tankschat.O000OO00 = "MS Sans Serif"
  }
  if ($1 isnum 0-1) {
    O0OOO0OO
    OO0OO000
    O0OO0O00
    drawdot @Tanks
  }
}
on *:close:@tanksO0000000:O0O00000
on *:keydown:@Tanks�scores:*:if (* iswm $keychar) O0000OOO
menu @tanksO0000O0O {
  mouse:window -h @tanksO0000O0O
  sclick:window -h @tanksO0000O0O
}
alias -l O0OOOOOO {
  var %tanks.O0OOO0O0 = $iif(%tanks.OO000O0O & 1,122,136), %tanks.OOOO000O = drawtext -rn @Tank�info 0 Fixedsys 15 8, %tanks.OOO00O00 = %tanks.O00O00O0 [ $+ [ $1 ] ]
  if ($window(@Tank�info)) {
    window -c @Tank�info
    return
  }
  if (%tanks.OOO0O000 [ $+ [ $1 ] ] < 1) return
  var %tanks.O000O0OOlags = -Bhdofpk
  if ($version >= 6.20) %tanks.O000O0OOlags = -Bw0dofpk
  window %tanks.O000O0OOlags +Ltf @Tank�info $int($calc(%tankswidth /2-52+$window(@Tanks).x)) $int($calc(%tanksheight /2-60+$window(@Tanks).y)) 104 %tanks.O0OOO0O0
  drawrect -rfn @Tank�info %tanks.O00O0OOO [ $+ [ $1 ] ] 1 0 0 104 %tanks.O0OOO0O0
  drawrect -rfn @Tank�info %tanks.15 1 3 3 98 $calc(%tanks.O0OOO0O0 -6)
  drawtext -crn @Tank�info 0 %tankschat.O000OO00 %tankschat.O00000O0 8 8 88 13 $O0O00OOO($1)
  %tanks.OOOO000O 24 Angle�� $iif($calc(180-%tanks.OOO00O00) < %tanks.OOO00O00,$calc(180-%tanks.OOO00O00),%tanks.OOO00O00)
  %tanks.OOOO000O 38 Power�� %tanks.O00000O0 [ $+ [ $1 ] ]
  %tanks.OOOO000O 52 Prev.�� %tanks.O000OO00 [ $+ [ $1 ] ]
  %tanks.OOOO000O 66 Max.��� $iif(%tanks.OO000O0O & 1,100,%tanks.O0O0O000 [ $+ [ $1 ] ] )
  %tanks.OOOO000O 84 Credits %tanks.OO0O0000 [ $+ [ $1 ] ]
  if (%tanks.OO000O0O !& 1) %tanks.OOOO000O 98 Shield� %tanks.OOO0O000 [ $+ [ $1 ] ]
  %tanks.OOOO000O = Accuracy:� $calc(+$round($calc(100*%tanks.O0OOO000 [ $+ [ $1 ] ] /%tanks.O000O000 [ $+ [ $1 ] ] ),0)) $+ %
  drawtext -rn @Tank�info 0 %tankschat.O000OO00 %tankschat.O00000O0 $calc(52-$width(%tanks.OOOO000O,%tankschat.O000O00O,%tankschat.O00000O0,0,0)/2) $iif(%tanks.OO000O0O & 1,101,115) %tanks.OOOO000O
  drawdot @Tank�info
}
menu query,nicklist,menubar {
  -
  $iif($menu_,Tanks)
  .$iif($server,Play &Tanks with [ $iif($1,$1,someone) ] ):{
    if ($1) tanks $1
    else tanks $$?="Tanks: Enter a nickname or IP address and port"
  }
  .Pl&ay a private game (/tanks):tanks
  .Start a t&emporary server (/tanks 0):tanks 0
  .Start a &dedicated server (/tanksd):tanksd
  .List Tanks &servers (/tanklist):tanklist
  .-
  .$O0O000O0(%tanksnoctcp,Disable Tanks &ctcp reply):%tanksnoctcp = $iif(%tanksnoctcp,0,1)
  .$O0O000O0(%tanksnolisten,Ig&nore all Tanks requests):%tanksnolisten = $iif(%tanksnolisten,0,1)
  .-
  .&Version:abouttanks
  .&Readme:tanksreadme
  .-
  .&Hide this menu:%tanksnomenu = 1
  .&Uninstall Tanks:{
    if ($?!="Are you sure you want to unload Tanks and clear all of its variables?") {
      O0O00000
      unset %tanks*
      unload -rs tanks.mrc
    }
  }
}
alias -l O0000OO0 {
  if ($sock(tanks)) return
  var %tanks.O0O0OO0O = %tanks.OO00OOO0, %tanks.OOO0OO00 = 0, %tanks.OOO00O00 = 0, %tanks.OOOO000O = 0
  while (%tanks.O0O0OO0O) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.O0O0OO0O ] ] isnum) {
      var %tanks.O0OOO0O0 = $iif(%tanks.O00O0O00 [ $+ [ %tanks.O0O0OO0O ] ] isnum 0-4,0,1)
      if (%tanks.OOO0O000 [ $+ [ %tanks.O0O0OO0O ] ] > 0) {
        inc %tanks.OOO0OO00
        if (%tanks.OO00OOOO [ $+ [ %tanks.O0O0OO0O ] ] ) {
          if (%tanks.O0OOO0O0) inc %tanks.OOO00O00
        }
        elseif (%tanks.O0OOO0O0) return
        elseif (%tankslvr) && (%tanksstopbots != 1) return
      }
      elseif (%tanks.O0OOO0O0) inc %tanks.OOOO000O
    }
    dec %tanks.O0O0OO0O
  }
  if (%tanks.OOO0OO00 < 2) return
  if (%tanks.OOO00O00) return 1
  if (%tanksstopbots) return $iif(%tanks.OOOO000O,1,2)
  if (%tankslvr) return 1
}
alias -l OOO000OO {
  if ($dialog(abouttanks)) did -o abouttanks 2 1 $gettok($1-,1,124)
  elseif ($deltok($1-,1,124)) OOOO0000 $ifmatch
}
on *:close:@Tanks�request:OOO0OOO0 decline
dialog tanksmsg {
  title "Tanks - Send a private message."
  option dbu
  size -1 -1 141 89
  text "Send to:"4,4 20 25 7
  list 1,27 19 88 66,hsbarvsbarsizextsel
  edit ""2,4 4 104 11, autohs result limit 200
  button "&Send" 3,112 4 25 11, ok
}
on *:sockopen:tanks:{
  if ($sockerr) {
    O00O00OO $ifmatch $sockname connection
    return
  }
  $O0O0OO00
  O000O00O O000OOO0 $tanksversion(1) %tankscolor %tanksname
  %tanks.OO000000 = O0000O00
}
alias -l OOO00O0O {
  if (* !iswm $window(@Tanks)) || (%tanks.O00O0O00 [ $+ [ %tanks.OO000OO0 ] ] !isnum 0-4) return
  var %tanks.OO0000O0, %tanks.OO0000OO, %tanks.OO0O0OOO = %tanks.O000OO00 [ $+ [ %tanks.OO000OO0 ] ] , %tanks.O00O00OO = $iif(%tanks.OOO0OOO0,%tanks.O00O0000,0), %tanks.OOO000O0 = %tanks.O00OOO0O. [ $+ [ %tanks.OO000OO0 ] ] , %tanks.O0O000O0, %tanks.OOO00O00 = %tanks.O00O0O00 [ $+ [ %tanks.OO000OO0 ] ]
  if (%tanks.O00O0OOO [ $+ [ %tanks.OOO000O0 ] ] !isnum) || (%tanks.OOO0O000 [ $+ [ %tanks.OOO000O0 ] ] < 1) || (%tanks.OO0O0OOO !isnum) {
    var %tanks.O0OO000O = %tankslvr
    :0
    var %tanks.OOO00000
    tokenize 32 %tanks.OO0O00O0
    while ($1) {
      if (%tanks.O0OO000O) && ($iif(%tanks.O0000O00 [ $+ [ $1 ] ] < $calc(%tankswidth /2),1,0) == $iif(%tanks.O0000O00 [ $+ [ %tanks.OO000OO0 ] ] < $calc(%tankswidth /2),1,0)) { }
      elseif (%tanks.OOO0O000 [ $+ [ $1 ] ] > 0) && ($1 != %tanks.OO000OO0) %tanks.OOO00000 = %tanks.OOO00000 $1
      tokenize 32 $2-
    }
    if ($numtok(%tanks.OOO00000,32)) {
      %tanks.OOO000O0 = $gettok(%tanks.OOO00000,$rand(1,$numtok(%tanks.OOO00000,32)),32)
      %tanks.O00OOO0O. [ $+ [ %tanks.OO000OO0 ] ] = %tanks.OOO000O0
    }
    elseif (%tanks.O0OO000O) {
      %tanks.O0OO000O = 0
      goto 0
    }
    %tanks.O0O000O0 = 1
  }
  if (%tanks.O0000O00 [ $+ [ %tanks.OO000OO0 ] ] < %tanks.O0000O00 [ $+ [ %tanks.OOO000O0 ] ] ) var %tanks.OO0000O0 = 1
  %tanks.OO0000OO = $iif(%tanksmode & 1 && %tanks.OOO00O00 < 4 || %tanks.OOO00O00 == 0,$calc(53 + 9 * %tanks.OOO00O00 / 3),66)
  %tanks.OO0000OO = $iif(%tanks.OO0000O0 != 1,180-) %tanks.OO0000OO + %tanks.O00O00OO / 99 * $iif($iif(%tanks.OO0000O0,$calc(0-%tanks.O00O00OO),%tanks.O00O00OO) > 0,17,14)
  %tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] = $round($calc(%tanks.OO0000OO),0)
  var %tanks.O0O0OOO0 = %tanks.O0000O00 [ $+ [ %tanks.OOO000O0 ] ] - %tanks.O0000O00 [ $+ [ %tanks.OO000OO0 ] ] , %tanks.O0O00000 = %tanks.OOO0O00O [ $+ [ %tanks.OOO000O0 ] ] - %tanks.OOO0O00O [ $+ [ %tanks.OO000OO0 ] ]
  var %tanks.O0000OOO = %tanks.OOO0O0OO [ $+ [ %tanks.OO000OO0 ] ] - %tanks.O0O0OOO0, %tanks.O0OO00OO = %tanks.OO00O000 [ $+ [ %tanks.OO000OO0 ] ] - %tanks.O0O00000
  if (%tanks.OO0O0OOO !isnum) || (%tanks.O0O000O0) || ($calc($iif(%tanks.OO0000O0,0-) (%tanks.O0000OOO + %tanks.O0O0OOO0 / 2)) > 0) {
    %tanks.O0000OOO = 0
    %tanks.O0OO00OO = 0 - %tanks.O0O00000
    %tanks.OO0O0OOO = $round($calc($iif(%tanksmode & 1 || %tanks.OOO00O00 == 0,$calc(80 + 5 * %tanks.OOO00O00),100) * $sqrt($abs($calc(%tanks.O0O0OOO0 / %tankswidth)))),0)
    %tanks.O0O000O0 = 1
  }
  $iif(%tanks.OO0000O0,dec,inc) %tanks.OO0O0OOO $round($calc(%tanks.O0000OOO / 8),0)
  inc %tanks.OO0O0OOO $round($calc(%tanks.O0OO00OO / 20),0)
  if (%tanks.OOO00O00 == 0) inc %tanks.OO0O0OOO $iif($iif(%tanks.OO0000O0,$calc(0-%tanks.O00O00OO),%tanks.O00O00OO) > 0,$calc($rand(0,4) - 2),$calc($rand(0,6) - 3))
  if (%tanks.OO0O0OOO > 100) %tanks.OO0O0OOO = 100
  if (%tanks.OO0O0OOO < 0) %tanks.OO0O0OOO = 0
  if (%tanks.O0O000O0 != 1) && (%tanks.O0000OOO >= -40) && (%tanks.O0000OOO <= 40) && (%tanks.O0OO00OO >= -38) && (%tanks.O0OO00OO <= 30) && (%tanks.OO0O0OOO isnum) {
    if (%tanks.OOO00O00 == 2) %tanks.OO00O0O0 = $rand(1,3)
    if (%tanks.OOO00O00 == 3) %tanks.OO00O0O0 = $rand(2,5)
    if (%tanks.OOO00O00 == 4) %tanks.OO00O0O0 = 5
    if (%tanks.OO00O0O0 < 1) %tanks.OO00O0O0 = 1
    if ($O00OOOO0 < %tanks.OO00O0O0) %tanks.OO00O0O0 = $ifmatch
  }
  tokenize 32 %tanks.OO0O00O0
  %tanks.O00O00OO = 1
  while (%tanks.OOO0O000 [ $+ [ $1 ] ] > 0) {
    if ($1 != %tanks.OO000OO0) if ($O00OOOO0($1) > %tanks.O00O00OO) %tanks.O00O00OO = $ifmatch
    tokenize 32 $2-
  }
  var %tanks.O00OO0OO = %tanks.O0O0O000 [ $+ [ %tanks.OO000OO0 ] ]
  if (%tanks.OO000O0O & 1) %tanks.O00OO0OO = 100
  while (%tanks.OOO0O000 [ $+ [ %tanks.OO000OO0 ] ] <= %tanks.O00O00OO) || (%tanks.OO0O0OOO > %tanks.O00OO0OO) && (%tanks.OO0O0000 [ $+ [ %tanks.OO000OO0 ] ] >= 30) && (%tanks.OOO0O000 [ $+ [ %tanks.OO000OO0 ] ] < 10) {
    OO0000O0 O000OO0O
    inc %tanks.O00OO0OO 10
  }
  %tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ] = %tanks.OO0O0OOO
  O00OOOOO 1
  OO0000OO
  OO00000O
}
on *:sockread:tanksversion:{
  var %tanks.OOOO000O, %tanks.O0OO000O, %tanks.O00OO0OO = $tanksversion(1)
  if ($sockerr) {
    OOO000OO Error $sockerr
    return
  }
  while (1) {
    sockread %tanks.OOOO000O
    if ($sockbr !isnum 1-) return
    if (tanks * iswm %tanks.OOOO000O) {
      %tanks.O0OO000O = $gettok(%tanks.OOOO000O,2,32)
      %tanks.OOOO000O = $gettok(%tanks.OOOO000O,3,32)
      if (%tanks.O00OO0OO != %tanks.O0OO000O) {
        abouttanks
        if (%tanks.OOOO000O > $version) {
          OOO000OO Newest requires mIRC %tanks.OOOO000O
          return
        }
        OOO000OO New:�[ $+ %tanks.O0OO000O $+ ]|New version of Tanks found! Download it by typing $O0OO0000(/downloadtanks)
      }
      else OOO000OO No new version
    }
  }
}
alias -l OO00OO0O {
  if (%tanks.OOO0O000 [ $+ [ %tanks.OO000OO0 ] ] > 0) && (%tanks.OO000000 isin O000000O O00000OO O0000000) {
    var %tanks.O0O0OOO0 = %tanks.O0000O00 [ $+ [ %tanks.OO000OO0 ] ] , %tanks.O0O00000 = 1 + %tanks.O0O00O00
    if ($1) drawrect -rfn @Tanks %tanks.O00OOO00 1 %tanks.O0O0O0O0 %tanks.O0O00000 10 13
    %tanks.O0O0O0O0 = %tanks.O0O0OOO0 - $iif(%tanks.O0O0OOO0 > $calc(%tankswidth /2),5,6)
    drawpic -cnt @Tanks 16711935 %tanks.O0O0O0O0 %tanks.O0O00000 120 104 10 13 %tanksbmp
    drawfill -srn @Tanks 7368816 16777215 $calc(5+%tanks.O0O0O0O0) %tanks.O0O00000
  }
}
alias -l OO0OOO0O {
  var %tanks.O00OO0OO
  if ($1 == /msg) && ($numtok($2,44)) {
    if (* !iswm $3) return
    %tanks.O00OO0OO = 1
    var %tanks.O0O0OOO0 = $numtok($2,44), %tanks.OOO00000, %tanks.OO0O0OOO
    while (%tanks.O0O0OOO0) {
      %tanks.OO0O0OOO = $gettok($2,%tanks.O0O0OOO0,44)
      if (* iswm %tanks.OOO00000) %tanks.OOO00000 = $O0O00OOO(%tanks.OO0O0OOO) $+ ,� $+ %tanks.OOO00000
      else %tanks.OOO00000 = $O0O00OOO(%tanks.OO0O0OOO)
      dec %tanks.O0O0OOO0
    }
    %tanks.OOO0OOOO = $2
    %tanks.O000OO0O = %tanks.OOO00000
    tokenize 32 $3-
  }
  if (/ooh* iswm $1) {
    var %tanks.OOO00OO0, %tanks.OO0000O0 = $rand(6,16), %tanks.O0OO000O = $2-
    while ($len(%tanks.OOO00OO0) < %tanks.OO0000O0) {
      %tanks.OOO00OO0 = %tanks.OOO00OO0 $+ $mid(oO,$rand(1,2),1)
    }
    tokenize 32 %tanks.OOO00OO0 $+ $right($1,-4) %tanks.O0OO000O
  }
  if ($1 == /xyzzy) O0OOOOO0 O0000O00 Something happened!
  elseif ($1 == /log) {
    if (/log on == $1-) {
      %tankslog = 1
      O0OOOOO0 O0000O00 Logging is ON
    }
    elseif (/log off == $1-) {
      %tankslog = 0
      O0OOOOO0 O0000O00 Logging is OFF
    }
    else O0OOOOO0 O0000O00 Logging is $iif(%tankslog,ON,OFF)
  }
  elseif ($1 == /color) || ($1 == /c) {
    if ($2 == 0) var %tanks.OOO00O0O = $gettok($remtok(%tanks.O0O00O0O,%tanks.O00OO000 [ $+ [ %tanks.O00O0O0O ] ] ,1,32),$rand(1,$calc($numtok(%tanks.O0O00O0O,32)-1)),32)
    else var %tanks.OOO00O0O = $calc($gettok(%tanks.O0O00O0O,$2,32))
    if (%tanks.OOO00O0O) {
      %tankscolor = %tanks.OOO00O0O
      if ($sock(tanks)) O000O00O O00OOOO0 %tanks.OOO00O0O
      else O000OOO0 %tanks.O00O0O0O %tanks.OOO00O0O
    }
    else OO000O0O
  }
  elseif ($istok(/sname /snick,$1,32)) {
    if ($sock(tanks)) %tanksserver = $2-
    else {
      var %tanks.O0OO000O = %tanks.O00O0O0O
      %tanks.O00O0O0O = 0
      O0O0O0OO $2-
      %tanks.O00O0O0O = %tanks.O0OO000O
    }
  }
  elseif ($istok(/n /name /nick,$1,32)) O0O0O0OO $2-
  elseif ($1 == /clear) {
    window -c @tanksO0000O00
    window -hl @tanksO0000O00
    %tankschat.O0000O0O = 0
    %tankschat.O0000OO0 = 0
    .timertanks.O0OOOOO0 -o 1 0 return
    O0OOO0OO
  }
  elseif ($1 == /vote) || ($1 == /v) {
    if (* !iswm $sock(tanks)) {
      if (%tanks.O00O0O0O isnum 1-) {
        O0OO000O %tanks.O00O0O0O $iif(%tanks.OO00OOOO [ $+ [ %tanks.O00O0O0O ] ] ,0,1)
        if (%tanks.OO00OOOO [ $+ [ %tanks.O00O0O0O ] ] ) O0OOOOO0 O0000O00 Type /end to end the round without voting
      }
      else O0OOOOO0 O0000O00 Type /end to end the round
    }
    if ($sock(tanks)) && (%tanks.OOO0O000 [ $+ [ %tanks.O00O0O0O ] ] > 0) && ($numtok(%tanks.OO0O00O0,32) > 1) O000O00O O000O000
    elseif ($sock(tanks)) O0OOOOO0 O0000O00 You can't vote
  }
  elseif ($1 == /port) {
    if ($2 !isnum) || ($sock(tanks.*,0) == 0) O0OOOOO0 O0000O00 Server port is %tanksport
    else {
      if ($2 !isnum 1-65534) {
        window -n @Tanks
        tokenize 32 /port $?="Enter new server port:"
        if (* !iswm $window(@Tanks)) return
        window -a @Tanks
        if ($2 !isnum 1-65534) return
      }
      %tankssavedport = $2
      if (%tanksport == $2) return
      %tanksport = $2
      O000O00O O000OO0O %tanksport
      O00O0O00
    }
  }
  elseif ($1 == /end) && (* !iswm $sock(tanks)) {
    if (%tanks.OO000000 isin O000000O O00000OO O0000000) O0O0O000
  }
  elseif ($1 == /b) || ($1 == /bot) || ($1 == /skill) && (* !iswm $sock(tanks)) {
    if ($O00OO00O($2)) O0OOOOO0 O0000O00 The game is full
  }
  elseif ($1 == /nb) || ($1 == /nobots) || ($1 == /nobot) && (* !iswm $sock(tanks)) {
    var %tanks.OOO00O0O = 1
    while (%tanks.OOO00O0O <= %tanks.OO00OOO0) {
      if (%tanks.O00O0O00 [ $+ [ %tanks.OOO00O0O ] ] isnum 0-4) OO0O00OO %tanks.OOO00O0O
      inc %tanks.OOO00O0O
    }
  }
  elseif ($1 == /join) || ($1 == /j) && (* !iswm $sock(tanks)) {
    if ($O00O0OO0($iif($0 > 1,$2-,%tanksname))) O0OOOOO0 O0000O00 The game is full
  }
  elseif ($istok(/b /bot /nobots /end /j /join,$1,32)) O0OOOOO0 O0000O00 Only the server can use the $1 command
  elseif ($1 == /p) || ($1 == /ping) || ($1 == /lag) O000O00O O000O00O $ctime
  elseif ($istok(/l /list /tanklist /tankslist,$1,32)) tanklist
  elseif ($1 == /quit) {
    if ($sock(tanks)) O000O00O O00OOO00
    elseif (%tanks.O00O0O0O != 0) OO0O00OO %tanks.O00O0O0O
    else O0OOOOO0 O0000O00 Use /exit to close Tanks
  }
  elseif ($1 == /exit) O0O00000
  elseif ($istok(/help /about /readme,$1,32)) tanksreadme
  elseif (%tanks.O00OO0OO) && ($0) {
    var %tanks.OOO00O0O, %tanks.OOO0OO00 = %tanks.OO00OOO0
    while (%tanks.OOO0OO00 >= 0) {
      if ($istok(%tanks.OOO0OOOO,%tanks.OOO0OO00,44)) && (%tanks.O00O0OOO [ $+ [ %tanks.OOO0OO00 ] ] isnum) {
        %tanks.OOO00O0O = 1
        if (* !iswm $sock(tanks)) OO0OOOO0 %tanks.OOO0OO00 O00000OO %tanks.O00O0O0O $1-
      }
      dec %tanks.OOO0OO00
    }
    if (%tanks.OOO00O0O) {
      O0OOOOO0 O000000O %tanks.O00O0OOO [ $+ [ %tanks.O00O0O0O ] ] %tanks.O000OO0O $1-
      if ($sock(tanks)) O000O00O O00000OO %tanks.OOO0OOOO $1-
    }
  }
  elseif ($0) && (%tanks.O00OO0OO != 1) {
    if ($sock(tanks)) O000O00O O00O00O0 $1-
    else O000O00O O00O00O0 %tanks.O00O0O0O $1-
    O0OOOOO0 O0000O0O %tanks.O00O0OOO [ $+ [ %tanks.O00O0O0O ] ] %tanks.O0OO0OO0 [ $+ [ %tanks.O00O0O0O ] ] $1-
  }
}
on *:unload:{
  O0O00000
  unset %tanks*
}
alias -l O0O00000 {
  %tanksxy = $window(@Tanks).x $window(@Tanks).y
  close -@ @Tanks
  if ($dialog(tanksban)) dialog -x tanksban
  if ($dialog(tanksignore)) dialog -x tanksignore
  if ($dialog(tankschat)) dialog -x tankschat
  if ($dialog(tanksbots)) dialog -x tanksbots
  if ($dialog(tanksserver)) dialog -x tanksserver
  .timertanks* off
  O00000OO 1
  if (%tankslog) {
    write " $+ $scriptdir $+ tanks.log" - Session Close: $fulldate
    write " $+ $scriptdir $+ tanks.log" -
  }
}
alias tanks.init {
  if ($version < 5.7) {
    OOOO0000 $tanksversion requires mIRC v5.7 or newer - $O0OO0000(http://www.mirc.com/get.html)
    if ($?!="You need a newer version of mIRC to use Tanks.") OO0O00O0 run http://www.mirc.com/get.html
    unload -rs " $+ $script $+ "
  }
  if (%tanksnick) %tanksname = %tanksnick
  unset %tanksnochat %tanksonecon
  var %tanks.O000O0OO = $scriptdir $+ tanksb.bmp
  if ($isfile(%tanks.O000O0OO)) .remove " $+ %tanks.O000O0OO $+ "
  if (%tanksautoscroll !isnum) %tanksautoscroll = 1
  if (%tanksforget !isnum) %tanksforget = 1
  if (%tankspublic !isnum) %tankspublic = 1
  %tanks.O000O0OO = $scriptdir $+ tanks.txt
  var %tanks.O0OO000O = $read -w"*Fixes and additions" " [ $+ [ %tanks.O000O0OO ] $+ ] "
  if (%tanks.O0OO000O) {
    window -zBkdaC @Tanks�versions -1 -1 -1 400 Fixedsys 15
    loadbuf $calc($readn - 1) $+ - $+ $calc($lines(%tanks.O000O0OO)-2) @Tanks�versions " $+ %tanks.O000O0OO $+ "
  }
}
alias -l OO00O000 {
  if (%tankschat.O00O0OO0) return
  var %tanks.O0O0OOO0 = %tankschat.O0000O0O
  inc %tankschat.O0000O0O $1
  if (%tankschat.O0000O0O >= $calc(%tankschat.O0000OO0 -10)) %tankschat.O0000O0O = %tankschat.O0000OO0 - 11
  if (%tankschat.O0000O0O < 0) %tankschat.O0000O0O = 0
  if (%tanks.O0O0OOO0 != %tankschat.O0000O0O) O0OOO0OO
}
alias -l OO000O00 {
  if ($sock($1)) {
    var %tanks.OOO00O0O = tanks.rand. $+ $ticks $+ $rand(0,999999)
    sockclose %tanks.OOO00O0O
    sockrename $1 %tanks.OOO00O0O
    sockwrite -tn %tanks.OOO00O0O $2-
    .timer -o 1 30 sockclose %tanks.OOO00O0O
  }
}
alias -l O000O00O {
  if ($sock(tanks)) sockwrite -tn tanks $1-
  else {
    var %tanks.OOO0OO00, %tanks.OOO00O0O = %tanks.OO00OOO0
    while (%tanks.OOO00O0O) {
      %tanks.OOO0OO00 = tanks. $+ %tanks.OOO00O0O
      if ($sock(%tanks.OOO0OO00)) && (%tanks.O00O0OOO [ $+ [ %tanks.OOO00O0O ] ] isnum) sockwrite -tn %tanks.OOO0OO00 $1-
      dec %tanks.OOO00O0O
    }
  }
}
dialog tanksserver {
  title "Tanks server settings"
  size -1 -1 183 164
  option dbu
  button "&Ok" 1,75 148 32 12, default ok
  button "&Cancel" 2,110 148 32 12, cancel
  button "&Apply" 3,145 148 32 12
  box "Game settings" 101,6 4 171 83, group
  check "Instagib mode (One hit kills, no starting credits)" 4,14 15 124 11
  check "Reset scores when a" 5,14 51 61 11
  combo 6,76 51 40 50, drop
  text "of" 102,119 53 6 8
  edit "" 7,126 51 16 11, center
  text "is reached" 103,145 53 26 8
  text "Wind mode:" 104,14 71 30 8
  combo 8,46 69 55 50, drop
  check "Explosive radius is smaller when power is greater than 80" 13,14 33 151 11
  box "Connections" 105,6 95 171 47, group
  text "Limit the number of players to:" 106,14 109 76 8
  edit "" 9,91 107 16 12, center
  button "-" 10,110 107 14 12
  button "+" 11,126 107 14 12
  check "Allow multiple connections from the same IP address" 12,14 125 135 10
}
alias -l O0OOO0O0 {
  var %tanks.OO0O0O0O
  if ($1 == 0) {
    %tanks.OO0O0O0O = $2
    tokenize 32 $3-
  }
  %tanks.OOO0OOOO = $remtok(%tanks.OOO0OOOO,$1,1,44)
  var %tanks.OO0000OO = $O0O00O0O($2), %tanks.OOO00O0O = $3
  if (* !iswm %tanks.OOO00O0O) return
  if ($dialog(tanksbots)) && (%tanks.OO0O0O0O isnum) {
    var %tanks.O0O0OO0O = 1
    while ($did(tanksbots,20,%tanks.O0O0OO0O) < $1) {
      inc %tanks.O0O0OO0O
    }
    did -i tanksbots 20 %tanks.O0O0OO0O $1
    did -i tanksbots 22 %tanks.O0O0OO0O %tanks.OOO00O0O
  }
  if ($OOOO000O($1,$4,%tanks.OOO00O0O)) {
    OO000O00 tanks. $+ $1 ver $tanksversion(1) O000000O
    return
  }
  O000O0O0 $1 %tanks.OO0000OO
  O0000O00 $1 $O0000O00
  unset %tanks.O00O000O [ $+ [ $1 ] ]
  var %tanks.O0O0OO0O = $4
  if ($sock(tanks)) && (%tanks.OO0O0O0O == 5) %tanks.O0O0OO0O = $sock(tanks).ip
  %tanks.O0OO0OO0 [ $+ [ $1 ] ] = %tanks.OOO00O0O
  %tanks.O00OO00O [ $+ [ $1 ] ] = %tanks.O0O0OO0O
  OOO0O00O
  %tanks.OOO00O0O = $O0O00OOO($1)
  if (* !iswm $timer(tanks.OOO0O000)) && (%tanks.O00O0O00 [ $+ [ %tanks.OO000OO0 ] ] == 5) OOO0O000 0
  %tanks.O00O0O00 [ $+ [ $1 ] ] = %tanks.OO0O0O0O
  if (* !iswm $sock(tanks)) {
    OO0OOOO0 $1 O00O0000 %tanks.O00OO0000 %tanks.O0OO0OO00
    O000000O $iif(%tanks.OO000000 !isin O000000O O00000OO O0000000,-) $1 1
    OOO000O0 $1
    OO0OOOO0 $1 O000O0O0 $1 $O0O00O00
    if (%tanks.OO0O0O0O isnum) %tanks.OO0O0O0O = 0 %tanks.OO0O0O0O
    var %tanks.O0OO000O = *!*@ $+ $4
    O000O00O O000OOO0 %tanks.OO0O0O0O $1 %tanks.OO0000OO %tanks.OOO00O0O $iif($4,$gettok($mask(%tanks.O0OO000O,4),2,64))
  }
  if ($1 == %tanks.O00O0O0O) && (%tankslog) && ($sock(tanks)) write " $+ $scriptdir $+ tanks.log" - Connect: %tanksip $+ : $+ %tanksport
  if ($1 == %tanks.O00O0O0O) && ($line(@tanksO0000O0O,1)) && ($sock(tanks)) {
    %tanks.OO000000 = O000000O
    OO0000OO
  }
  else {
    OO0OO000
    O0OO0O00
    if ($1 == %tanks.O00O0O0O) O0OOO0OO
  }
  O0OOOOO0 O000O000 %tanks.O00O0OOO [ $+ [ $1 ] ] %tanks.OOO00O0O $OO0O0O00($1)
  O0OO0OOO
  OOOO00O0
}
on *:keydown:@tanks:*:{
  if (%tanks.OO000OO0 == %tanks.O00O0O0O) OOO0O000 0
  var %tanks.O0OO000O = $keyval
  if ($mouse.key & 2) && (%tanks.O0OO000O isnum 35-36) {
    if (%tanks.O0OO000O == 35) %tankschat.O0000O0O = 0
    else %tankschat.O0000O0O = %tankschat.O0000OO0 - 11
    if (%tankschat.O0000O0O < 0) %tankschat.O0000O0O = 0
    O0OOO0OO
  }
  elseif (%tanks.OO000000 %tanks.O0OO000O == O00000O0 13) OO00OOO0
  elseif (%tanks.OO000000 == O0000000) OO0000O0 $O000O000($replace(%tanks.O0OO000O,38,O0000O0O,40,O00000O0,37,O00000OO,39,O000O00O,45,O00O00001,36,O00O00005,46,O0000OOO,35,O0000O00,49,O00O00001,50,O00O00002,51,O00O00003,52,O00O00004,53,O00O00005,13,O0000OO0,32,O000OO0O,9,$iif(%tanksinc == 1,O000O000,O000O0O0)))
  if ($istok(84 89 77,%tanks.O0OO000O,32)) .timertanks.OO00O00O -o 1 0 OO00O00O $iif(%tanks.O0OO000O == 77,1)
  elseif (%tanks.O0OO000O == 33) OO00O000 $iif($mouse.key !& 2,11)
  elseif (%tanks.O0OO000O == 34) O0O000OO $iif($mouse.key !& 2,11)
  elseif (%tanks.O0OO000O == 219) OO0000O0 O000O0OO
  elseif (%tanks.O0OO000O == 221) OO0000O0 O000OOO0
}
on *:dialog:tanklist:init,sclick,dclick:*:{
  if ($devent == init) || ($did == 3) {
    if ($sock(tanklist)) && (action=list* iswm %tankslistsend) { }
    else {
      %tankslisting = 1
      OO0OOOOO action=list
    }
  }
  elseif ($devent == dclick) && ($did == 1) || ($did == 2) {
    tokenize 32 $did($dname,9,$did($dname,1).sel).text
    if (http://* iswm $1) {
      dialog -i $dname
      run $1
    }
    elseif (/* iswm $1) {
      dialog -i $dname
      $right($1-,-1)
    }
    halt
  }
  elseif ($did == 1) {
    tokenize 32 $did($dname,9,$did($dname,1,1).sel)
    if (/* iswm $1) did -o $dname 5 1 $1-
    elseif (http://* iswm $1) did -o $dname 5 1 $1
    else did -r $dname 5
  }
}
alias -l O0OO0O0O {
  var %tanks.OO0O0OOO = %tanks.OO00OOO0
  while (%tanks.OO0O0OOO) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) {
      %tanks.O00O00O0 [ $+ [ %tanks.OO0O0OOO ] ] = $iif(%tanks.O0000O00 [ $+ [ %tanks.OO0O0OOO ] ] > $calc(%tankswidth /2),145,35)
      %tanks.O00000O0 [ $+ [ %tanks.OO0O0OOO ] ] = 45
      %tanks.OOO0O000 [ $+ [ %tanks.OO0O0OOO ] ] = 11
      %tanks.O0O0O000 [ $+ [ %tanks.OO0O0OOO ] ] = 100
      unset %tanks.O000OO00 [ $+ [ %tanks.OO0O0OOO ] ]
      if (%tanksforget) %tanksinc = 5
    }
    dec %tanks.OO0O0OOO
  }
  %tanks.OO00O0O0 = 1
  O0O00OO0 Drawing land...
}
on *:sockread:tanks:{
  var %tanks.OOO00OO0, %tanks.OOO00O0O
  if ($sockerr) {
    O00O00OO $ifmatch $sockname sockread
    return
  }
  while ($sock($sockname)) {
    sockread %tanks.OOO00OO0
    if ($sockbr !isnum 1-) return
    tokenize 32 %tanks.OOO00OO0
    if ($1 == ver) {
      if ($2 != $tanksversion(1)) {
        if ($2 > $tanksversion(1)) OOOO0000 The Tanks server has a newer version ( $+ $2 $+ ). Download the newest by typing $O0OO0000(/downloadtanks) $+ .
        else OOOO0000 The server has an older version ( $+ $2 $+ ). Your version is $tanksversion(1) $+ .
        O00000OO
        continue
      }
      tokenize 32 $3-
    }
    if ($1 == O00O000O) {
      while ($2) {
        tokenize 32 $2-
        aline @tanksO0000O0O $1
      }
      if ($line(@tanksO0000O0O,0) >= %tankswidth) {
        drawrect -rfn @Tanks %tanks.O00OOO00 1 0 0 %tankswidth %tanks.O0OO0O0O
        var %tanks.OOO00O0O = 1, %tanks.O0OO000O = 0
        while (%tanks.OOO00O0O <= %tankswidth) {
          drawline -rn @Tanks %tanks.O0OOO0OO 1 %tanks.O0OO000O $line(@tanksO0000O0O,%tanks.OOO00O0O) %tanks.O0OO000O %tanks.O0OO0O0O
          inc %tanks.OOO00O0O
          inc %tanks.O0OO000O
        }
        %tanks.OO000000 = O000000O
        if (%tanks.O00O0OOO [ $+ [ %tanks.O00O0O0O ] ] isnum) OOO0OO00
        O000O00O O00OO00O
      }
      continue
    }
    elseif ($1 == O000OO00) {
      close -@ @tanksO0000O0O
      window -hl @tanksO0000O0O
      unset %tanks.OO000000
      %tanks.O00O0000 = $2
      if ($3 != 1) {
        OO0OOO00
        O0OO0O0O
      }
    }
    elseif ($1 == O00OO00O) O000O00O $1
    elseif ($1 == O000O00O) O000O00O O00OO0OO $2
    elseif ($1 == O00OO0OO) {
      var %tanks.O0OO000O = $ctime - $2
      if (%tanks.O0OO000O) O0OOOOO0 O0000O00 Your lag is $duration(%tanks.O0OO000O)
      else O0OOOOO0 O0000O00 You have no lag
    }
    elseif ($1 == O00OOOOO) && (%tanks.OO000000 == O000000O) OO0000O0 0 $2-
    elseif ($1 == O00O0OOO) {
      %tanks.OO000O0O = $2
      %tanks.O0O0O00O = $3
      %tanks.OOO0OOO0 = $4
      %tanks.OO0O0OO0 = $5
      %tanks.O0000OO0 = $6
      %tanks.O000000O = $7
      %tanks.OO00O0O0 = $8
      %tanks.OO000OO0 = $9
      %tanks.O00O0000 = $10
      O0O00OO0
      O00OOOOO
      if (%tanks.OO000000 != O0000O00) {
        OO00OO00
        O0OOO00O
        O0OO0O00
        OO0OO000
        drawdot @Tanks
      }
    }
    elseif ($1 == O00OO0O0) {
      %tanks.OO00OOOO [ $+ [ $4 ] ] = $2
      %tanks.O00O0O00 [ $+ [ $4 ] ] = $3
      O0000O00 $4-
    }
    elseif ($1 == O000OOOO) {
      if ($2) {
        %tanks.OO00O0O0 = $2
        %tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] = $3
        %tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ] = $4
      }
      OO00000O $5-
    }
    elseif ($1 == O00OOO0O) OO00OOOO d
    elseif ($1 == O0000OOO) O0O0O000 $2-
    elseif ($1 == O0000O0O) OOOO00OO $2-
    elseif ($1 == O0000OO0) {
      %tanks.O00OOOOO = $calc(+$2)
      if (-99 > %tanks.O00OOOOO) %tanks.O00OOOOO = $ifmatch
      elseif (99 < %tanks.O00OOOOO) %tanks.O00OOOOO = $ifmatch
    }
    elseif ($1 == O00000OO) && (* !iswm %tanks.OO0OO0OO [ $+ [ $2 ] ] ) O0OOOOO0 O000OO00 %tanks.O00O0OOO [ $+ [ $2 ] ] $O0O00OOO($2) $3-
    elseif ($1 == O00O00O0) && (* !iswm %tanks.OO0OO0OO [ $+ [ $2 ] ] ) O0OOOOO0 O0000O0O %tanks.O00O0OOO [ $+ [ $2 ] ] $O0O00OOO($2) $3-
    elseif ($1 == O00000O0) O0OO0OO0 $2-
    elseif ($1 == O00O0000) {
      O000O0O0 0 $2
      %tanks.O0OO0OO00 = $3
      OOO0O00O
      OO0OO0OO
      close -@ @tanksO0000O0O
      window -hl @tanksO0000O0O
    }
    elseif ($1 == O00OOOO0) O000OOO0 $2-
    elseif ($1 == O000OO0O) %tanksport = $2
    elseif ($1 == O00O0O00) O0OOOOO0 O000O00O $2-
    elseif ($1 == O000O000) O0OO000O $2-
    elseif ($1 == O0000O00) OO0O00OO O0000O00 $2-
    elseif ($1 == O00OOO00) OO0O00OO $2-
    elseif ($1 == O000O0O0) {
      if ($2) %tanks.O00O0O0O = $2
      O0O00O00 $3-
      if ($2) unset %tanks.OO000000
      else {
        O0OO0O00
        drawdot @Tanks
        O0O00OO0
      }
    }
    elseif ($1 == O000OOO0) O0OOO0O0 $2-
    elseif ($1 == O00OO000) {
      OOOO0000 The Tanks game at %tanksip is full.
      O00000OO
    }
    elseif ($1 == O0000000) {
      OOOO0000 Tanks: You're trying to reconnect too fast.
      O00000OO
    }
    elseif ($1 == O000000O) {
      OOOO0000 Tanks: You're banned from the server at %tanksip $+ .
      O00000OO
    }
    elseif ($1 == O00O00OO) {
      OOOO0000 Tanks: There is already a connection from your address.
      O00000OO
    }
  }
}
alias tankscheck {
  $O00OOO00
  OOO000OO
  if ($sock(tanksversion).name) return
  OOO000OO Checking...
  sockopen tanksversion pages.cthome.net 80
}
alias -l OO0O000O {
  tokenize 32 $line(@tanksO0000O00,%tankschat.O00O0O0O)
  if ($1 == O0000O00) return *** $2-
  if ($1 == O000O0O0) return *** $4-
  if ($istok(O000O0OO O00000O0 O0000O0O O000000O O000OO00,$1,32)) return $3-
  return *** $3-
}
alias -l O0O00O00 {
  if ($isid) {
    var %tanks.OOO0OO00 = 0, %tanks.O0OO000O
    while (%tanks.OOO0OO00 <= %tanks.OO00OOO0) {
      if (%tanks.O00O0OOO [ $+ [ %tanks.OOO0OO00 ] ] isnum) {
        var %tanks.O0O0OO0O = $OO0O0O00(%tanks.OOO0OO00), %tanks.O00OO0OO = *!*@ $+ %tanks.O0O0OO0O
        %tanks.O0OO000O = %tanks.O0OO000O %tanks.OOO0OO00 %tanks.O00OO000 [ $+ [ %tanks.OOO0OO00 ] ] %tanks.O0OO0OO0 [ $+ [ %tanks.OOO0OO00 ] ] $iif(%tanks.O0O0OO0O,$gettok($mask(%tanks.O00OO0OO,4),2,64),0)
      }
      inc %tanks.OOO0OO00
    }
    return %tanks.O0OO000O
  }
  while ($0) {
    O000O0O0 $1 $O0O00O0O($2)
    %tanks.O0OO0OO0 [ $+ [ $1 ] ] = $3
    %tanks.O00OO00O [ $+ [ $1 ] ] = $iif($4,$4)
    tokenize 32 $5-
  }
  OOO0O00O
}
menu @Tanks�color {
  mouse:if ($window(@Tanks�color)) O000OO00 $mouse.x $mouse.y 1
  leave:O000OO00 0 0 1
  sclick:{
    var %tanks.OO0000OO = $O000OO00($click(@Tanks�color,$click(@Tanks�color,0)).x,$click(@Tanks�color,$click(@Tanks�color,0)).y)
    if (%tanks.OO0000OO) {
      close -@ @Tanks�color @1
      if (%tanks.O000O00O != 1) %tankscolor = %tanks.OO0000OO
      if ($sock(tanks)) O000O00O O00OOOO0 %tanks.OO0000OO
      elseif (%tanks.O000O00O) {
        unset %tanks.O000O00O
        if ($dialog(tanksbots)) {
          var %tanks.O0O0OO0O = 1
          :0
          if ($did(tanksbots,22,%tanks.O0O0OO0O).sel) {
            O000OOO0 $did(tanksbots,20,$did(tanksbots,22,%tanks.O0O0OO0O).sel) %tanks.OO0000OO
            inc %tanks.O0O0OO0O
            goto 0
          }
        }
      }
      else O000OOO0 %tanks.O00O0O0O %tanks.OO0000OO
    }
  }
}
alias -l OOO00OO0 if (%tanks.O0000O00 [ $+ [ $1 ] ] ) drawtext -brn @Tanks $2 %tanks.O00OOO00 fixedsys 20 $calc(%tanks.O0000O00 [ $+ [ $1 ] ] -$iif(%tanks.O0000O00 [ $+ [ $1 ] ] > $calc(%tankswidth /2),0,1)-(5*$len($3))) %tanks.O0O00O00 $iif(%tanks.O00O0OOO [ $+ [ $1 ] ] isnum,$3,�)
alias -l O000OOO0 {
  var %tanks.OO0000OO = $O0O00O0O($2), %tanks.OOO00O00 = %tanks.O00O0OOO [ $+ [ $1 ] ]
  if (%tanks.O00OO000 [ $+ [ $1 ] ] == %tanks.OO0000OO) return
  if ($sock(tanks.*,0)) O000O00O O00OOOO0 $1 %tanks.OO0000OO
  $O000O0O0($1,%tanks.OO0000OO)
  if ($1 == %tanks.OO000OO0) OO0OO000
  O0OO0O00
  O0O0OO0O $1
  O0OOOOO0 O000O0O0 %tanks.OOO00O00 $O0O00OOO($1) %tanks.O00O0OOO [ $+ [ $1 ] ]
}
on *:close:@tanksO0000O00:O0O00000
on *:dialog:tankschat:sclick:*:{
  if ($did == 1) did -f $dname 2
  elseif ($did == 3) && (* iswm %tanks.OO00OO00) {
    var %tanks.O0O0OOO0, %tanks.OOO00O0O, %tanks.OO0O0OOO, %tanks.OOO00000
    while (1) {
      %tanks.O0O0OOO0 = $did($dname,1,1).sel
      if (%tanks.O0O0OOO0) {
        %tanks.OO0O0OOO = $gettok(%tanks.OO00OO00,%tanks.O0O0OOO0,32)
        %tanks.OOO00O0O = $addtok(%tanks.OOO00O0O,%tanks.OO0O0OOO,44)
        did -uk $dname 1 %tanks.O0O0OOO0
      }
      else break
    }
    %tanks.OOO0OOOO = %tanks.OOO00O0O
    unset %tanks.OO00OO00
  }
}
alias -l OOO00OOO {
  if ($numtok(%tanks.OO0O00O0,32) > 8) {
    drawpic -cnt @Tanks 16711935 4 383 0 0 36 17 %tanksbmp
    return
  }
  var %tanks.OO0000OO = %tanks.O00O0OOO [ $+ [ %tanks.OO000OO0 ] ]
  if (%tanks.OO0000OO !isnum) return
  drawrect -rfn @Tanks %tanks.OO0000OO 1 4 383 36 17
}
alias tanksversion var %tanks.O0OO000O = 2007.04.19 | if ($1) return %tanks.O0OO000O | return Tanks [[ $+ %tanks.O0OO000O $+ ]]
alias -l OO0O00OO {
  var %tanks.O0OO00O0 = O0000OO0, %tanks.OOO0OO00 = O00OOO00
  if ($1 == O0000O00) {
    %tanks.O0OO00O0 = O0000000
    %tanks.OOO0OO00 = $1
    tokenize 32 $2-
  }
  if ($dialog(tanksbots)) {
    var %tanks.O0O0OO0O = $did(tanksbots,20).lines
    while (%tanks.O0O0OO0O) {
      if ($did(tanksbots,20,%tanks.O0O0OO0O) == $1) did -d tanksbots 20,22 %tanks.O0O0OO0O
      dec %tanks.O0O0OO0O
    }
    OOO0OO0O
  }
  if (%tanks.O00O0OOO [ $+ [ $1 ] ] isnum) && ($window(@Tanks)) {
    var %tanks.OO00O00O = $OO0O0O00($1)
    if (%tanks.OO00O00O isin (Admin)(Bot)) %tanks.O0OO0OOO = %tanks.OO00O00O
    elseif (%tanks.OO00O00O) %tanks.O0OO0OOO = (IP: $ifmatch $+ )
    else unset %tanks.O0OO0OOO
    O0OOOOO0 %tanks.O0OO00O0 %tanks.O00O0OOO [ $+ [ $1 ] ] $O0O00OOO($1) $2-
    var %tanks.O0OO000O = %tanks.OOO0O000 [ $+ [ $1 ] ] 
    %tanks.OOO0O000 [ $+ [ $1 ] ] = 0
    O0O0OOOO
    unset %tanks.O00O0OOO [ $+ [ $1 ] ] %tanks.O0OO0OO0 [ $+ [ $1 ] ] %tanks.O00OO000 [ $+ [ $1 ] ] %tanks.OO0OO0OO [ $+ [ $1 ] ] %tanks.O00OO00O [ $+ [ $1 ] ]
    O0OO0O00
    if (%tanks.OO000000 == O00000O0) OO0OO000
    drawpic @Tanks
    var %tanks.O0O0OO0O = 1
    while (%tanks.OOO0O000 [ $+ [ $gettok(%tanks.OO0O00O0,%tanks.O0O0OO0O,32) ] ] > 0) {
      inc %tanks.O0O0OO0O
    }
    dec %tanks.O0O0OO0O
    if ($1 == %tanks.OO000OO0) && (%tanks.OO000000 isin O000000O O00000OO O0000000) {
      .timertanks.OO00000O2 off
      O0O0OOO0
    }
    elseif (%tanks.O0O0OO0O < 2) || ($O0000OO0) && (%tanks.O0OO000O > 0) {
      if ($O0000OO0 > 1) OOOO00OO
      else O0O0O000
    }
    if ($1 == %tanks.O00O0O0O) {
      if ($sock(tanks)) {
        O00000OO
        return
      }
      %tanks.O00O0O0O = 0
    }
    if ($sock(tanks.*,0)) {
      O00000O0 $1 %tanks.OOO0OO00 $1-
      OO000O00 tanks. $+ $1 %tanks.OOO0OO00 $1-
      O0OO0OOO
    }
  }
}
alias -l O0O0O0O0 {
  if (* !iswm $window(@Tanks)) return
  if (%tankschat.O00OO00O == O0000000) var %tanks.O0O00000 = %tankschat.O00O000O, %tanks.O0OOO0O0 = %tankschat.O0000000 - %tankschat.O00O000O, %tanks.OO0000OO = OO00O000 11
  elseif (%tankschat.O00OO00O == O000OOOO) var %tanks.O0O00000 = %tankschat.O0000000 + 15, %tanks.O0OOO0O0 = $calc(%tankschat.O000O000 -15-%tankschat.O0000000), %tanks.OO0000OO = O0O000OO 11
  elseif (%tankschat.O00OO00O == O000000O) var %tanks.O0O00000 = %tankschat.O00OOO00, %tanks.O0OOO0O0 = 15, %tanks.OO0000OO = OO00O000
  elseif (%tankschat.O00OO00O == O000OO00) var %tanks.O0O00000 = %tankschat.O000O000, %tanks.O0OOO0O0 = 15, %tanks.OO0000OO = O0O000OO
  if ($1 != 1) && ($inrect($mouse.x,$mouse.y,%tankschat.O00O0O00,%tanks.O0O00000,15,%tanks.O0OOO0O0)) {
    %tankschat.O000000O = 1
    %tanks.OO0000OO
    return
  }
  %tankschat.O000000O = 0
  drawrect -fnr @Tanks %tankschat.O000O0OO 1 %tankschat.O00O0O00 %tankschat.O00O000O 15 %tankschat.O00O0000
  drawpic -cn @Tanks %tankschat.O00O0O00 %tankschat.O0000000 180 115 15 15 %tanksbmp
  drawpic -cn @Tanks %tankschat.O00O0O00 %tankschat.O00OOO00 150 115 15 15 %tanksbmp
  drawpic -cn @Tanks %tankschat.O00O0O00 %tankschat.O000O000 150 130 15 15 %tanksbmp
  drawdot @Tanks
}
alias -l OO000000 {
  did $iif($sock(tanks),-b,-e) tanksserver 105,106,9,10,11,12
  did $iif(%tanks.OO000O0O & 1,-c,-u) tanksserver 4
  did $iif(%tanks.O0O0O00O,-c,-u) tanksserver 13
  did $iif(%tanks.O000000O,-c,-u) tanksserver 5
  did $iif($did(tanksserver,5).state,-e,-b) tanksserver 6,7
  did -o tanksserver 6 1 �frag limit
  did -o tanksserver 6 2 �round limit
  did -c tanksserver 6 $iif(%tankslimitmode == 2,2,1)
  did -o tanksserver 7 1 %tankslimit
  did -o tanksserver 8 1 �No wind
  did -o tanksserver 8 2 �Constant wind
  did -o tanksserver 8 3 �Changing wind
  did -c tanksserver 8 $calc(1+%tankscwind)
  did -o tanksserver 9 1 %tanksplayerlimit
  did $iif(%tanksallowclones,-c,-u) tanksserver 12
}
alias -l OO0OO0O0 {
  O0OO0O0O
  drawrect -rfn @Tanks %tanks.O00OOO00 1 0 0 %tankswidth %tanks.O0OO0O0O
  tokenize 32 . %tanks.OOOO0000
  var %tanks.OOO00O0O, %tanks.OO0000O0 = 0, %tanks.OO0O0O0O = $2, %tanks.O0OOO0O0, %tanks.O0O0OO0O = 0, %tanks.O0O0OOO0 = 1, %tanks.O0O000OO = 0, %tanks.O0O00000, %tanks.OOOO000O = drawline -rn @Tanks %tanks.O0OOO0OO 1
  while (%tanks.O0O0OOO0 <= %tankswidth) && (* iswm $2) {
    if (%tanks.O0O0OO0O >= %tanks.OO0000O0) || (%tanks.O0O0OOO0 == %tankswidth) {
      tokenize 32 $3-
      %tanks.O0O00000 = $1
      %tanks.OO0000O0 = $2
      %tanks.O0O0OO0O = 0
    }
    %tanks.O0OOO0O0 = $int(%tanks.OO0O0O0O)
    %tanks.OOOO000O %tanks.O0O000OO %tanks.O0OOO0O0 %tanks.O0O000OO %tanks.O0OO0O0O
    rline @tanksO0000O0O %tanks.O0O0OOO0 %tanks.O0OOO0O0
    inc %tanks.OO0O0O0O %tanks.O0O00000
    inc %tanks.O0O0OOO0
    inc %tanks.O0O0OO0O
    inc %tanks.O0O000OO
  }
  OOO0OO00
}
alias -l O0O0O000 {
  if ($sock(tanks)) && ($1 != 1) return
  if ($sock(tanks.*,0)) O000O00O O0000OOO 1
  var %tanks.OOO00O0O = %tanks.OO00OOO0, %tanks.OOOO000O
  while (%tanks.OOO00O0O) {
    if (%tanks.O000000O == 1) && (%tanks.O00O0OOO [ $+ [ %tanks.OOO00O0O ] ] isnum) && (%tanks.O00O0OO0 [ $+ [ %tanks.OOO00O0O ] ] >= %tanks.O0000OO0) %tanks.OOOO000O = 1
    elseif %tanks.O000000O == 2) && (%tanks.OO0O0OO0 >= %tanks.O0000OO0) %tanks.OOOO000O = 1
    dec %tanks.OOO00O0O
  }
  if (%tanks.OOOO000O) OOOO00OO
  else {
    inc %tanks.OO0O0OO0
    OO0OOO00
  }
}
on *:sockclose:downloadtanks:O0OOO000
alias -l O00OOO0O {
  var %tanks.OO0000OO = window $iif(%tanksontop,-o,-u) $1
  if ($2-) {
    OO0O00O0 OO0O0OOO 2 $1 %tanks.OO0000OO
    if (%tanks.0 !isnum) $O0O0OO00
    if ($version >= 6.20) {
      window -w0zBdfkp +ntf $1-
    }
    else {
      window -hzBdfkp +ntf $1-
    }
    if (%tankslog) write " $+ $scriptdir $+ tanks.log" - Session Start: $fulldate
    if ($1 == @Tanks) {
      drawrect -rf @Tanks %tanks.1 1 0 0 %tankswidth %tanksheight
      var %tanks.O000O0OO = Verdana, %tanks.OOO0OO00 = $iif($version > 5.9,50,60), %tanks.O0OO000O = " $+ %tanks.O000O0OO $+ " %tanks.OOO0OO00, %tanks.O0O0OOO0 = $int($calc(2+(%tankswidth -$width(Tanks,%tanks.O000O0OO,%tanks.OOO0OO00,0,0))/2))
      var %tanks.O0OOO0O0 = $height(Tanks,%tanks.O000O0OO,%tanks.OOO0OO00), %tanks.O0O00000 = $int($calc((%tanks.O0OO0O0O -%tanks.O0OOO0O0)/2)), %tanks.OO0000OO = %tanks.O0O00000 + 2
      drawtext -rn @Tanks %tanks.8 %tanks.O0OO000O %tanks.O0O0OOO0 %tanks.OO0000OO Tanks | dec %tanks.O0O0OOO0 | dec %tanks.OO0000OO
      drawtext -rn @Tanks %tanks.14 %tanks.O0OO000O %tanks.O0O0OOO0 %tanks.OO0000OO Tanks | dec %tanks.O0O0OOO0 | dec %tanks.OO0000OO
      drawtext -rn @Tanks %tanks.9 %tanks.O0OO000O %tanks.O0O0OOO0 %tanks.OO0000OO Tanks | dec %tanks.O0O0OOO0 | dec %tanks.OO0000OO
      drawtext -rn @Tanks %tanks.15 %tanks.O0OO000O %tanks.O0O0OOO0 %tanks.OO0000OO Tanks | dec %tanks.O0O0OOO0 | dec %tanks.OO0000OO
      drawtext -rn @Tanks 16777215 %tanks.O0OO000O %tanks.O0O0OOO0 %tanks.OO0000OO Tanks | window -hl @tanksO0000O0O
      tokenize 122 nnnvqnomnkmmknzunoonqznqomnlomnlplzttnlsnnqzmjnlkkznsnlqkzrvniqnoonszuenvknmmnkomqnzruomnlomnlplziooonqzxongrnppnqlpjnzwinrooqnnhzslmnmonvzmhrnzoknoznpntzqenwzqenoznpntzulmolnmmnkompnoonojn
      %tanks.O0O0OOO0 = $int($calc((%tankswidth -85)/2))
      inc %tanks.O0O00000 %tanks.O0OOO0O0
      while ($1) {
        var %tanks.OO0000OO = 1, %tanks.OOO0OO00 = drawline -rn @Tanks %tanks.14 1
        while (%tanks.OO0000OO < $len($1)) {
          inc %tanks.O0O0OOO0 $calc($asc($mid($1,%tanks.OO0000OO,1)) - 110) | inc %tanks.OO0000OO
          inc %tanks.O0O00000 $calc($asc($mid($1,%tanks.OO0000OO,1)) - 110) | inc %tanks.OO0000OO
          %tanks.OOO0OO00 = %tanks.OOO0OO00 %tanks.O0O0OOO0 %tanks.O0O00000
        }
        %tanks.OOO0OO00
        tokenize 32 $2-
      }
      drawpic @Tanks
      var %tanks.O0O0OOO0 = %tankswidth
      while (%tanks.O0O0OOO0) {
        aline @tanksO0000O0O 0
        dec %tanks.O0O0OOO0
      }
    }
  }
  else %tanks.OO0000OO
}
alias -l OOO0O000 {
  if ($1 == off) {
    .timertanks.OO00OOOO off
    .timertanks.OOO0O000 off
    .timertanks.OOO0OOO0 off
    .timertanks.O0OOOO00 off
    return
  }
  if ($sock(tanks.*,0)) && (%tanks.O00O0O00 [ $+ [ %tanks.OO000OO0 ] ] !isnum 0-4) {
    var %tanks.OOO0OO00 = tanks. $+ %tanks.OO000OO0
    if ($1 == -1) {
      .timertanks.O0OOOO00 -o 1 $iif(%tanks.OO000O0O & 1,40,60) OOO0O000 %tanks.OO000OO0 -1
      .timertanks.OOO0OOO0 -o 1 $iif(%tanks.OO000O0O & 1,30,45) OOO0O000 %tanks.OO000OO0 -2
    }
    elseif ($1 == 0) && (* !iswm $sock(%tanks.OOO0OO00)) || ($1 !isnum) {
      .timertanks.OOO0O000 -o 1 $iif(%tanks.OO000O0O & 1,20,30) OOO0O000 %tanks.OO000OO0
      .timertanks.OO00OOOO -o 1 $iif(%tanks.OO000O0O & 1,10,15) OOO0O000 %tanks.OO000OO0 0
    }
    elseif ($1 == 0) {
      %tanks.O0O0OOOO [ $+ [ %tanks.OO000OO0 ] ] = 0
      OO0OOOO0 %tanks.OO000OO0 O00OO00O
      .timertanks.OOO0O000 -o 1 $iif($sock(%tanks.OOO0OO00),30,0) OOO0O000 %tanks.OO000OO0 1
    }
    elseif ($sock(tanks.*,0) > 1) && ($1 == %tanks.OO000OO0) && (%tanks.OO000000 isin O000000O O0000000) && (%tanks.O00O0OOO [ $+ [ $1 ] ] isnum) {
      if ($2 == -2) {
        var %tanks.O0OO000O = 0 0 Your turn is almost over!
        if ($sock(%tanks.OOO0OO00)) OO0OOOO0 %tanks.OO000OO0 O00O0O00 %tanks.O0OO000O
        elseif (%tanks.OO000OO0 == %tanks.O00O0O0O) O0OOOOO0 O000O00O %tanks.O0OO000O
        return
      }
      if ($2 == 0) {
        if ($sock(%tanks.OOO0OO00)) OO0OOOO0 %tanks.OO000OO0 O00OOO0O
        elseif (%tanks.OO000OO0 == %tanks.O00O0O0O) OO00OOOO d
        return
      }
      if ($2 == 1) {
        OO0O00OO O0000O00 %tanks.OO000OO0 (Ping timeout)
        return
      }
      if (* !iswm $sock(%tanks.OOO0OO00)) {
        var %tanks.O0O0OO0O = 1, %tanks.OO0000OO = 0
        while ($gettok(%tanks.OO0O00O0,%tanks.O0O0OO0O,32)) {
          if (%tanks.O00O0O00 [ $+ [ $gettok(%tanks.OO0O00O0,%tanks.O0O0OO0O,32) ] ] !isnum) inc %tanks.OO0000OO
          inc %tanks.O0O0OO0O
        }
        if (%tanks.OO0000OO == 0) return
      }
      elseif (%tanks.O0O0OOOO [ $+ [ $1 ] ] != 1) {
        .timertanks.OOO0O000 -o 1 30 OOO0O000 $1 1
        return
      }
      inc %tanks.O00O000O [ $+ [ $1 ] ] 2
      if (%tanks.O00O000O [ $+ [ $1 ] ] > 3) {
        unset %tanks.O00O000O [ $+ [ $1 ] ]
        OO0O00OO O0000O00 $1 (Idle three times)
        return
      }
      var %tanks.O0OO000O = $1 $1 Server $iif($sock(%tanks.OOO0OO00),sent fire request to ��,forced �� to fire) (
      if ($2 == -1) %tanks.O0OO000O = %tanks.O0OO000O $+ $iif(%tanks.OO000O0O & 1,40,60) second time limit reached)
      else %tanks.O0OO000O = %tanks.O0OO000O $+ $iif(%tanks.OO000O0O & 1,20,30) seconds idle)
      O000O00O O00O0O00 %tanks.O0OO000O
      O0OOOOO0 O000O00O %tanks.O0OO000O
      if ($sock(%tanks.OOO0OO00)) {
        OO0OOOO0 $1 O000OOOO
        .timertanks.OO00OOOO off
        .timertanks.OOO0O000 -o 1 20 OOO0O000 $1 1
      }
      else OO00000O
    }
  }
}
on *:dialog:abouttanks:init,sclick:*:{
  if ($devent == init) {
    did -a abouttanks 1 $tanksversion $+ $crlf $+ by Andy Dufilie
    tankscheck
  }
  if ($did == 3) tankscheck
  if ($did == 4) downloadtanks
  if ($did == 99) run http://pages.cthome.net/pdufilie/
  if ($did == 97) tanksreadme
}
alias -l O00OO0OO {
  iline @tanksO0000O00 1 $1-
  inc %tankschat.O0000OO0
  if (%tankschat.O0000O0O > 0) {
    inc %tankschat.O00O0O0O
    inc %tankschat.O00OO0O0
    inc %tankschat.O0000O0O
  }
  if (%tankschat.O0000OOO > 0) inc %tankschat.O0000OOO
  if (%tankschat.O00O0OO0) && (%tankschat.O0000O0O == 0) {
    %tankschat.O0000O0Odown = 1
    %tankschat.O0000O0O = 1
    inc %tankschat.O00O0O0O
    inc %tankschat.O00OO0O0
  }
}
alias -l O00OOOOO {
  var %tanks.O0O0OOO0 = %tanks.OO00OOO0
  while (%tanks.O0O0OOO0) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.O0O0OOO0 ] ] isnum) {
      var %tanks.OO0O0OOO = %tanks.O00000O0 [ $+ [ %tanks.O0O0OOO0 ] ] , %tanks.O00OO0OO = %tanks.O0O0O000 [ $+ [ %tanks.O0O0OOO0 ] ]
      if (%tanks.OO000O0O & 1) %tanks.O00OO0OO = 100
      if (%tanks.OO0O0OOO < 0) %tanks.OO0O0OOO = 0
      if (%tanks.OO0O0OOO > %tanks.O00OO0OO) %tanks.OO0O0OOO = %tanks.O00OO0OO
      %tanks.O00000O0 [ $+ [ %tanks.O0O0OOO0 ] ] = %tanks.OO0O0OOO
      var %tanks.OO0000OO = %tanks.OO0O0000 [ $+ [ %tanks.O0O0OOO0 ] ]
      if (%tanks.OO0000OO < 0) %tanks.OO0000OO = 0
      if (%tanks.OO0000OO > 999) %tanks.OO0000OO = 999
      %tanks.OO0O0000 [ $+ [ %tanks.O0O0OOO0 ] ] = %tanks.OO0000OO
    }
    dec %tanks.O0O0OOO0
  }
  if ($1) {
    if (%tanks.OO00O0O0 < 1) %tanks.OO00O0O0 = 1
    if ($O00OOOO0 < %tanks.OO00O0O0) %tanks.OO00O0O0 = $ifmatch
  }
}
on *:dialog:tankschat:init:0:{
  if (%tanks.OO00OO00) {
    unset %tanks.OO00OO00
    var %tanks.OOO00O0O = %tanks.OO00OOO0
    while (%tanks.OOO00O0O >= 0) {
      var %tanks.OOO0OO00 = tanks. $+ %tanks.OOO00O0O
      if ($sock(tanks)) || ($sock(%tanks.OOO0OO00)) && (%tanks.OOO00O0O != %tanks.O00O0O0O) && (%tanks.O00O0OOO [ $+ [ %tanks.OOO00O0O ] ] isnum) && (%tanks.O00O0O00 [ $+ [ %tanks.OOO00O0O ] ] !isnum 0-4) {
        did -i $dname 1 1 $iif(%tanks.OOO00O0O == 0,(Server)) $O0O00OOO(%tanks.OOO00O0O)
        %tanks.OO00OO00 = %tanks.OOO00O0O %tanks.OO00OO00
        if ($istok(%tanks.OOO0OOOO,%tanks.OOO00O0O,44)) did -ck $dname 1 1
      }
      dec %tanks.OOO00O0O
    }
    if ($did($dname,1,1).sel !isnum 1-99) did -c $dname 1 1
  }
  did -f $dname 2
}
alias -l O0OOO0OO {
  if (* !iswm $window(@Tanks)) || (%tankschat.O00OO0OO !isnum) return
  if (%tankschat.O0000OO0 == 0) {
    O0OOOOO0 - O0000OOO Right-click in the window for commands and options
    if ($sock(tanks.*,0)) || ($sock(tanks)) O0OOOOO0 - O0000OOO Press 'T' to chat or 'M' to send a private message
    if (%tanks.O00O0OOO0 isnum) {
      var %tanks.O0OO000O = O0OOOOO0 - $iif($timer(tanks.O0OOOOO0),O0000OOO,O0000O00) Server is: $O0O00OOO(0)
      if ($sock(tanks)) %tanks.O0OO000O (IP: $sock(tanks).ip $+ )
      else %tanks.O0OO000O
    }
    %tankschat.O0000OO0 = $line(@tanksO0000O00,0)
  }
  drawrect -fnr @Tanks %tankschat.O000O0OO 1 %tankschat.O00O0O00 %tankschat.O00O000O 15 %tankschat.O00O0000
  if (%tankschat.O0000OO0 < 12) %tankschat.O0000000 = %tanksheight + 15
  else {
    %tankschat.O0000000 = $int($calc(%tanksheight -30-(%tankschat.O00O0000 -15)*%tankschat.O0000O0O /(%tankschat.O0000OO0 -11)))
    if (%tankschat.O00OO00O == O0000000) drawrect -fnr @Tanks %tankschat.O00O0OOO 1 %tankschat.O00O0O00 %tankschat.O00O000O 15 $calc(%tankschat.O0000000 -%tankschat.O00O000O)
    elseif (%tankschat.O00OO00O == O000OOOO) drawrect -fnr @Tanks %tankschat.O00O0OOO 1 %tankschat.O00O0O00 %tankschat.O0000000 15 $calc(%tankschat.O000O000 -%tankschat.O0000000)
    drawpic -cn @Tanks %tankschat.O00O0O00 %tankschat.O0000000 180 115 15 15 %tanksbmp
  }
  var %tanks.O0O0OOO0 = 150
  if (%tankschat.O00OO00O == O000000O) && (%tankschat.O000000O) %tanks.O0O0OOO0 = 165
  drawpic -cn @Tanks %tankschat.O00O0O00 %tankschat.O00OOO00 %tanks.O0O0OOO0 115 15 15 %tanksbmp
  %tanks.O0O0OOO0 = 150
  if (%tankschat.O00OO00O == O000OO00) && (%tankschat.O000000O) %tanks.O0O0OOO0 = 165
  drawpic -cn @Tanks %tankschat.O00O0O00 %tankschat.O000O000 %tanks.O0O0OOO0 130 15 15 %tanksbmp
  var %tanks.O0O0OOO0 = %tankschat.O00OO000, %tanks.OO0O00OO = %tankschat.O00OOO00, %tanks.O00O00OO = %tankschat.O000OOOO, %tanks.O0OOO0O0 = %tankschat.O000O0O0, %tanks.OO0000OO
  drawrect -rfn @Tanks %tankschat.O00OO0OO 1 %tanks.O0O0OOO0 %tanks.OO0O00OO %tanks.O00O00OO %tanks.O0OOO0O0
  inc %tanks.O0O0OOO0 3
  %tanks.O00O00OO = $calc(%tanks.O00O00OO -19-%tankstahoma)
  var %tanks.O0O00000 = $calc(%tanks.OO0O00OO -15+%tanks.O0OOO0O0), %tanks.O0O000OO = $calc(%tanks.O0O0OOO0 +14+%tankstahoma), %tanks.O0OO000O, %tanks.OOO00O0O = %tankschat.O0000O0O
  while (%tanks.O0O00000 > %tanks.OO0O00OO) {
    inc %tanks.OOO00O0O
    tokenize 32 $line(@tanksO0000O00,%tanks.OOO00O0O)
    if (* !iswm $1) {
      drawdot @Tanks
      return
    }
    if ($1 == O0000O00) %tanks.O0OO000O = $2-
    elseif ($1 == O000O0O0) %tanks.O0OO000O = $4-
    else %tanks.O0OO000O = $3-
    if (�* !iswm %tanks.O0OO000O) {
      if ($1 != O0000O00) drawrect -rfn @Tanks $2 1 %tanks.O0O0OOO0 %tanks.O0O00000 12 12
      drawpic -cnt @Tanks 16711935 %tanks.O0O0OOO0 %tanks.O0O00000 $replace($1,O000O000,120,O000O0OO,132,O00000O0,132,O0000O0O,132,O000000O,132,O000OO00,132,O00000OO,132,O000O0O0,144,O0000OO0,156,O0000000,168,O0000O00,180) 80 12 12 %tanksbmp
      if ($1 == O000O0O0) drawfill -srn @Tanks $3 16777215 $calc(10+%tanks.O0O0OOO0) $calc(10+%tanks.O0O00000)
    }
    if ($1 == O0000O0O) %tanks.OO0000OO = %tankschat.O0000O00
    elseif ($istok(O000OO00 O000000O,$1,32)) %tanks.OO0000OO = %tankschat.O00000OO
    elseif ($1 == O00000O0) %tanks.OO0000OO = 6291520
    elseif ($1 == O000O0OO) %tanks.OO0000OO = 8388688
    else %tanks.OO0000OO = %tankschat.O000OO0O
    drawtext -nrc @Tanks %tanks.OO0000OO %tankschat.O000OO00 %tankschat.O00000O0 %tanks.O0O000OO $calc(%tanks.O0O00000 -%tankstahoma) %tanks.O00O00OO 13 %tanks.O0OO000O
    dec %tanks.O0O00000 13
  }
  if (%tankschat.O00O0OO0) %tankschat.O00O00O0
  drawdot @Tanks
}
on *:close:@Tanks:O0O00000
alias -l OO00000O {
  if (* !iswm $window(@Tanks)) return
  O0O00OO0 Getting ready to fire...
  O0O0000O
  O0O0OOOO
  drawdot @Tanks
  OOO0O000 off
  O00OOOOO 1
  if (%tanks.O00O0O00 [ $+ [ %tanks.OO000OO0 ] ] isnum 0-4) && (* !iswm $sock(tanks)) || (%tanks.OO000OO0 == %tanks.O00O0O0O) && (* !iswm $1-) {
    if ($sock(tanks)) O000O00O O00OO00O
  }
  if ($sock(tanks)) {
    if (* !iswm $1-) {
      O000O00O O000OOOO %tanks.OO00O0O0 %tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] %tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ]
      O0O00OO0 Waiting for server reply...
      %tanks.OO000000 = O000000O
      return
    }
    if (*\ %tanks.OO000OO0 $O0000O00(%tanks.OO000OO0) !iswm $1-) {
      var %tanks.O0OO000O = $sock(tanks).ip ; %tanks.O00O0O0O ; %tanks.OO0O00O0 ; %tanks.O00O0O00 [ $+ [ %tanks.OO000OO0 ] ] ; $ifmatch ; $1-
      sockclose tanklist
      OO0OOOOO error= $+ $replace(%tanks.O0OO000O,$chr(32),$right(.%20,3))
      O000O00O O00OOO00 Error
    }
  }
  elseif (%tanks.OO000OO0 == %tanks.O00O0O0O) {
    var %tanks.O0OO000O = %tanks.O00O000O [ $+ [ %tanks.OO000OO0 ] ] - 1
    %tanks.O00O000O [ $+ [ %tanks.OO000OO0 ] ] = $iif(%tanks.O0OO000O < 0,0,%tanks.O0OO000O)
  }
  var %tanks.OOO00O00 = $calc(%tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] *3.14159/180)
  var %tanks.OOO00OOO = $iif(%tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] > $iif(%tanks.O0000O00 [ $+ [ %tanks.OO000OO0 ] ] > $calc(%tankswidth /2),89,90),-1,+1)
  var %tanks.O0O000OO = $round($calc(%tanks.O0000O00 [ $+ [ %tanks.OO000OO0 ] ] %tanks.OOO00OOO +$cos(%tanks.OOO00O00)*10),0)
  var %tanks.OO0O00OO = $round($calc(%tanks.OOO0O00O [ $+ [ %tanks.OO000OO0 ] ] -$sin(%tanks.OOO00O00)*9-7),0)
  var %tanks.O00O00OO = $calc($iif(%tanks.OOO0OOO0,%tanks.O00O0000,0) / 96), %tanks.OOO0OO00 = %tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ] / 1.1, %tanks.OO0000OO = %tanks.OOO0OO00 * $cos(%tanks.OOO00O00), %tanks.OOO0OO00 = %tanks.OOO0OO00 * $sin(%tanks.OOO00O00)
  $iif($0,OO00000O3,OO00000O2) %tanks.O0O000OO %tanks.OO0O00OO %tanks.O00O00OO %tanks.OO0000OO %tanks.OOO0OO00 -.1 0 0 $1-
}
alias -l OO0OO00O {
  tokenize 32 %tanks.O0000O0O
  var %tanks.OO0O0OOO, %tanks.O0OO000O = -0.0065
  while (* !iswm %tanks.OO0O0OOO) || (%tanks.O0OO000O < $7) {
    inc %tanks.O0OO000O .5
    if (%tanks.O0OO000O > $7) %tanks.O0OO000O = $7
    %tanks.OO0O0OOO = %tanks.OO0O0OOO $int($calc($1 +%tanks.O0OO000O *($3 +$5 *%tanks.O0OO000O))) $int($calc($2 -0-%tanks.O0OO000O *($4 -4.9*%tanks.O0OO000O)))
  }
  drawline -rn @Tanks %tanks.O0OOOOO0 2 $1-2 %tanks.OO0O0OOO
  .timertanks.OO00O0O0 -om 1 1900 OO0O0OOO 4
}
alias -l O0OO0OO0 {
  if (* !iswm $2) || (%tanks.O0OO0OO0 [ $+ [ $1 ] ] === $2) return
  if ($dialog(tanksbots)) {
    var %tanks.O0O0OO0O = $did(tanksbots,20).lines
    while (%tanks.O0O0OO0O) {
      if ($did(tanksbots,20,%tanks.O0O0OO0O) == $1) did $iif($did(tanksbots,22,%tanks.O0O0OO0O).state,-ock,-o) tanksbots 22 %tanks.O0O0OO0O $2
      dec %tanks.O0O0OO0O
    }
  }
  var %tanks.OO0O0OOO = $O0O00OOO($1)
  %tanks.O0OO0OO0 [ $+ [ $1 ] ] = $2
  OOO0O00O
  if (%tanks.OO0O0OOO === $O0O00OOO($1)) { }
  else {
    if ($1 < 2) && (%tanks.O00O0O0O == 0) O0O00OO0
    O0OO0OOO
    O0OO0O00
    O0O00OO0
    if ($1 == 0) %tanks.OO0O0OOO = (Server)� $+ %tanks.OO0O0OOO
    O0OOOOO0 O00000OO %tanks.O00O0OOO [ $+ [ $1 ] ] %tanks.OO0O0OOO $O0O00OOO($1)
  }
  if ($sock(tanks.*,0)) O000O00O O00000O0 $1 $2
  OOOO00O0
}
alias -l O0O0OOOO {
  var %tanks.OO0O0OOO = %tanks.OO00OOO0, %tanks.OOO00OO0
  while (%tanks.OO0O0OOO) {
    %tanks.OOO00OO0 = %tanks.OOO00OO0 $O0O0OO0O(%tanks.OO0O0OOO,1)
    dec %tanks.OO0O0OOO
  }
  tokenize 32 %tanks.OOO00OO0
  while ($1) {
    O0O0OO0O $1
    tokenize 32 $2-
  }
}
alias -l OO00O00O {
  if ($dialog(tankschat)) {
    dialog -ev tankschat
    return
  }
  if ($1) %tanks.OO00OO00 = 1
  else unset %tanks.OO00OO00
  if (%tanks.O00O0OOO [ $+ [ %tanks.O00O0O0O ] ] isnum) || ($sock(tanks.*,0)) { }
  else return
  var %tanks.O0OO000O = $left($dialog(tankschat,$replace(tankschat,chat,$iif($1,msg,chat)),@tanks),200)
  if ($1) && (* iswm %tanks.OOO0OOOO) OO0OOO0O /msg %tanks.OOO0OOOO %tanks.O0OO000O
  else OO0OOO0O %tanks.O0OO000O
}
dialog tanklist {
  title "Tanks servers"
  option dbu
  size -1 -1 316 222
  list 1, 3 3 310 201, sizehsbarvsbar
  button "&Go" 2, 196 207 37 12, ok
  button "&Refresh" 3, 236 207 37 12
  button "&Close" 4, 276 207 37 12, cancel
  edit "" 5, 3 207 189 12, read
  list 9, 0 0 0 0, disablehide
}
on *:dialog:tanksbots:init,sclick:*:{
  if ($devent == init) {
    did -o tanksbots 2 1 %tanksname
    did $iif(%tanksstopbots,-u,-c) tanksbots 18
    did $iif(%tankslvr,-c,-u) tanksbots 19
    did -r tanksbots 22,20
    var %tanks.O0O0OO0O = 1
    while (%tanks.O0O0OO0O <= %tanks.OO00OOO0) {
      if (%tanks.O00O0OOO [ $+ [ %tanks.O0O0OO0O ] ] isnum) && (%tanks.O00O0O00 [ $+ [ %tanks.O0O0OO0O ] ] isnum) {
        did -a tanksbots 20 %tanks.O0O0OO0O
        did -a tanksbots 22 %tanks.O0OO0OO0 [ $+ [ %tanks.O0O0OO0O ] ]
      }
      inc %tanks.O0O0OO0O
    }
    OOO0OO0O
  }
  elseif ($did == 99) && ($dialog(tanksbots).focus == 2) || ($did == 3) {
    O00O0OO0 $did(tanksbots,2)
    halt
  }
  elseif ($did isnum 12-17) O00OO00O $calc($did -12)
  elseif ($did == 18) {
    %tanksstopbots = 1 - $did(tanksbots,18).state
    OOO000O0
    OO0OO000
  }
  elseif ($did == 19) %tankslvr = $did(tanksbots,19).state
  elseif ($did == 22) OOO0OO0O
  elseif ($did == 23) .timertanks.O0O0O0OO -o 1 0 O0O0O0OO
  elseif ($did == 24) OO000O0O 1
  elseif ($did == 25) {
    var %tanks.OOO00O0O = $did(tanksbots,22,0).sel
    while ($did(tanksbots,22,%tanks.OOO00O0O).sel) {
      var %tanks.OOO0OO00 = $did(tanksbots,22,%tanks.OOO00O0O).sel
      var %tanks.O0OO000O = $did(tanksbots,20,%tanks.OOO0OO00)
      did -d tanksbots 20,22 %tanks.OOO0OO00
      OO0O00OO %tanks.O0OO000O
      dec %tanks.OOO00O0O
    }
    OOO0OO0O
  }
}
alias -l O00O0O0O {
  if (* !iswm $window(@Tanks)) return
  if (%tanks.OO000OO0 == %tanks.O00O0O0O) && ($1 == 0) OOO0O000 0
  var %tanks.OOO00OO0 = .timertanks.O0O0O0O0 -om 1 200 .timertanks.O0O0O0O0 -om 0 50 O0O0O0O0, %tanks.OOO00OOO = O000O0O0 81 440 77 57 131 16 17, %tanks.O0O00OOO = O000O000 99 440 95 57 131 16 17, %tanks.OOOO000O = 0, %tanks.OO0O0OOO = $1, %tanks.OO00O00O = %tanks.O00OO0O0, %tanks.O0000OOO = $mouse.dx, %tanks.O0OO00OO = $mouse.dy, %tanks.O0O0OOO0 = $mouse.x, %tanks.O0O00000 = $mouse.y, %tanks.O0O0OO0O, %tanks.OO0O0O0O, %tanks.OOO00O00
  if ($mouse.key & 1) {
    %tanks.OOOO000O = 1
    if ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,%tankschat.O00OO000,%tankschat.O00OOO00,%tankschat.O000OOOO,%tankschat.O000O0O0)) {
      var %tanks.OO0000O0 = $int($calc((%tanks.O0O00000 -3-%tankschat.O00OOO00)/13))
      if (%tanks.OO0O0OOO == 0) && ($mouse.key > 1) {
        %tankschat.O00O0O0O = $calc(%tankschat.O0000O0O +11-%tanks.OO0000O0)
        %tankschat.O00OO0O0 = %tankschat.O00O0O0O
        if (%tanks.OO0000O0 < 11) && (%tankschat.O00O0O0O <= %tankschat.O0000OO0) {
          %tankschat.O00O00O0
          %tankschat.O00O00O0 = drawrect -nrif @Tanks 0 1 $calc(16+%tankschat.O00OO000) $calc(3+%tankschat.O00OOO00 +13*%tanks.OO0000O0) $calc(%tankschat.O000OOOO -17) 13
          %tankschat.O00O00O0
          drawdot @Tanks
          %tankschat.O00O0OO0 = 1
          unset %tankschat.O0000O0Odown
        }
        else unset %tankschat.O00O00O0
      }
      elseif (%tankschat.O00O0OO0) {
        if (%tanks.OO0000O0 > 10) %tanks.OO0000O0 = 10
        %tankschat.O00OO0O0 = $calc(%tankschat.O0000O0O +11-%tanks.OO0000O0)
        if (%tankschat.O00OO0O0 > %tankschat.O00O0O0O) %tankschat.O00OO0O0 = %tankschat.O00O0O0O
        %tankschat.O00O00O0
        %tankschat.O00O00O0 = drawrect -nrif @Tanks 0 1 $calc(16+%tankschat.O00OO000) $calc(3+%tankschat.O00OOO00 +13*(11+%tankschat.O0000O0O -%tankschat.O00O0O0O)) $calc(%tankschat.O000OOOO -17) $calc(13*(1+%tankschat.O00O0O0O -%tankschat.O00OO0O0))
        %tankschat.O00O00O0
        drawdot @Tanks
      }
    }
    elseif (%tankschat.O00O0OO0) {
      %tankschat.O00O00O0
      unset %tankschat.O00O00O0
      drawdot @Tanks
    }
    if (%tankschat.O000OOO0) {
      var %tanks.O0OO000O = %tankschat.O0000O0O
      %tankschat.O0000O0O = $int($calc(.5+%tankschat.O0000OOO +(%tankschat.O0000OO0 -11)*(%tankschat.O000OOO0 -%tanks.O0O00000)/(%tankschat.O00O0000 -15)))
      if (%tankschat.O0000O0O < $calc(%tankschat.O0000OO0 -11)) {
        if (%tankschat.O0000O0O < 0) %tankschat.O0000O0O = 0
      }
      else %tankschat.O0000O0O = %tankschat.O0000OO0 - 11
      if (%tanks.O0OO000O != %tankschat.O0000O0O) O0OOO0OO
    }
    if ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,%tankschat.O00O0O00,%tankschat.O00OOO00,15,%tankschat.O000O0O0)) {
      if ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,%tankschat.O00O0O00,%tankschat.O0000000,15,15)) && (%tanks.OO0O0OOO == 0) {
        %tankschat.O000OOO0 = %tanks.O0O00000
        %tankschat.O0000OOO = %tankschat.O0000O0O
      }
      if (%tankschat.O000OOO0 != 1) {
        if (%tanks.O0O00000 >= %tankschat.O00O000O) && (%tanks.O0O00000 < %tankschat.O0000000) {
          if (%tanks.OO0O0OOO == 0) {
            %tankschat.O00OO00O = O0000000
            OO00O000 11
            %tankschat.O000000O = 1
            %tanks.OOO00OO0
          }
        }
        elseif (%tankschat.O00OO00O == O0000000) O0O0O0O0 1
        elseif (%tanks.O0O00000 < %tankschat.O000O000) && (%tanks.O0O00000 >= $calc(15+%tankschat.O0000000)) {
          if (%tanks.OO0O0OOO == 0) {
            %tankschat.O00OO00O = O000OOOO
            O0O000OO 11
            %tankschat.O000000O = 1
            %tanks.OOO00OO0
          }
        }
        elseif (%tankschat.O00OO00O == O000OOOO) O0O0O0O0 1
      }
      if (%tanks.O0O00000 < %tankschat.O00O000O) {
        if (%tanks.OO0O0OOO == 0) {
          %tankschat.O00OO00O = O000000O
          %tankschat.O000000O = 1
          OO00O000
          %tanks.OOO00OO0
        }
      }
      elseif (%tankschat.O00OO00O == O000000O) O0O0O0O0 1
      if (%tanks.O0O00000 >= %tankschat.O000O000) {
        if (%tanks.OO0O0OOO == 0) {
          %tankschat.O00OO00O = O000OO00
          %tankschat.O000000O = 1
          O0O000OO
          %tanks.OOO00OO0
        }
      }
      elseif (%tankschat.O00OO00O == O000OO00) O0O0O0O0 1
    }
    elseif ($timer(tanks.O0O0O0O0)) O0O0O0O0 1
  }
  else {
    if (%tankschat.O00O0OO0) {
      if (%tankschat.O0000O0Odown) {
        unset %tankschat.O0000O0Odown %tankschat.O00O00O0
        %tankschat.O0000O0O = 0
        O0OOO0OO
      }
      else {
        %tankschat.O00O00O0
        drawdot @Tanks
        unset %tankschat.O00O00O0
      }
      %tankschat.O00O0OO0 = 0
      if ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,%tankschat.O00OO000,%tankschat.O00OOO00,%tankschat.O000OOOO,%tankschat.O000O0O0)) {
        var %tanks.OO0000OO
        while (1) {
          var %tanks.O0OO000O = $OO0O000O(%tankschat.O00O0O0O)
          if ($left(%tanks.O0OO000O,6) == *** ��) %tanks.OO0000OO = %tanks.OO0000OO $+ $mid(%tanks.O0OO000O,7)
          elseif ($left(%tanks.O0OO000O,5) " == *** � ") %tanks.OO0000OO = %tanks.OO0000OO $mid(%tanks.O0OO000O,7)
          elseif (��* iswm %tanks.O0OO000O) %tanks.OO0000OO = %tanks.OO0000OO $+ $mid(%tanks.O0OO000O,3)
          elseif (� * iswm %tanks.O0OO000O) %tanks.OO0000OO = %tanks.OO0000OO $mid(%tanks.O0OO000O,3)
          elseif (* iswm %tanks.OO0000OO) %tanks.OO0000OO = %tanks.OO0000OO $+ $crlf $+ %tanks.O0OO000O
          else %tanks.OO0000OO = %tanks.O0OO000O
          if (%tankschat.O00O0O0O > %tankschat.O00OO0O0) dec %tankschat.O00O0O0O
          else break
        }
        clipboard %tanks.OO0000OO
      }
    }
    unset %tankschat.O00OO00O
    %tankschat.O000OOO0 = 0
    if ($timer(tanks.O0O0O0O0)) {
      O0O0O0O0 1
      .timertanks.O0O0O0O0 off
    }
  }
  if (%tanks.OO000000 !isin O000000O O00000OO O0000000) return
  if (%tanks.OO0O0OOO isnum) || ($mouse.key !& 1) && ($active == @Tanks) {
    if (%tanks.O0O00000 < %tanks.O0OO0O0O) || ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,0,312,320,57)) {
      if ($appactive) OO0O0000 %tanks.O0000OOO %tanks.O0OO00OO %tanks.O0O0OOO0 %tanks.O0O00000 %tanks.OO0O0OOO
      return
    }
  }
  unset %tanks.O0O0O0OO
  if ($version != 6.02) window -h @tanksO0000OO0
  if (%tanks.OO00O00O < 1) && (%tanks.OOOO000O < 1) return
  if (%tanks.OO000000 == O0000000) {
    %tanks.OOO00O00 = %tanks.OOO00OOO %tanks.O0O00OOO
    %tanks.OOO00O00 = %tanks.OOO00O00 O00O0000 206 409 0 0 0 110 23
    %tanks.OOO00O00 = %tanks.OOO00O00 O0000O0O 42 383 38 0 74 36 36
    %tanks.OOO00O00 = %tanks.OOO00O00 O00000O0 42 421 38 38 112 36 36
    %tanks.OOO00O00 = %tanks.OOO00O00 O00000OO 4 402 0 19 93 36 36
    %tanks.OOO00O00 = %tanks.OOO00O00 O000O00O 80 402 76 19 93 36 36
    %tanks.OOO00O00 = %tanks.OOO00O00 O000OO0O 218 383 214 0 74 84 25
    %tanks.OOO00O00 = %tanks.OOO00O00 O0000OO0 218 433 214 50 124 84 24
  }
  if ($numtok(%tanks.OO0O00O0,32) > 8) {
    %tanks.OOO00O00 = %tanks.OOO00O00 O000O0OO 4 383 0 0 74 17 17
    %tanks.OOO00O00 = %tanks.OOO00O00 O000OOO0 23 383 19 0 74 17 17
  }
  tokenize 32 %tanks.OOO00O00
  while ($1) {
    %tanks.OO0O0O0O = $1
    if (%tanks.OO00O00O) && (%tanks.OO00O00O != %tanks.OO0O0O0O) || (%tanksinc == $replace(%tanks.OO0O0O0O,O000O0O0,1,O000O000,5)) { }
    else {
      if ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,$2,$3,$7,$8)) %tanks.O0O0OO0O = 1
      else %tanks.O0O0OO0O = 0
      if (%tanks.OO0O0O0O == O00O0000) {
        if (%tanks.O0O0OO0O) || (%tanks.O00OO0O0 == O00O0000) && (%tanks.OOOO000O) {
          var %tanks.O0OO000O = 5
          if (%tanks.O0O0OOO0 < 229) %tanks.O0OO000O = 1
          elseif (%tanks.O0O0OOO0 < 250) %tanks.O0OO000O = 2
          elseif (%tanks.O0O0OOO0 < 271) %tanks.O0OO000O = 3
          elseif (%tanks.O0O0OOO0 < 292) %tanks.O0OO000O = 4
          if (%tanks.OO00O0O0 != %tanks.O0OO000O) OO0000O0 %tanks.OO0O0O0O $+ %tanks.O0OO000O
          %tanks.O00OO0O0 = O00O0000
        }
      }
      elseif (%tanks.O0O0OO0O) && (%tanks.OOOO000O) {
        drawpic -cnt @Tanks 16711935 $2-4 $6-8 %tanksbmp
        drawdot @Tanks
        %tanks.O00OO0O0 = %tanks.OO0O0O0O
      }
      elseif (%tanks.OO00O00O == %tanks.OO0O0O0O) {
        if ($istok(O000O0O0 O000O000,%tanks.OO00O00O,32)) && (%tanks.O0O0OO0O) && (%tanks.OO0O0OOO) tokenize 32 $iif(%tanks.OO0O0O0O == O000O0O0,%tanks.O0O00OOO,%tanks.OOO00OOO)
        drawpic -cnt @Tanks 16711935 $2-5 $7-8 %tanksbmp
        drawdot @Tanks
      }
      if (%tanks.O0O0OO0O) && (%tanks.OO0O0OOO) OO0000O0 $O000O000(%tanks.OO0O0O0O)
    }
    tokenize 32 $9-
  }
  if (%tanks.OOOO000O) && (%tanks.O00OO0O0 == 0) %tanks.O00OO0O0 = \
  if (%tanks.OOOO000O < 1) %tanks.O00OO0O0 = 0
}
on *:sockread:tanklist*:{
  if ($sockname !isin tanklistb) return
  var %tanks.O0OO000O
  if ($sockerr) return
  while (1) {
    sockread %tanks.O0OO000O
    if ($sockbr !isnum 1-) return
    tokenize 32 %tanks.O0OO000O
    if ($sockname == tanklist) && (* !iswm $1-) {
      sockmark $sockname
      %tankslistcount = 0
      if (%tankslisting) && ($dialog(tanklist)) did -r tanklist 1,9,5
    }
    if ($sock($sockname).mark != wait) {
      if ($sockname == tanklist) {
        if ($1- == v) {
          abouttanks
          tanklistmsg You need the newest version of Tanks.
          return
        }
        if ($1- == vv) .downloadtanks
      }
      if (ip *.*.*.* iswm $1-2) && ($sock(tanks.*,0)) %tanksip = $2
      elseif (%tankslisting) && ($dialog(tanklist)) {
        if (<* iswm $1-) {
          if ($sockname == tanklist) {
            if (%tanksbackup) {
              unset %tanksbackup
              tanklistmsg Unable to connect.
            }
            else {
              %tanksbackup = 1
              socket tanklist tanks.mircscripts.org
              socket tanklistb tanks.ileet.net
            }
          }
          else sockclose $sockname
          return
        }
        elseif ($sockname == tanklist) {
          if (rem ?* iswm $1-) {
            did -az tanklist 1 $2-
            did -a tanklist 9 rem
          }
          elseif (http://* ?* iswm $1-) {
            did -az tanklist 1 $2-
            did -a tanklist 9 $1
          }
          elseif (tanks isin $1) || (server isin $1) && (/*?	?* iswm $1-) {
            did -az tanklist 1 $deltok($2-,1,9)
            did -a tanklist 9 $gettok($1-,1,9)
          }
          else OOO0000O $1-
        }
      }
      elseif ($sockname == tanklist) && (b? ?* iswm $1-) && ($window(@tanksO0000000)) {
        aline @tanksO0000000 $mid($1-,2)
        OOOO00O0
        if ($1 == bm) dline @tanksO0000000 $line(@tanksO0000000,0)
      }
    }
  }
}
alias -l OOO0O0OO {
  if ($appactive) && ($active == @Tanks) return
  if (%tanks.O00O0O0O) && (* !iswm $sock(tanks.0)) {
    flash @Tanks
    window $iif($1,-g1,-g3) @Tanks
  }
}
alias tanksn %tanksmode = 0 | tanks $1-
alias -l O00O0O00 {
  if ($1) inc %tanksport
  sockclose tanks.0
  .timertanks.O00O0O00 -o 1 0 O00O0O00 $calc(1+$1) $2
  socklisten tanks.0 %tanksport
  .timertanks.O00O0O00 off
  O0OO0OOO
  if ($1) && ($version < 6.14) {
    O0OOOOO0 O0000O00 Please ignore mIRC's error message. Tanks was testing the port and it was unavailable.
    O0OOOOO0 O0000O00 Server running on port %tanksport
  }
  if ($2) return
  O0OOOOO0 O0000O00 Server port has been changed to %tanksport
  :error
  if ($version >= 6.14) reseterror
}
on *:sockopen:downloadtanks:{
  if ($sockerr) {
    OOO000OO Connection error $sockerr |Connection error ( $+ $sockerr $+ ) when downloading Tanks
    close -@ $O00OO0O0
    return
  }
  write -c $O0OO00OO
  sockmark $sockname 1 0
  sockwrite -n $sockname GET /pdufilie/irc/tanks.exe HTTP/1.0
  sockwrite -n $sockname Accept: */*
  sockwrite -n $sockname Host: pages.cthome.net
  sockwrite -n $sockname
}
on *:connect:%tanksctime = $ctime
alias -l OO0000OO {
  if ($window(@Tanks)) {
    O0O00OO0
    O00OOOOO
    OO00OO00
    O0OO0O00
    OO0OO000 - $1
    O0O0OOOO
    if ($1 != 0) O0OOO0OO
    else drawdot @Tanks
  }
}
alias -l OOO0000O {
  var %tanks.O0O0OO0O = $1, %tanks.OOO00O0O = $2, %tanks.OO0O0OOO = $3, %tanks.OOO0OO00 = $4, %tanks.O0O0OOO0 = $5, %tanks.O0O0OO00 = $6, %tanks.O0O00OOO = $7, %tanks.O00O00OO = $8, %tanks.O00OO0OO = $9, %tanks.OO0000O0 = $10, %tanks.O0000OOO = $11-
  if ($dialog(tanklist)) && (%tanks.O0O0OOO0 isnum) && (%tanks.OO0O0OOO isnum) {
    if (/*tanks * iswm $did(tanklist,9,$did(tanklist,9).lines)) did -az tanklist 1,9 $str(-,198)
    did -az tanklist 1 � $+ $iif(%tanks.OOO0OO00,�������Temp server:�,Dedicated server:�) %tanks.OOO00O0O
    did -a tanklist 9 /tanks %tanks.O0O0OO0O %tanks.OO0O0OOO
    var %tanks.O0OO000O = did -az tanklist 1 $str(�,7) Settings/info:�
    if (%tanks.O0O00OOO) %tanks.O0OO000O = %tanks.O0OO000O Instagib ����
    %tanks.O0OO000O = %tanks.O0OO000O $iif(%tanks.O00O00OO,$iif(%tanks.O00O00OO == 1,Constant wind,Changing wind),No wind) ����
    if (%tanks.O00OO0OO) %tanks.O0OO000O = %tanks.O0OO000O $iif(%tanks.O00OO0OO == 1,Frag limit:,Round limit:) %tanks.OO0000O0 ����
    else %tanks.O0OO000O = %tanks.O0OO000O No limit ����
    %tanks.O0OO000O IP: %tanks.O0O0OO0O ���� Port: %tanks.OO0O0OOO
    did -a tanklist 9 /tanks %tanks.O0O0OO0O %tanks.OO0O0OOO
    var %tanks.O0OO00O0 = 0
    tokenize 32 %tanks.O0000OOO
    while (1) {
      var %tanks.O0OO000O = 1
      while (%tanks.O0OO000O == 1) || ($width($replace($ [ $+ 1- $+ [ %tanks.O0OO000O ] ] ,$chr(32),����),Tahoma,$iif($version < 5.91,13,11),0,0) < 450) && (* iswm $ [ $+ [ %tanks.O0OO000O ] ] ) {
        inc %tanks.O0OO000O
      }
      dec %tanks.O0OO000O
      var %tanks.OOO000O0 = $ [ $+ 1- $+ [ %tanks.O0OO000O ] ]
      if (%tanks.O0OO00O0) did -az tanklist 1 $str(�,30) $replace(%tanks.OOO000O0,$chr(32),����)
      else did -az tanklist 1 $iif(?? iswm %tanks.O0O0OOO0,�,���) $+ $iif(?? iswm %tanks.O0O0OO00,�,���) %tanks.O0O0OOO0 / %tanks.O0O0OO00 �Players:� $replace(%tanks.OOO000O0,$chr(32),����)
      did -a tanklist 9 /tanks %tanks.O0O0OO0O %tanks.OO0O0OOO
      if (%tanks.O0OO000O) tokenize 32 $ [ $+ [ $calc(1+%tanks.O0OO000O) ] $+ ] -
      inc %tanks.O0OO00O0
      if ($0 !isnum 1-) break
    }
    inc %tankslistcount %tanks.O0O0OOO0
    %tanks.O0OO000O = ( $+ %tankslistcount players total)
    dialog -t tanklist Tanks servers $iif(%tankslistcount,%tanks.O0OO000O)
  }
}
alias -l OO000OO0 {
  if (%tanks.OO0O0000 [ $+ [ %tanks.OO000OO0 ] ] >= 30) && (%tanks.OOO0O000 [ $+ [ %tanks.OO000OO0 ] ] < 10) && (%tanks.OO000O0O !& 1) {
    dec %tanks.OO0O0000 [ $+ [ %tanks.OO000OO0 ] ] 30
    inc %tanks.OOO0O000 [ $+ [ %tanks.OO000OO0 ] ]
    var %tanks.O0OO000O = $calc(%tanks.O0O0O000 [ $+ [ %tanks.OO000OO0 ] ] +10)
    if (100 < %tanks.O0OO000O) %tanks.O0OO000O = $ifmatch
    %tanks.O0O0O000 [ $+ [ %tanks.OO000OO0 ] ] = %tanks.O0OO000O
    if ($O00OOOO0 < %tanks.OO00O0O0) %tanks.OO00O0O0 = $ifmatch
    OO0OO000
    O0OO0O00
    drawdot @Tanks
  }
}
alias -l OO0000O0 {
  if ($timer(tanks.OO00000O2)) return
  var %tanks.OOO00O00, %tanks.O0O0OO0O = %tanksinc
  if ($istok(O0000O0O O00000O0 O00000OO O000O00O O0000O00 O0000OOO O000OO0O O00O00001 O00O00002 O00O00003 O00O00004 O00O00005,$1,32)) O000O00O O00OOOOO $1 $iif($2 isnum,$2,%tanks.O0O0OO0O)
  if ($1 == O000O0O0) {
    %tanksinc = 1
    OO0OO000
  }
  if ($1 == O000O000) {
    %tanksinc = 5
    OO0OO000
  }
  if ($1 == 0) tokenize 32 $2-
  if ($2 isnum) %tanks.O0O0OO0O = $2
  if ($1 == O0000O0O) || ($1 == O00000O0) {
    %tanks.OOO00O00 = %tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ] $iif($1 == O0000O0O,+,-) %tanks.O0O0OO0O
    if (%tanks.OOO00O00 < 0) %tanks.OOO00O00 = 0
    if ($iif(%tanks.OO000O0O & 1,100,%tanks.O0O0O000 [ $+ [ %tanks.OO000OO0 ] ] ) < %tanks.OOO00O00) %tanks.OOO00O00 = $ifmatch
    %tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ] = %tanks.OOO00O00
    var %tanks.OO0O0OOO = %tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ] 
    OOO00000 398 %tanks.OO0O0OOO 0 $iif(%tanks.O0O0O00O && %tanks.OO0O0OOO > 80,$iif(%tanks.OO0O0OOO > 90,8421631,12632319))
  }
  elseif ($1 == O00000OO) || ($1 == O000O00O) {
    %tanks.OOO00O00 = $replace($1,O00000OO,1,O000O00O,-1)
    inc %tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] $calc(%tanks.O0O0OO0O *%tanks.OOO00O00)
    if ($calc(%tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] -%tanks.O0O0OO0O *%tanks.OOO00O00) == $calc(90+90*%tanks.OOO00O00)) %tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] = $calc(90-90*%tanks.OOO00O00)
    if (%tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] < 0) %tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] = 0
    if (%tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] > 180) %tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] = 180
    O0O0O00O
    O0O0OO0O %tanks.OO000OO0
  }
  elseif (O00O0000? iswm $1) {
    %tanks.OO00O0O0 = $O00OOOO0
    if (%tanks.OO00O0O0 > $right($1,1)) %tanks.OO00O0O0 = $right($1,1)
    O00OO000
  }
  elseif ($1 == O0000O00) {
    %tanks.O0O0OO0O = $calc(1+%tanks.OO00O0O0)
    if (%tanks.O0O0OO0O > 5) %tanks.O0O0OO0O = 5
    if ($calc(25*%tanks.O0O0OO0O) <= %tanks.OO0O0000 [ $+ [ %tanks.OO000OO0 ] ] ) %tanks.OO00O0O0 = %tanks.O0O0OO0O
    O00OO000
  }
  elseif ($1 == O0000OOO) {
    dec %tanks.OO00O0O0
    if (%tanks.OO00O0O0 < 1) %tanks.OO00O0O0 = 1
    O00OO000
  }
  elseif ($1 == O000OO0O) OO000OO0
  elseif ($1 == O0000OO0) {
    if (%tanks.OO000OO0 == %tanks.O00O0O0O) && ($timer(tanks.OO00000O2)) return
    OO00000O
  }
  elseif ($1 == O000O0OO) && (%tanks.O0OO0O00 > 0) {
    dec %tanks.O0OO0O00 %tanks.O0OOOOOO
    O0OO0O00
  }
  elseif ($1 == O000OOO0) {
    var %tanks.O0OO000O = %tanks.OO00OOO0
    while (%tanks.O0OO000O) && (%tanks.O00O0OOO [ $+ [ %tanks.O0OO000O ] ] !isnum) {
      dec %tanks.O0OO000O
    }
    if (%tanks.O0OO000O > $calc(8+%tanks.O0OO0O00)) inc %tanks.O0OO0O00 %tanks.O0OOOOOO
    O0OO0O00
  }
  drawdot @Tanks
}
alias -l O00000OO {
  if ($sock(tanks.0)) O0OO00O0
  unset %tanks.O00O0OOO*
  sockclose tanks
  sockclose tanks.*
  if ($window(@Tanks)) && ($1 != 1) {
    O0OOOOO0 O0000O00 Game over
    unset %tanks.*
    %tanks.O0OO0O0O = 311
  }
  else {
    close -@ @tanksO0000O0O @Tanks�color @tanksO00000OO @Tank�info @tanksO0000000 @tanksO00000O0 @tanksO0000OO0 @tanksO0000O00 @tanksO000000O
    unset %tankschat.* %tanksbmp %tankswidth %tanksheight %tanks.*
  }
  if ($window(@Tanks�request)) O000OOOO
}
alias -l O0OOOO00 {
  OO00OO0O
  unset %tanks.OO000000
  drawdot @Tanks
  var %tanks.OO0O0OOO = %tanks.OO00OOO0, %tanks.OOO00O0O = 0, %tanks.O0OOO0O0 = 0
  while (%tanks.OO0O0OOO) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) {
      if (%tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] !isnum 0-4) inc %tanks.O0OOO0O0
      inc %tanks.OOO00O0O
    }
    dec %tanks.OO0O0OOO
  }
  if (* !iswm $1) && (%tanks.OOO00O0O > 1) {
    if (%tanks.OO000OO0 == %tanks.O00O0O0O) {
      %tanks.OO000000 = O00000OO
      OO0O00O0 OO0O0OOO 3
    }
    elseif (%tanks.O00O0O00 [ $+ [ %tanks.OO000OO0 ] ] isnum 0-4) && (* !iswm $sock(tanks)) {
      %tanks.OO000000 = O000000O
      .timertanks.OOO00O0O -om 1 $rand(275,400) OOO00O0O
    }
    else %tanks.OO000000 = O000000O
  }
  if (%tanks.OO000OO0 == %tanks.O00O0O0O) {
    if (%tanksnopop != 1) && ($window(@Tanks).state == minimized) window -a @Tanks
    OOO0O0OO 1
  }
  OOO0O000 0
  OOO0O000 -1
  if ($version != 6.02) {
    window -h @tanksO0000OO0
    unset %tanks.O0O0O0OO
  }
  if (* !iswm $sock(tanks)) {
    %tanks.OO0O0OOO = 1
    while (%tanks.OO0O0OOO <= %tanks.OO00OOO0) {
      var %tanks.OOO0OO00 = tanks. $+ %tanks.OO0O0OOO
      if (* !iswm $sock(%tanks.OOO0OO00)) && (%tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] !isnum) OO0O00OO %tanks.OO0O0OOO (Connection lost)
      inc %tanks.OO0O0OOO
    }
  }
}
alias -l OO00OOOO {
  if (%tanksnosound) return
  !.splay " $+ $scriptdir $+ tanks $+ $1 $+ .wav"
}
on *:keydown:@tanksO0000000,@tanksO00000O0,@tanksO0000O00,@tanksO0000O0O,@tanksO0000OO0,@tanksO00000OO:*:{
  if ($target == @tanksO0000OO0) unset %tanks.O0O0O0OO
  window -h $target
}
alias -l O0O0O00O {
  var %tanks.OOO00O00 = %tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ]
  if ($calc(180-%tanks.OOO00O00) < %tanks.OOO00O00) %tanks.OOO00O00 = $ifmatch
  OOO00000 385 %tanks.OOO00O00
}
alias -l O0OO0O00 {
  if (* !iswm $window(@Tanks)) return
  var %tanks.OO0O0OOO = %tanks.OO00OOO0, %tanks.OOO00OOO, %tanks.O0O00OOO, %tanks.OOO0OO00 = $iif($numtok(%tanks.OO0O00O0,32) > 8,1,0)
  while (%tanks.OO0O0OOO) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) {
      if (%tanks.OOO0O000 [ $+ [ %tanks.OO0O0OOO ] ] > 0) %tanks.OOO00OOO = %tanks.OO0O0OOO %tanks.OOO00OOO
      else %tanks.O0O00OOO = %tanks.OO0O0OOO %tanks.O0O00OOO
    }
    dec %tanks.OO0O0OOO
  }
  %tanks.OO0O00O0 = %tanks.OOO00OOO %tanks.O0O00OOO
  if (%tanksautoscroll) && (%tanks.OO000OOO != %tanks.OO000OO0 %tanks.OO0O00O0) {
    %tanks.OO000OOO = %tanks.OO000OO0 %tanks.OO0O00O0
    %tanks.OO0O0OOO = $findtok(%tanks.OO0O00O0,%tanks.OO000OO0,1,32)
    while (%tanks.OO0O0OOO < $calc(%tanks.O0OO0O00 + 3)) {
      dec %tanks.O0OO0O00 %tanks.O0OOOOOO
    }
    while (%tanks.OO0O0OOO > $calc(%tanks.O0OO0O00 + 4)) || (%tanks.O0OO0O00 < 0) {
      inc %tanks.O0OO0O00 %tanks.O0OOOOOO
    }
  }
  var %tanks.OOO00O0O = $numtok(%tanks.OO0O00O0,32)
  while ($calc(9-%tanks.O0OOOOOO +%tanks.O0OO0O00) > %tanks.OOO00O0O) && (%tanks.O0OO0O00 > 0) {
    dec %tanks.O0OO0O00 %tanks.O0OOOOOO
  }
  if (%tanks.OOO0OO00 != $iif(%tanks.OOO00O0O > 8,1,0)) && (%tanks.OO000000 isin O000000O O00000OO O0000000) OOO00OOO
  drawrect -rfn @Tanks %tanks.15 1 0 312 320 57
  if (%tanks.O0O0O0O0) O0O0000O
  OO00OO0O
  var %tanks.O0O0OO0O = 1, %tanks.O00OO0OO = $O00OOOO0, %tanks.OO00000O = %tanks.0, %tanks.OOO0OO00 = %tanks.OOO0O000 [ $+ [ %tanks.OO000OO0 ] ]
  while (1) {
    var %tanks.OO0O0OOO = $gettok(%tanks.OO0O00O0,%tanks.O0O0OO0O,32)
    if (%tanks.OO0O0OOO) && (%tanks.OOO0O000 [ $+ [ %tanks.OO0O0OOO ] ] > 0) {
      if (%tanks.OO0O0OOO != %tanks.OO000OO0) && ($O00OOOO0(%tanks.OO0O0OOO) >= %tanks.OOO0OO00) && (%tanks.OOO0OO00 > 0) {
        if (%tanks.OO000O0O !& 1) && (%tanks.OO000000 isin O000000O O00000OO O0000000) OOO00OO0 %tanks.OO0O0OOO %tanks.4 !
        %tanks.OO00000O = %tanks.4
      }
      inc %tanks.O0O0OO0O
    }
    else break
  }
  %tanks.O0O0OO0O = 1
  while (1) {
    %tanks.OO0O0OOO = $gettok(%tanks.OO0O00O0,$calc(%tanks.O0OO0O00 + %tanks.O0O0OO0O),32)
    if (%tanks.O0O0OO0O <= 8) && (%tanks.OO0O0OOO) { }
    else break
    var %tanks.OOO00O0O = 10, %tanks.OO00O00O = %tanks.OOO0O000 [ $+ [ %tanks.OO0O0OOO ] ] , %tanks.O0O0OOO0 = $iif(%tanks.O0O0OO0O & 1,64,222), %tanks.O0O00000 = $calc(320+13*$int($calc((%tanks.O0O0OO0O -1)/2))), %tanks.OO0000OO = $iif(%tanks.OO0O0OOO == %tanks.OO000OO0,%tanks.OO00000O,$iif(%tanks.OO00O00O > %tanks.O00OO0OO,%tanks.0,%tanks.4)), %tanks.O0OO000O = $iif(%tanks.OO00OOOO [ $+ [ %tanks.OO0O0OOO ] ] && %tanks.OO00O00O > 0 || * iswm %tanks.OO0OO0OO [ $+ [ %tanks.OO0O0OOO ] ] || %tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] isnum,14,0)
    if (%tanks.OO0O0OOO == %tanks.OO000OO0) && (%tanks.OO00O00O > 0) drawrect -rfn @Tanks %tanks.OO0OO00O 1 $calc(10+%tanks.O0O0OOO0) $calc(%tanks.O0O00000 -6) 85 14
    drawrect -rnf @Tanks %tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] 1 $calc(%tanks.O0O0OOO0 -61) $calc(%tanks.O0O00000 -5) 69 12
    drawpic -cnt @Tanks 16711935 $calc(%tanks.O0O0OOO0 -61) $calc(%tanks.O0O00000 -5) 120 92 69 12 %tanksbmp
    if (%tanks.OO0O0OOO == %tanks.OO000OO0) && (%tanks.OO00O00O > 0) var %tanks.O000O0OO = %tanks.15, %tanks.OOO00000 = %tanks.OOO0O0O0
    else var %tanks.O000O0OO = %tanks.1, %tanks.OOO00000 = %tanks.1
    if (* iswm %tanks.OO0OO0OO [ $+ [ %tanks.OO0O0OOO ] ] ) %tanks.O000O0OO = %tanks.14
    if (%tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] isnum 0-4) {
      drawpic -cnt @Tanks 16711935 $calc(11+%tanks.O0O0OOO0) $calc(%tanks.O0O00000 -4) 180 104 12 10 %tanksbmp
      drawfill -srn @Tanks %tanks.O000O0OO 16777215 $calc(11+%tanks.O0O0OOO0) %tanks.O0O00000 $calc(15+%tanks.O0O0OOO0) %tanks.O0O00000 $calc(15+%tanks.O0O0OOO0) $calc(3+%tanks.O0O00000)
    }
    elseif (%tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] == 5) {
      drawpic -cnt @Tanks 16711935 $calc(11+%tanks.O0O0OOO0) $calc(%tanks.O0O00000 -4) 190 92 12 10 %tanksbmp
      drawfill -srn @Tanks %tanks.O000O0OO 16777215 $calc(11+%tanks.O0O0OOO0) %tanks.O0O00000 $calc(16+%tanks.O0O0OOO0) %tanks.O0O00000
    }
    elseif (%tanks.O0OO000O) && (%tanks.OO00OOOO [ $+ [ %tanks.OO0O0OOO ] ] ) {
      drawpic -cnt @Tanks 16711935 $calc(12+%tanks.O0O0OOO0) $calc(%tanks.O0O00000 -4) 192 104 10 10 %tanksbmp
      drawfill -srn @Tanks $iif(* iswm %tanks.OO0OO0OO [ $+ [ %tanks.OO0O0OOO ] ] ,%tanks.O000O0OO,%tanks.OOO00000) 16777215 $calc(13+%tanks.O0O0OOO0) %tanks.O0O00000
    }
    elseif (* iswm %tanks.OO0OO0OO [ $+ [ %tanks.OO0O0OOO ] ] ) {
      drawpic -cnt @Tanks 16711935 $calc(12+%tanks.O0O0OOO0) $calc(%tanks.O0O00000 -4) 192 82 10 10 %tanksbmp
      drawfill -srn @Tanks %tanks.O000O0OO 16777215 $calc(12+%tanks.O0O0OOO0) %tanks.O0O00000
    }
    drawtext -crn @Tanks %tanks.OOO00000 %tankschat.O000OO00 %tankschat.O00000O0 $calc(10+%tanks.O0OO000O + %tanks.O0O0OOO0 + %tankstahoma) $calc(%tanks.O0O00000 -6) $calc(83-%tanks.O0OO000O) 13 $O0O00OOO(%tanks.OO0O0OOO)
    if (%tanks.OO00O00O > 10) || (%tanks.OO000O0O & 1) {
      if (%tanks.OO00O00O < 1) %tanks.OO0000OO = %tanks.OO0O0O00
      elseif (%tanks.OO000O0O & 1) %tanks.OO0000OO = %tanks.0
      if (%tanks.O000OOO0) {
        dec %tanks.O0O0OOO0 56
        drawline -rn @Tanks %tanks.OO0000OO 1 %tanks.O0O0OOO0 %tanks.O0O00000 $calc(59+%tanks.O0O0OOO0) %tanks.O0O00000
        inc %tanks.O0O00000
        drawline -rn @Tanks %tanks.OO0000OO 1 %tanks.O0O0OOO0 %tanks.O0O00000 $calc(59+%tanks.O0O0OOO0) %tanks.O0O00000
      }
      else drawrect -rfn @Tanks %tanks.OO0000OO 1 $calc(%tanks.O0O0OOO0 -56) %tanks.O0O00000 59 2
    }
    else {
      :615fix
      if (%tanks.OOO00O0O) {
        drawfill -rn @Tanks $iif(%tanks.OO00O00O >= %tanks.OOO00O0O,%tanks.OO0000OO,%tanks.OO0O0O00) 0 %tanks.O0O0OOO0 %tanks.O0O00000
        dec %tanks.O0O0OOO0 6
        dec %tanks.OOO00O0O
        goto 615fix
      }
    }
    inc %tanks.O0O0OO0O
  }
  if (%tanks.O00O0OOO [ $+ [ %tanks.OO000OO0 ] ] !isnum) return
  var %tanks.OOO00O0O = 10, %tanks.OOO0OO00 = %tanks.OOO0O000 [ $+ [ %tanks.OO000OO0 ] ]
  drawrect -rfn @Tanks %tanks.O0OOOO0O 1 0 370 320 9
  if (%tanks.OOO0OO00 > 10) || (%tanks.OO000O0O & 1) {
    if (%tanks.OOO0OO00 < 1) %tanks.OO00000O = %tanks.O0O0000O
    elseif (%tanks.OO000O0O & 1) %tanks.OO00000O = %tanks.0
    drawrect -rfn @Tanks %tanks.OO00000O 1 1 372 318 5
    return
  }
  while (%tanks.OOO00O0O) {
    drawrect -rfn @Tanks $iif(%tanks.OOO0OO00 >= %tanks.OOO00O0O,%tanks.OO00000O,%tanks.O0O0000O) 1 $calc(32*%tanks.OOO00O0O -31) 372 30 5
    dec %tanks.OOO00O0O
  }
}
menu @Tanks�request {
  mouse:O00O0000
  leave:O00O0000
  sclick:{
    var %tanks.O0O0OOO0 = $click(@Tanks�request,$click(@Tanks�request,0)).x, %tanks.O0O00000 = $click(@Tanks�request,$click(@Tanks�request,0)).y
    if ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,16,24,39,15)) {
      close -@ @Tanks�request
      O00000OO
      sockopen tanks %tankstempip %tankstempport
    }
    elseif ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,64,24,31,15)) {
      close -@ @Tanks�request
      OOO0OOO0 decline
    }
  }
}
on *:close:@tanksO0000OO0:O0O00000
alias -l O0O000O0 {
  if ($1 == -) tokenize 32 $iif($2,0,1) $3-
  if ($version < 5.9) return $iif($1,[�]�,[��]�) $2-
  return $style($1) $2-
}
alias -l O0OO000O {
  if ($sock(tanks.*,0)) O000O00O O000O000 $1-
  %tanks.OO00OOOO [ $+ [ $1 ] ] = $2
  O0OO0O00
  O0OOOOO0 O0000O00 $O0O00OOO($1) votes $iif($2,to,not to) end the round
  if ($O0000OO0) {
    if ($ifmatch > 1) OOOO00OO
    else O0O0O000
    return 1
  }
}
alias -l O0OO00OO return " $+ $scriptdir $+ tanks.exe"
alias -l O0000O00 {
  if ($isid) {
    if ($1) return %tanks.O0000O00 [ $+ [ $1 ] ] %tanks.OOO0O00O [ $+ [ $1 ] ] %tanks.O00O00O0 [ $+ [ $1 ] ] %tanks.O00000O0 [ $+ [ $1 ] ] %tanks.O0O0O000 [ $+ [ $1 ] ] %tanks.OOO0O000 [ $+ [ $1 ] ] %tanks.OO0O0000 [ $+ [ $1 ] ] %tanks.O00O0OO0 [ $+ [ $1 ] ] %tanks.O0OOO000 [ $+ [ $1 ] ] %tanks.O000O000 [ $+ [ $1 ] ] %tanks.O00000OO [ $+ [ $1 ] ]
    return 0 0 0 0 0 0 0 0 0 0 0
  }
  %tanks.O0000O00 [ $+ [ $1 ] ] = $2
  %tanks.OOO0O00O [ $+ [ $1 ] ] = $3
  %tanks.O00O00O0 [ $+ [ $1 ] ] = $4
  %tanks.O00000O0 [ $+ [ $1 ] ] = $5
  %tanks.O0O0O000 [ $+ [ $1 ] ] = $6
  %tanks.OOO0O000 [ $+ [ $1 ] ] = $7
  %tanks.OO0O0000 [ $+ [ $1 ] ] = $8
  %tanks.O00O0OO0 [ $+ [ $1 ] ] = $9
  %tanks.O0OOO000 [ $+ [ $1 ] ] = $10
  %tanks.O000O000 [ $+ [ $1 ] ] = $11
  %tanks.O00000OO [ $+ [ $1 ] ] = $12
}
alias -l O0000O0O {
  var %tanks.O00O00OO = @Tanks�IP�addresses, %tanks.OOO00000 = $window(%tanks.O00O00OO).x $window(%tanks.O00O00OO).y
  if (* !iswm $window(@Tanks)) {
    close -@ %tanks.O00O00OO
    return
  }
  if ($version != 6.02) window -h @tanksO0000OO0
  var %tanks.OOO0OO00 = 420 $calc(36+16*$numtok(%tanks.OO0O00O0,32))
  if (* * iswm %tanks.OOO00000) {
    filter -wwcx %tanks.O00O00OO %tanks.O00O00OO
    window -fa %tanks.O00O00OO %tanks.OOO00000 %tanks.OOO0OO00
  }
  else window $iif(%tanksontop,-fzdok0,-fzdk0) %tanks.O00O00OO -1 -1 %tanks.OOO0OO00 Fixedsys 15
  aline %tanks.O00O00OO Server at %tanksip $+ : $+ %tanksport
  aline %tanks.O00O00OO -
  var %tanks.OO0O0OOO = %tanks.OO00OOO0
  :0
  if (%tanks.OO0O0OOO) {
    var %tanks.O0O0OO0O = $OO0O0O00(%tanks.OO0O0OOO)
    if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) && (%tanks.O0O0OO0O) iline %tanks.O00O00OO 3 $O0O00OOO(%tanks.OO0O0OOO) %tanks.O0O0OO0O
    dec %tanks.OO0O0OOO
    goto 0
  }
}
alias -l O0O0OO00 {
  .timertanks* off
  %tanksremove = %tanksid
  %tanksid = $ticks
  if ($version == 6.02) window -hp @tanksO0000OO0
  else {
    var %tanks.O0OO000O = $iif(%tanksnoxy || * * !iswm %tanksxy,-1 -1,%tanksxy)
    window -hBdfp +Ld @tanksO0000OO0 %tanks.O0OO000O 100 17
    window -h @tanksO0000OO0 %tanks.O0OO000O 100 17
  }
  window -hl @tanksO0000O00
  var %tanks.O0O0OOO0, %tanks.O0O00000, %tanks.O000O0OO = $scriptdir $+ tanks.bmp
  O000OOOO
  if ($pic(%tanks.O000O0OO).width $pic(%tanks.O000O0OO).height != 435 148) {
    OOOO0000 $iif($isfile(%tanks.O000O0OO),Incorrect Tanks file:,Tanks file missing:) tanks.bmp ( $+ $pic(%tanks.O000O0OO).width x $pic(%tanks.O000O0OO).height $+ )
    O0O00000
    downloadtanks
    return return
  }
  %tanksbmp = " $+ %tanks.O000O0OO $+ "
  %tanks.O0000000 = 30
  %tanks.O00OOOO0 = 10
  if (%tankstitle !isnum) %tankstitle = 15
  window -Bhpf +d @tanksO00000OO -1 -1 %tanks.O0000000 %tanks.O00OOOO0
  window -f @tanksO00000OO -1 -1 %tanks.O0000000 %tanks.O00OOOO0
  drawpic -c @tanksO00000OO 0 0 150 104 %tanks.O0000000 %tanks.O00OOOO0 %tanksbmp
  %tanks.O0O00O0O = 5 11 13 1 8 18 3 17 2 16 6
  %tankscolor = $O0O00O0O(%tankscolor)
  %tanksname = $O0OOOO0O(%tanksname,1)
  if (* !iswm %tanksserver) %tanksserver = %tanksname $+ 's�server
  %tanksserver = $O0OOOO0O(%tanksserver,0)
  window -hl @tanksO0000000
  window -hl @tanksO00000O0
  %tanks.O000O0OO = $scriptdir $+ tanks.ban
  if ($isfile(%tanks.O000O0OO)) loadbuf @tanksO0000000 " $+ %tanks.O000O0OO $+ "
  %tanks.O000O0OO = $scriptdir $+ tanks.ign
  if ($isfile(%tanks.O000O0OO)) loadbuf @tanksO00000O0 " $+ %tanks.O000O0OO $+ "
  if (%tanksskill !isnum 0-4) %tanksskill = 4
  if (%tankscwind !isnum 0-2) %tankscwind = 1
  if (%tanksmode !isnum 0-1) %tanksmode = 0
  if (%tanksexplosivemode !isnum 0-1) %tanksexplosivemode = 1
  %tanks.OO0OOO00 = %tanksfast
  if (%tanksinc !isin 1 5) %tanksinc = 5
  if (%tankslimit !isnum 1-999) %tankslimit = 10
  if (%tankslimitmode !isnum 0-2) %tankslimitmode = 1
  %tanks.OO000O0O = %tanksmode
  %tanks.O0O0O00O = %tanksexplosivemode
  %tanks.OOO0OOO0 = %tankscwind
  %tanks.OO0O0OO0 = 1
  %tanks.O0000OO0 = %tankslimit
  %tanks.O000000O = %tankslimitmode
  %tanks.OO00O0O0 = 1
  %tanks.OO000OO0 = 1
  %tanks.O00O0000 = 0
  %tanks.OO00OOO0 = 32
  %tanks.O0OO0O00 = 0
  %tanks.O0OOOOOO = 2
  if (%tanksplayerlimit !isnum 2-32) %tanksplayerlimit = 8
  %tankswidth = 641
  %tanksheight = 460
  %tanks.O0O00O00 = 20
  %tanks.O0OO0O0O = 311
  inc %tanksd
  if (%tanksd > $script(0)) %tanksd = 1
  %tanks.O0O0O0O0 = 0
  %tanks.O0OOOO00 = 21
  %tankschat.O00OO000 = 321
  %tankschat.O00OOO00 = 312
  %tankschat.O000OOOO = $calc(%tankswidth -15-%tankschat.O00OO000)
  %tankschat.O000O0O0 = $calc(%tanksheight -%tankschat.O00OOO00)
  %tankschat.O00O00OO = 11
  %tankschat.O00OO0OO = %tanks.15
  %tankschat.O0000O00 = %tanks.1
  %tankschat.O00000OO = %tanks.2
  %tankschat.O000OO0O = %tanks.8
  %tankschat.O000O0OO = 15000804
  %tankschat.O00O0OOO = 9342606
  %tankschat.O00O0O00 = %tankswidth - 15
  %tankschat.O00O000O = %tankschat.O00OOO00 + 15
  %tankschat.O00O0000 = %tankschat.O000O0O0 - 30
  %tankschat.O000O000 = %tanksheight - 15
  %tankschat.O0000O0O = 0
  %tankschat.O0000OO0 = 0
  OO00O0OO
  %tanks.O0OOO0OO = $iif(%tanksground isnum,%tanksground,%tanks.14)
  %tanks.O00OOO00 = $iif(%tankssky isnum,%tankssky,%tanks.15)
  %tanks.O0OOOOO0 = 11579568
  %tanks.OOO0O0O0 = 16777215
  %tanks.OO0OO00O = 0
  %tanks.OOO0OO0O = 7368816
  %tanks.O0OOOO0O = %tanks.8
  %tanks.O0O0000O = %tanks.1
  %tanks.OO0O0O00 = %tanks.8
  close -@ @Tanks @tanksO0000O0O
  var %tanks.OO0O0OOO = %tanks.OO00OOO0
  while (%tanks.OO0O0OOO) {
    O0000O00 %tanks.OO0O0OOO $O0000O00
    dec %tanks.OO0O0OOO
  }
}
alias tanks.chat OO0OOO0O $1-
on *:active:*:{
  if ($target == @Tanks) {
    if ($lactive == @tanksO0000OO0) return
    close -@ @Tanks�color @Tank�info
    if ($version != 6.02) O00OOO0O @Tanks
  }
  elseif ($istok(@tanksO0000000.@tanksO00000O0.@tanksO0000O00.@tanksO0000O0O.@tanksO00000OO.@tanksO0000OO0,$target,46)) {
    if ($target == @tanksO0000OO0) unset %tanks.O0O0O0OO
    .timertankshide -o 1 0 window -h $target
  }
  elseif (%tanks.O0O0O0OO) && ($version != 6.02) {
    unset %tanks.O0O0O0OO
    window -h @tanksO0000OO0
  }
}
alias -l O00OO0O0 {
  var %tanks.O00O00OO = @Downloading�Tanks
  if ($isid) return %tanks.O00O00OO
  if (* !iswm $window(%tanks.O00O00OO)) {
    sockclose downloadtanks
    return
  }
  tokenize 32 $sock(downloadtanks).mark
  if ($window(%tanks.O00O00OO).state != hidden) {
    drawrect -frn %tanks.O00O00OO 0 1 0 0 152 24
    drawrect -rn %tanks.O00O00OO $calc(+$2) 1 0 0 152 24
    drawrect -frn %tanks.O00O00OO 7368816 1 1 1 $calc(+$calc(150*$sock(downloadtanks).rcvd /$1)) 22
    drawtext -rn %tanks.O00O00OO 12632256 Fixedsys 15 8 4 Downloading Tanks
    drawdot %tanks.O00O00OO
  }
}
alias -l OOO000O0 {
  var %tanks.O0OO000O = %tanks.OO000O0O %tanks.O0O0O00O %tanks.OOO0OOO0 %tanks.OO0O0OO0 %tanks.O0000OO0 %tanks.O000000O %tanks.OO00O0O0 %tanks.OO000OO0 %tanks.O00O0000
  if ($1) OO0OOOO0 $1 O00O0OOO %tanks.O0OO000O
  else O000O00O O00O0OOO %tanks.O0OO000O
}
alias -l O0OO00O0 OO0OOOOO action=remove
menu @Tanks,@tanksO0000OO0 {
  mouse:if ($menu != @tanksO0000OO0) O00O0O0O
  leave:if ($menu != @tanksO0000OO0) O00O0O0O
  sclick:{
    if ($menu == @tanksO0000OO0) O0OOOOOO %tanks.O0O0O0OO
    else O00O0O0O 0
  }
  dclick:{
    if ($menu != @tanksO0000OO0) {
      O00O0O0O 0
      if (%tanks.OO000000 == O00000O0) if ($inrect($mouse.x,$mouse.y,0,380,320,80)) OO00OOO0
    }
  }
  uclick:if ($menu != @tanksO0000OO0) O00O0O0O 1
  -
  $iif(%tanks.O00O0OOO [ $+ [ %tanks.O00O0O0O ] ] isnum,Vie&w scores):.timertanks.O0000OOO -o 1 0 O0000OOO
  -
  $iif(* !iswm $sock(tanks),&Server settings):{
    if ($dialog(tanksserver)) dialog -ev $ifmatch
    else dialog $iif(%tanksontop,-dmo,-dm) tanksserver tanksserver
  }
  $iif(* !iswm $sock(tanks),&Bots && local players):{
    if ($dialog(tanksbots)) dialog -ev $ifmatch
    else dialog $iif(%tanksontop,-dmo,-dm) tanksbots tanksbots
  }
  -
  $iif($sock(tanks.*,0),&Kick user...)
  .$iif(%tanks.O00O0OOO1 isnum,%tanks.O0OO0OO01):OO0O00OO O0000O00 1
  .$iif(%tanks.O00O0OOO2 isnum,%tanks.O0OO0OO02):OO0O00OO O0000O00 2
  .$iif(%tanks.O00O0OOO3 isnum,%tanks.O0OO0OO03):OO0O00OO O0000O00 3
  .$iif(%tanks.O00O0OOO4 isnum,%tanks.O0OO0OO04):OO0O00OO O0000O00 4
  .$iif(%tanks.O00O0OOO5 isnum,%tanks.O0OO0OO05):OO0O00OO O0000O00 5
  .$iif(%tanks.O00O0OOO6 isnum,%tanks.O0OO0OO06):OO0O00OO O0000O00 6
  .$iif(%tanks.O00O0OOO7 isnum,%tanks.O0OO0OO07):OO0O00OO O0000O00 7
  .$iif(%tanks.O00O0OOO8 isnum,%tanks.O0OO0OO08):OO0O00OO O0000O00 8
  .$iif(%tanks.O00O0OOO9 isnum,%tanks.O0OO0OO09):OO0O00OO O0000O00 9
  .$iif(%tanks.O00O0OOO10 isnum,%tanks.O0OO0OO010):OO0O00OO O0000O00 10
  .$iif(%tanks.O00O0OOO11 isnum,%tanks.O0OO0OO011):OO0O00OO O0000O00 11
  .$iif(%tanks.O00O0OOO12 isnum,%tanks.O0OO0OO012):OO0O00OO O0000O00 12
  .$iif(%tanks.O00O0OOO13 isnum,%tanks.O0OO0OO013):OO0O00OO O0000O00 13
  .$iif(%tanks.O00O0OOO14 isnum,%tanks.O0OO0OO014):OO0O00OO O0000O00 14
  .$iif(%tanks.O00O0OOO15 isnum,%tanks.O0OO0OO015):OO0O00OO O0000O00 15
  .$iif(%tanks.O00O0OOO16 isnum,%tanks.O0OO0OO016):OO0O00OO O0000O00 16
  .$iif(%tanks.O00O0OOO17 isnum,%tanks.O0OO0OO017):OO0O00OO O0000O00 17
  .$iif(%tanks.O00O0OOO18 isnum,%tanks.O0OO0OO018):OO0O00OO O0000O00 18
  .$iif(%tanks.O00O0OOO19 isnum,%tanks.O0OO0OO019):OO0O00OO O0000O00 19
  .$iif(%tanks.O00O0OOO20 isnum,%tanks.O0OO0OO020):OO0O00OO O0000O00 20
  .$iif(%tanks.O00O0OOO21 isnum,%tanks.O0OO0OO021):OO0O00OO O0000O00 21
  .$iif(%tanks.O00O0OOO22 isnum,%tanks.O0OO0OO022):OO0O00OO O0000O00 22
  .$iif(%tanks.O00O0OOO23 isnum,%tanks.O0OO0OO023):OO0O00OO O0000O00 23
  .$iif(%tanks.O00O0OOO24 isnum,%tanks.O0OO0OO024):OO0O00OO O0000O00 24
  .$iif(%tanks.O00O0OOO25 isnum,%tanks.O0OO0OO025):OO0O00OO O0000O00 25
  .$iif(%tanks.O00O0OOO26 isnum,%tanks.O0OO0OO026):OO0O00OO O0000O00 26
  .$iif(%tanks.O00O0OOO27 isnum,%tanks.O0OO0OO027):OO0O00OO O0000O00 27
  .$iif(%tanks.O00O0OOO28 isnum,%tanks.O0OO0OO028):OO0O00OO O0000O00 28
  .$iif(%tanks.O00O0OOO29 isnum,%tanks.O0OO0OO029):OO0O00OO O0000O00 29
  .$iif(%tanks.O00O0OOO30 isnum,%tanks.O0OO0OO030):OO0O00OO O0000O00 30
  .$iif(%tanks.O00O0OOO31 isnum,%tanks.O0OO0OO031):OO0O00OO O0000O00 31
  .$iif(%tanks.O00O0OOO32 isnum,%tanks.O0OO0OO032):OO0O00OO O0000O00 32
  $iif($sock(tanks.*,0),Edit &ban list):{
    if ($dialog(tanksban)) dialog -ev tanksban
    else dialog $iif(%tanksontop,-dmo,-dm) tanksban tanksban
  }
  $iif($sock(tanks),Edit &ignore list):{
    if ($dialog(tanksignore)) dialog -ev tanksignore
    else dialog $iif(%tanksontop,-dmo,-dm) tanksignore tanksignore
  }
  -
  $iif($sock(tanks.0),$O0O000O0(%tankspublic,&Public server)):{
    %tankspublic = $iif(%tankspublic,0,1)
    if (%tankspublic) O0OO0OOO
    else O0OO00O0
  }
  -
  &Commands
  .$iif($sock(tanks*,0) && %tanksip && %tanksport,Copy server IP &address && port to clipboard):clipboard %tanksip $+ : $+ %tanksport
  .$iif($sock(tanks.*,0),Change port for &server�[ [ $+ [ %tanksport ] $+ ] ]):OO0OOO0O /port 0
  .-
  .$iif($sock(tanks.*,0),&Ping user...)
  ..$iif(%tanks.O00O0OOO1 isnum && $sock(tanks.1),%tanks.O0OO0OO01):OO0OOOO0 1 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO2 isnum && $sock(tanks.2),%tanks.O0OO0OO02):OO0OOOO0 2 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO3 isnum && $sock(tanks.3),%tanks.O0OO0OO03):OO0OOOO0 3 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO4 isnum && $sock(tanks.4),%tanks.O0OO0OO04):OO0OOOO0 4 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO5 isnum && $sock(tanks.5),%tanks.O0OO0OO05):OO0OOOO0 5 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO6 isnum && $sock(tanks.6),%tanks.O0OO0OO06):OO0OOOO0 6 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO7 isnum && $sock(tanks.7),%tanks.O0OO0OO07):OO0OOOO0 7 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO8 isnum && $sock(tanks.8),%tanks.O0OO0OO08):OO0OOOO0 8 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO9 isnum && $sock(tanks.9),%tanks.O0OO0OO09):OO0OOOO0 9 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO10 isnum && $sock(tanks.10),%tanks.O0OO0OO010):OO0OOOO0 10 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO11 isnum && $sock(tanks.11),%tanks.O0OO0OO011):OO0OOOO0 11 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO12 isnum && $sock(tanks.12),%tanks.O0OO0OO012):OO0OOOO0 12 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO13 isnum && $sock(tanks.13),%tanks.O0OO0OO013):OO0OOOO0 13 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO14 isnum && $sock(tanks.14),%tanks.O0OO0OO014):OO0OOOO0 14 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO15 isnum && $sock(tanks.15),%tanks.O0OO0OO015):OO0OOOO0 15 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO16 isnum && $sock(tanks.16),%tanks.O0OO0OO016):OO0OOOO0 16 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO17 isnum && $sock(tanks.17),%tanks.O0OO0OO017):OO0OOOO0 17 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO18 isnum && $sock(tanks.18),%tanks.O0OO0OO018):OO0OOOO0 18 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO19 isnum && $sock(tanks.19),%tanks.O0OO0OO019):OO0OOOO0 19 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO20 isnum && $sock(tanks.20),%tanks.O0OO0OO020):OO0OOOO0 20 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO21 isnum && $sock(tanks.21),%tanks.O0OO0OO021):OO0OOOO0 21 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO22 isnum && $sock(tanks.22),%tanks.O0OO0OO022):OO0OOOO0 22 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO23 isnum && $sock(tanks.23),%tanks.O0OO0OO023):OO0OOOO0 23 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO24 isnum && $sock(tanks.24),%tanks.O0OO0OO024):OO0OOOO0 24 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO25 isnum && $sock(tanks.25),%tanks.O0OO0OO025):OO0OOOO0 25 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO26 isnum && $sock(tanks.26),%tanks.O0OO0OO026):OO0OOOO0 26 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO27 isnum && $sock(tanks.27),%tanks.O0OO0OO027):OO0OOOO0 27 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO28 isnum && $sock(tanks.28),%tanks.O0OO0OO028):OO0OOOO0 28 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO29 isnum && $sock(tanks.29),%tanks.O0OO0OO029):OO0OOOO0 29 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO30 isnum && $sock(tanks.30),%tanks.O0OO0OO030):OO0OOOO0 30 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO31 isnum && $sock(tanks.31),%tanks.O0OO0OO031):OO0OOOO0 31 O000O00O $ctime
  ..$iif(%tanks.O00O0OOO32 isnum && $sock(tanks.32),%tanks.O0OO0OO032):OO0OOOO0 32 O000O00O $ctime
  .$iif($sock(tanks) || $sock(tanks.*,0) > 1,$iif($sock(tanks),&Ping server,Ping &all users)):O000O00O O000O00O $ctime
  .-
  .$iif($sock(tanks*,0),&List IP addresses):O0000O0O
  .-
  .$iif($sock(tanks) && %tanks.OOO0O000 [ $+ [ %tanks.O00O0O0O ] ] > 0,Change your &vote to end this round):O000O00O O000O000
  .$iif(* !iswm $sock(tanks) && %tanks.OO000000 isin O000000O O00000OO O0000000,&End this round):O0O0O000
  .$iif(* !iswm $sock(tanks) && %tanks.OO000000 isin O000000O O00000OO O0000000,En&d current game):OOOO00OO
  .-
  .$iif(* !iswm $sock(tanks),C&hange server name [ [ $+ [ %tanks.O0OO0OO00 ] $+ ] ]):OO0OOO0O /sname
  .$iif(%tanks.O00O0OOO [ $+ [ %tanks.O00O0O0O ] ] isnum && %tanks.O00O0O0O,Change &name [ [ $+ [ %tanks.O0OO0OO0 [ $+ [ %tanks.O00O0O0O ] ] ] $+ ] ]):O0O0O0OO
  .$iif(%tanks.O00O0OOO [ $+ [ %tanks.O00O0O0O ] ] isnum,Change &color):OO000O0O
  Syst&em
  .$O0O000O0(-,%tanksforget) &Remember increment setting between rounds:%tanksforget = $iif(%tanksforget,0,1)
  .-
  .$O0O000O0(-,%tanksnosound) &Play sounds:%tanksnosound = $iif(%tanksnosound,0,1)
  .-
  .$O0O000O0(%tanks.OO0OOO00) &Fast mode:%tanks.OO0OOO00 = $iif(%tanks.OO0OOO00,0,1) | %tanksfast = %tanks.OO0OOO00 | .timertanks.OO00O0O0 -e
  .-
  .$O0O000O0(%tanksautoscroll,&Automatically scroll names list to active player):%tanksautoscroll = $iif(%tanksautoscroll,0,1)
  .$O0O000O0(%tankstahoma,Use the &Tahoma font):OO00O0OO $iif(%tankstahoma,0,1)
  .$O0O000O0(%tankslog) &Log chat to tanks.log:%tankslog = $iif(%tankslog,0,1)
  .-
  .$O0O000O0(%tanksnoctcp,&Disable Tanks ctcp reply):%tanksnoctcp = $iif(%tanksnoctcp,0,1)
  .$O0O000O0(%tanksnolisten,&Ignore all Tanks requests):%tanksnolisten = $iif(%tanksnolisten,0,1)
  .-
  .$O0O000O0(-,%tanksnomenu) Show Tanks &menu in query, nicklist, and menubar:%tanksnomenu = $iif(%tanksnomenu,0,1)
  Win&dow
  .$O0O000O0($iif(%tankstitle & 1,1)) Show in titlebar $+ $chr(58) �&Round:%tankstitle = $iif(%tankstitle & 1,$bitoff(%tankstitle,1),$biton(%tankstitle,1)) | O0O00OO0
  .$O0O000O0($iif(%tankstitle & 2,1)) Show in titlebar $+ $chr(58) �&Frags:%tankstitle = $iif(%tankstitle & 2,$bitoff(%tankstitle,2),$biton(%tankstitle,2)) | O0O00OO0
  .$O0O000O0($iif(%tankstitle & 4,1)) Show in titlebar $+ $chr(58) �&Accuracy:%tankstitle = $iif(%tankstitle & 4,$bitoff(%tankstitle,3),$biton(%tankstitle,3)) | O0O00OO0
  .$O0O000O0($iif(%tankstitle & 8,1)) Show in titlebar $+ $chr(58) �&Server name:%tankstitle = $iif(%tankstitle & 8,$bitoff(%tankstitle,4),$biton(%tankstitle,4)) | O0O00OO0
  .-
  .$O0O000O0(-,%tanksnopop) &Un-minimize on your turn:%tanksnopop = $iif(%tanksnopop,0,1)
  .$O0O000O0(%tanksontop) &Window on top:%tanksontop = $iif(%tanksontop,0,1) | O00OOO0O @Tanks
  .$O0O000O0(-,%tanksnoxy) R&emember window position:%tanksnoxy = $iif(%tanksnoxy,0,1)
  .-
  .$iif($sock(tanks.*,0) && $version != 6.02,Hi&de this window):window -h @Tanks
  -
  Versio&n:abouttanks
  &Readme:tanksreadme
  -
  Ser&ver list:tanklist
}
alias -l OO00000O3 {
  var %tanks.O0O000OO = $1, %tanks.OO0O00OO = $2, %tanks.O00O00OO = $3, %tanks.OO0000OO = $4, %tanks.OOO0OO00 = $5, %tanks.O0OO000O = $6, %tanks.O0O00OO0 = $7, %tanks.O0OOO00O = $8
  var %tanks.O0O0OO0O = %tanks.OO000OO0 $O0000O00(%tanks.OO000OO0)
  if (%tanks.OO00O0O0 > 1) dec %tanks.OO0O0000 [ $+ [ %tanks.OO000OO0 ] ] $calc(25*%tanks.OO00O0O0)
  tokenize 32 $9-
  OO0OO000 1
  O0O0OOOO
  O0O00OO0
  drawdot @Tanks
  inc %tanks.O00000OO [ $+ [ %tanks.OO000OO0 ] ]
  if (%tanks.OO0OOO00 != 1) OO00OOOO $iif(%tanks.OO000OO0 != %tanks.O00O0O0O,g2,g1)
  if (%tanks.O0O0O00O) && (%tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ] > 90) var %tanks.O0O00OOO = $gettok(122 134 11 11.386 38 17 17.406 2 27 27.367 0 37 37.312 101 47 47,%tanks.OO00O0O0,46)
  elseif (%tanks.O0O0O00O) && (%tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ] > 80) var %tanks.O0O00OOO = $gettok(136 133 13 13.412 100 21 21.404 31 31 31.357 56 41 41.359 97 51 51,%tanks.OO00O0O0,46)
  else var %tanks.O0O00OOO = $gettok(369 39 15 15.410 123 25 25.398 62 35 35.312 56 45 45.312 0 55 55,%tanks.OO00O0O0,46)
  var %tanks.OOO000O0, %tanks.OOO00OO0 = $int($calc($gettok(%tanks.O0O00OOO,4,32) /2))
  if ($0) var %tanks.O0O000OO = $1, %tanks.OO0O00OO = $2, %tanks.O0O00OO0 = $3, %tanks.O0OOO00O = $4, %tanks.O0O000O0 = $5, %tanks.OOO00OOO = $6, %tanks.OO0OO000 = $7-
  else {
    var %tanks.OOO000O0, %tanks.O0O000O0 = %tanks.O0OO000O, %tanks.OOO00OOO = 0, %tanks.OO0OO000 = \, %tanks.O0000OOO = 0, %tanks.OOO00O0O = %tanks.OO00OOO0
    while (%tanks.OOO00O0O) {
      if (%tanks.O00O0OOO [ $+ [ %tanks.OOO00O0O ] ] isnum) {
        if (%tanks.OOO0O000 [ $+ [ %tanks.OOO00O0O ] ] > 0) {
          inc %tanks.O0000OOO
          if ($sqrt($calc((%tanks.O0000O00 [ $+ [ %tanks.OOO00O0O ] ] -%tanks.O0O00OO0)^2+(1.132-0.004*%tanks.OOO00OO0)*(%tanks.OOO0O00O [ $+ [ %tanks.OOO00O0O ] ] -5.75-%tanks.O0OOO00O)^2)) <= $calc(9.25+%tanks.OOO00OO0)) %tanks.OO0OO000 = %tanks.OOO00O0O %tanks.OO0OO000
        }
      }
      dec %tanks.OOO00O0O
    }
    if (%tanks.OOO0OOO0 > 1) {
      if (-99 == %tanks.O00O0000) %tanks.O00OOOOO = %tanks.O00O0000 + $rand(0,20)
      elseif (99 == %tanks.O00O0000) %tanks.O00OOOOO = %tanks.O00O0000 - $rand(0,20)
      else %tanks.O00OOOOO = $calc($rand(0,40)-20+%tanks.O00O0000)
      if (-99 > %tanks.O00OOOOO) %tanks.O00OOOOO = $ifmatch
      elseif (99 < %tanks.O00OOOOO) %tanks.O00OOOOO = $ifmatch
      O000O00O O0000OO0 %tanks.O00OOOOO
    }
    %tanks.OOO00O0O = $numtok(%tanks.OO0OO000,32)
    while (%tanks.OOO00O0O) {
      if ($gettok(%tanks.OO0OO000,%tanks.OOO00O0O,32) != %tanks.OO000OO0) inc %tanks.OOO00OOO $calc(($iif(%tanks.OO0O0000 [ $+ [ %tanks.OO000OO0 ] ] < 150,3,1)+%tanks.O0000OOO)*%tanks.OO00O0O0)
      dec %tanks.OOO00O0O
    }
    var %tanks.O00OO0OO = %tanks.OOO0O000 [ $+ [ %tanks.OO000OO0 ] ]
    var %tanks.OO0OOOO0 = 1, %tanks.OO0OOO0O = 1
    %tanks.OOO00O0O = %tanks.OO00OOO0
    while (%tanks.OOO00O0O) {
      if (%tanks.O00O0OOO [ $+ [ %tanks.OOO00O0O ] ] isnum) {
        if (%tanks.OOO0O000 [ $+ [ %tanks.OOO00O0O ] ] < %tanks.O00OO0OO) %tanks.OO0OOOO0 = 0
        elseif (%tanks.OOO0O000 [ $+ [ %tanks.OOO00O0O ] ] > %tanks.O00OO0OO) %tanks.OO0OOO0O = 0
      }
      dec %tanks.OOO00O0O
    }
    if (%tanks.OO0OOO0O) inc %tanks.OOO00OOO $calc(6+%tanks.O0000OOO)
    elseif (%tanks.OO0OOOO0) inc %tanks.OOO00OOO $calc(11+%tanks.O0000OOO)
    else inc %tanks.OOO00OOO $calc(8+%tanks.O0000OOO)
    if (%tanks.OO0O0000 [ $+ [ %tanks.OO000OO0 ] ] >= 150) dec %tanks.OOO00OOO 6
    O000O00O O000OOOO %tanks.OO00O0O0 %tanks.O00O00O0 [ $+ [ %tanks.OO000OO0 ] ] %tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ] %tanks.O0O000OO %tanks.OO0O00OO %tanks.O0O00OO0 %tanks.O0OOO00O %tanks.O0O000O0 %tanks.OOO00OOO %tanks.OO0OO000 %tanks.O0O0OO0O
  }
  inc %tanks.OO0O0000 [ $+ [ %tanks.OO000OO0 ] ] %tanks.OOO00OOO
  dec %tanks.O0O000OO
  var %tanks.O0O0OOO0 = %tanks.O0O000OO - 1, %tanks.O0O00000 = %tanks.OO0O00OO - 1
  if (%tanks.OO0OOO00 != 1) {
    %tanks.OOO000O0 = $ticks
    while (1) {
      drawrect -rfn @Tanks %tanks.O00OOO00 1 %tanks.O0O0OOO0 %tanks.O0O00000 3 3
      %tanks.O0OO000O = $calc(($ticks -%tanks.OOO000O0)/85)
      if (%tanks.O0OO000O > %tanks.O0O000O0) %tanks.O0OO000O = %tanks.O0O000O0
      %tanks.O0O0OOO0 = $round($calc(%tanks.O0O000OO -1+%tanks.O0OO000O *(%tanks.OO0000OO +%tanks.O00O00OO *%tanks.O0OO000O)),5)
      %tanks.O0O00000 = $round($calc(%tanks.OO0O00OO -1-%tanks.O0OO000O *(%tanks.OOO0OO00 -4.9*%tanks.O0OO000O)),5)
      if (%tanks.O0OO000O < %tanks.O0O000O0) {
        drawpic -cnt @Tanks 16711935 %tanks.O0O0OOO0 %tanks.O0O00000 151 76 3 3 %tanksbmp
        drawdot @Tanks
      }
      else break
    }
  }
  if (%tanks.OO0OOO00) OO00O0O0
  %tanks.O0000O0O = %tanks.O0O000OO %tanks.OO0O00OO %tanks.OO0000OO %tanks.OOO0OO00 %tanks.O00O00OO $calc(%tankswidth -1) %tanks.O0O000O0 %tanks.O0O0OOO0 %tanks.O0O00000
  if (%tanks.OO0OOO00) OO0OO00O
  tokenize 32 %tanks.O0O00OOO
  var %tanks.O0O0OOO0 = $calc(%tanks.O0O00OO0 - %tanks.OOO00OO0 - 1), %tanks.O0O00000 = %tanks.O0OOO00O - %tanks.OOO00OO0, %tanks.O0OOO0O0 = $4
  if ($calc(%tanks.O0O00000 +%tanks.O0OOO0O0) >= %tanks.O0OO0O0O) %tanks.O0OOO0O0 = $calc(%tanks.O0OO0O0O -%tanks.O0O00000)
  drawpic -cnt @Tanks 16711935 %tanks.O0O0OOO0 %tanks.O0O00000 $1-3 %tanks.O0OOO0O0 %tanksbmp
  drawdot @Tanks
  if (\* iswm %tanks.OO0OO000) OO00OOOO h1
  else OO00OOOO h2
  OOO0O0O0 %tanks.O0O00OO0 %tanks.O0OOO00O
  if (%tanks.OO0OOO00) OO0OO00O
  inc %tanks.O000O000 [ $+ [ %tanks.OO000OO0 ] ] $iif(%tanks.OO000O0O & 1,1,%tanks.OO00O0O0)
  tokenize 32 %tanks.OO0OO000
  var %tanks.O0O0OOO0, %tanks.O0O00000, %tanks.OOO00O0O
  while ($1 isnum) {
    if (%tanks.OOO0O000 [ $+ [ $1 ] ] == 11) inc %tanks.O0O0O000 [ $+ [ $1 ] ] 5
    dec %tanks.OOO0O000 [ $+ [ $1 ] ] %tanks.OO00O0O0
    if (%tanks.OO000O0O & 1) %tanks.OOO0O000 [ $+ [ $1 ] ] = 0
    var %tanks.OO0O0OOO = $calc(%tanks.O0O0O000 [ $+ [ $1 ] ] -5*%tanks.OO00O0O0)
    if (%tanks.OO0O0OOO < 50) %tanks.OO0O0OOO = 50
    %tanks.O0O0O000 [ $+ [ $1 ] ] = %tanks.OO0O0OOO
    $iif($1 == %tanks.OO000OO0,dec,inc) %tanks.O0OOO000 [ $+ [ %tanks.OO000OO0 ] ] $iif(%tanks.OO000O0O & 1,1,%tanks.OO00O0O0)
    if (%tanks.OOO0O000 [ $+ [ $1 ] ] < 1) {
      $iif($1 == %tanks.OO000OO0,dec,inc) %tanks.O00O0OO0 [ $+ [ %tanks.OO000OO0 ] ]
      if (* !iswm $sock(tanks)) {
        if ($1 == %tanks.OO000OO0) var %tanks.O00OO0OO = |�� tried to put the pin back in|�� decided it was all too much|�� fell asleep on the controls|�� pushed the self-destruct button|�� disintegrated|�� pushed the wrong button|�� saw the light|�� crumbled|
        else var %tanks.O00OO0OO = |�� pokes ��� with a stick|�� showed ��� who's boss|�� pounded ��� into the ground|�� melted ���|�� blew ��� to bits|�� recycles ���|
        %tanks.O00OO0OO = $gettok(%tanks.O00OO0OO,$rand(1,$numtok(%tanks.O00OO0OO,124)),124)
        O000O00O O00O0O00 %tanks.OO000OO0 $1 %tanks.O00OO0OO
        O0OOOOO0 - O000O00O %tanks.OO000OO0 $1 %tanks.O00OO0OO
        if (%tanks.O000000O == 1) && (%tanks.O00O0OO0 [ $+ [ %tanks.OO000OO0 ] ] == %tanks.O0000OO0) && ($1 != %tanks.OO000OO0) {
          var %tanks.O0OO000O = %tanks.OO000OO0 %tanks.OO000OO0 �� hit the frag limit
          O000O00O O00O0O00 %tanks.O0OO000O
          O0OOOOO0 - O000O00O %tanks.O0OO000O
        }
      }
      %tanks.OO0O0OOO = -20
      while (%tanks.OO0O0OOO <= 20) {
        %tanks.OOO00O0O = %tanks.O0000O00 [ $+ [ $1 ] ] + %tanks.OO0O0OOO
        if (%tanks.OOO00O0O > 0) && (%tanks.OOO00O0O <= %tankswidth) {
          %tanks.O0O0OOO0 = %tanks.OOO00O0O - 1
          %tanks.O0O00000 = $line(@tanksO0000O0O,%tanks.OOO00O0O)
          drawline -rn @Tanks %tanks.O0OOO0OO 1 %tanks.O0O0OOO0 %tanks.O0O00000 %tanks.O0O0OOO0 %tanks.O0OO0O0O
          if ($rand(0,1)) drawline -rn @Tanks %tanks.O00O0OOO [ $+ [ $1 ] ] 1 %tanks.O0O0OOO0 $calc(%tanks.O0O00000 -$rand(1,2)) %tanks.O0O0OOO0 %tanks.O0O00000
        }
        inc %tanks.OO0O0OOO
      }
    }
    tokenize 32 $2-
  }
  %tanks.O000OO00 [ $+ [ %tanks.OO000OO0 ] ] = %tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ]
  %tanks.OO00O0O0 = 1
  O00OOOOO
  O0O0OOO0
}
alias tanksreadme {
  var %tanks.O000O0OO = $scriptdir $+ tanks.txt
  if ($isfile(%tanks.O000O0OO)) run " $+ %tanks.O000O0OO $+ "
  else run http://pages.cthome.net/pdufilie/irc/tanks.txt
}
alias -l OO00000O2 {
  var %tanks.O0OO000O = $6 + 0.0935, %tanks.OO0000OO = 10, %tanks.OOO00OOO = .0685
  while (1) {
    var %tanks.O0O0OOO0, %tanks.O0O00OO0 = $round($calc($1 +%tanks.O0OO000O *($4 +$3 *%tanks.O0OO000O)),0)
    if (%tanks.O0O00OO0 < 1) %tanks.O0O0OOO0 = 1
    elseif (%tanks.O0O00OO0 > %tankswidth) %tanks.O0O0OOO0 = %tankswidth
    else %tanks.O0O0OOO0 = %tanks.O0O00OO0
    var %tanks.O0OOO00O = $round($calc($2 -%tanks.O0OO000O *($5 -4.915*%tanks.O0OO000O)),0)
    if (%tanks.O0OOO00O < 0) %tanks.O0OOO00O = 0
    elseif (%tanks.O0OOO00O > %tanks.O0OO0O0O) %tanks.O0OOO00O = %tanks.O0OO0O0O
    if (%tanks.O0OOO00O >= %tanks.O0O00O00) {
      if (%tanks.O0OOO00O >= %tanks.O0OO0O0O) break
      if ($calc(1+%tanks.O0OOO00O) >= $line(@tanksO0000O0O,%tanks.O0O0OOO0)) break
      var %tanks.O0O0OO0O = 1
      :615fix
      var %tanks.OO0O0OOO = $gettok(%tanks.OO0O00O0,%tanks.O0O0OO0O,32)
      if (%tanks.OO0O0OOO) && (%tanks.OOO0O000 [ $+ [ %tanks.OO0O0OOO ] ] > 0) {
        if ($inrect(%tanks.O0O0OOO0,%tanks.O0OOO00O,$calc(%tanks.O0000O00 [ $+ [ %tanks.OO0O0OOO ] ] -7),$calc(%tanks.OOO0O00O [ $+ [ %tanks.OO0O0OOO ] ] -9),15,10)) goto 0
        inc %tanks.O0O0OO0O
        goto 615fix
      }
    }
    dec %tanks.OO0000OO
    if (%tanks.OO0000OO < 1) {
      .timertanks.OO00000O2 -o 1 0 OO00000O2 $1-5 %tanks.O0OO000O
      return
    }
    inc %tanks.O0OO000O %tanks.OOO00OOO
  }
  :0
  OO00000O3 $1-5 $calc(%tanks.O0OO000O -%tanks.OOO00OOO) %tanks.O0O00OO0 %tanks.O0OOO00O
}
alias -l O0O00OOO return $iif(* iswm %tanks.OO0OO0OO [ $+ [ $1 ] ] ,%tanks.OO0OO0OO [ $+ [ $1 ] ] ,%tanks.O0OO0OO0 [ $+ [ $1 ] ] )
on *:close:@tanksO0000O0O:O0O00000
alias -l O000OO00 {
  var %tanks.OO0000OO = $getdot(@Tanks�color,$1,$2), %tanks.O0O0OOO0 = $calc(20+8*%tanks.O0000000), %tanks.O0O00000 = $calc(8*%tanks.O00OOOO0 -53)
  if ($3 != 1) if (%tanks.OO0000OO == %tanks.15) return
  if ($1 < %tanks.O0O0OOO0) {
    if ($3) drawrect -rf @Tanks�color %tanks.OO0000OO 1 $calc(1+%tanks.O0O0OOO0) %tanks.O0O00000 62 62
    return $int($calc(($1 -10)/8)) $+ , $+ $int($calc(($2 -10)/8))
  }
  elseif ($3) drawrect -rf @Tanks�color %tanks.15 1 $calc(1+%tanks.O0O0OOO0) %tanks.O0O00000 62 62
}
alias -l O0OOO000 {
  OO0O00O0 close -@ $O00OO0O0
  if ($isfile($remove($O0OO00OO,"))) {
    OOO000OO Installing...
    .timertankserror -o 1 0 OOOO0000 An error occurred while downloading Tanks.
    run -n $O0OO00OO
    .timertankserror off
    O000O0OO 0 $window($O00OO0O0).state
    :error
  }
}
on *:close:@tanksO00000OO:O0O00000
alias -l tanklistmsg {
  sockclose tanklist
  if (* !iswm $dialog(tanklist)) return
  did -rz tanklist 1,9,5
  did -a tanklist 1 �
  did -a tanklist 1 � � $1-
  var %tanks.O0OO000O = rem
  if (version isin $1-) {
    %tanks.O0OO000O = /downloadtanks
    did -a tanklist 1 � � Double-click here to update the script.
    did -a tanklist 9 %tanks.O0OO000O
  }
  did -a tanklist 1 �
  did -a tanklist 9 %tanks.O0OO000O
  did -a tanklist 9 %tanks.O0OO000O
  did -a tanklist 9 %tanks.O0OO000O
}
on *:sockread:downloadtanks:{
  while (1) {
    if ($sockerr) {
      OOO000OO Error $sockerr |Error $sockerr when downloading Tanks
      return
    }
    tokenize 32 $sock($sockname).mark
    if ($2 != 0) break
    var %tanks.O0OO000O
    sockread %tanks.O0OO000O
    if ($sockbr) {
      if (Content-Length: * iswm %tanks.O0OO000O) sockmark $sockname $gettok(%tanks.O0OO000O,2,32) $2
      elseif (* !iswm %tanks.O0OO000O) {
        sockmark $sockname $1 $rand(1,16777215)
        break
      }
    }
  }
  while (1) {
    if (* !iswm $sock($sockname)) return
    sockread 4096 &b
    if ($sockbr !isnum 1-) return
    O00OO0O0
    bwrite $O0OO00OO -1 -1 &b
  }
}
on *:dialog:tanksserver:init,sclick:*:{
  if ($devent == init) OO000000
  elseif ($did == 1) || ($did == 3) {
    %tanks.OO000O0O = $did(tanksserver,4).state
    %tanksmode = %tanks.OO000O0O
    %tanks.O0O0O00O = $did(tanksserver,13).state
    %tanksexplosivemode = %tanks.O0O0O00O
    %tanks.O000000O = $did(tanksserver,5).state * $did(tanksserver,6,1).sel
    %tankslimitmode = %tanks.O000000O
    if ($int($did(tanksserver,7)) isnum 1-999) %tanks.O0000OO0 = $ifmatch
    else %tanks.O0000OO0 = 10
    %tankslimit = %tanks.O0000OO0
    %tanks.OOO0OOO0 = $did(tanksserver,8,1).sel - 1
    %tankscwind = %tanks.OOO0OOO0
    if ($int($did(tanksserver,9)) isnum 2-32) %tanksplayerlimit = $ifmatch
    else %tanksplayerlimit = 8
    %tanksallowclones = $did(tanksserver,12).state
    OO000000
    if ($window(@Tanks)) {
      O0O00OO0
      O00OOOOO
      OO00OO00
      O0OOO00O
      O0OO0O00
      OO0OO000
      drawdot @Tanks
    }
    OOO000O0
    O0OO0OOO
  }
  elseif ($did == 5) did $iif($did(tanksserver,5).state,-e,-b) tanksserver 6,7
  elseif ($did isnum 10-11) {
    %tanksplayerlimit = $did(tanksserver,9)
    if (%tanksplayerlimit !isnum) %tanksplayerlimit = 8
    $iif($did == 10,dec,inc) %tanksplayerlimit
    if (%tanksplayerlimit < 2) %tanksplayerlimit = 2
    elseif (%tanksplayerlimit > 32) %tanksplayerlimit = 32
    did -o tanksserver 9 1 %tanksplayerlimit
  }
}
alias -l OOO00O00 {
  var %tanks.O0O0OOO0 = $1 - 1
  drawline -rn @Tanks %tanks.O00OOO00 1 %tanks.O0O0OOO0 %tanks.O0O00O00 %tanks.O0O0OOO0 $2
  drawline -rn @Tanks %tanks.O0OOO0OO 1 %tanks.O0O0OOO0 $2 %tanks.O0O0OOO0 %tanks.O0OO0O0O
  rline @tanksO0000O0O $1 $2
}
dialog tanksname {
  title "Tanks name"
  option dbu
  size -1 -1 120 28
  text "Enter your new name:", 5, 4 3 54 7
  edit "", 2, 4 13 56 11, autohs result
  button "&Ok", 3, 63 13 25 11, ok default
  button "&Cancel", 4, 91 13 25 11, cancel
  list 1,0 0 0 0,disablehide
}
alias tanksdi %tanksmode = 1 | tanksd $1-
alias OOO0O00O {
  if (* !iswm $sock(tanks)) return
  var %tanks.OO0O0OOO = 0
  while (%tanks.OO0O0OOO <= %tanks.OO00OOO0) {
    %tanks.OO0OO0OO [ $+ [ %tanks.OO0O0OOO ] ] =
    var %tanks.O0O0OOO0 = $line(@tanksO00000O0,0)
    :615fix
    if (%tanks.O0O0OOO0) && (%tanks.OO0O0OOO != %tanks.O00O0O0O) {
      tokenize 32 $line(@tanksO00000O0,%tanks.O0O0OOO0)
      if (n isin $2) && ($3 iswm %tanks.O0OO0OO0 [ $+ [ %tanks.OO0O0OOO ] ] ) %tanks.OO0OO0OO [ $+ [ %tanks.OO0O0OOO ] ] = $1
      elseif (n !isin $2) && ($3 iswm $OO0O0O00(%tanks.OO0O0OOO)) %tanks.OO0OO0OO [ $+ [ %tanks.OO0O0OOO ] ] = $1
      dec %tanks.O0O0OOO0
      goto 615fix
    }
    inc %tanks.OO0O0OOO
  }
}
on *:appactive:{
  if ($version != 6.02) && (%tanks.O0O0O0OO) {
    unset %tanks.O0O0O0OO
    window -h @tanksO0000OO0
  }
}
alias -l O00000O0 {
  var %tanks.OOO0OO00, %tanks.OOO00O0O = %tanks.OO00OOO0
  while (%tanks.OOO00O0O) {
    %tanks.OOO0OO00 = tanks. $+ %tanks.OOO00O0O
    if ($sock(%tanks.OOO0OO00)) && (%tanks.O00O0OOO [ $+ [ %tanks.OOO00O0O ] ] isnum) && ($1 != %tanks.OOO00O0O) sockwrite -tn %tanks.OOO0OO00 $2-
    dec %tanks.OOO00O0O
  }
}
alias -l OO0OOOO0 {
  var %tanks.OOO0OO00 = tanks. $+ $1
  if ($sock(%tanks.OOO0OO00)) && ($1) && (%tanks.O00O0OOO [ $+ [ $1 ] ] isnum) sockwrite -tn %tanks.OOO0OO00 $2-
}
on *:keydown:@Tanks�IP�addresses:*:if (* iswm $keychar) O0000O0O
alias -l O0OOOOO0 {
  if (* !iswm $window(@Tanks)) return
  window -g3 @Tanks
  var %tanks.OOO00OOO, %tanks.O0O00OOO = 1
  if ($1 == -) {
    %tanks.O0O00OOO = 0
    tokenize 32 $2-
  }
  if ($1 == O0000OOO) {
    %tanks.OOO00OOO = 1
    tokenize 32 O0000O00 $2-
  }
  if ($1 == O000O00O) tokenize 32 O0000O00 $replace($4-,���,$O0O00OOO($3),��,$O0O00OOO($2))
  var %tanks.OOO00O00 = $1, %tanks.OO0000OO, %tanks.O0OO000O, %tanks.OOO00O0O, %tanks.O00O00OO = $calc(%tankschat.O000OOOO -19-%tankstahoma)
  if (%tanks.OOO00O00 == O0000O00) %tanks.O0OO000O = $2-
  else %tanks.OO0000OO = $2
  if (%tanks.OOO00O00 == O000O000) {
    %tanks.O0OO000O = $3 joined the game
    if ($4 isin (Admin)(Bot)) %tanks.O0OO000O = %tanks.O0OO000O $4
    elseif ($4) %tanks.O0OO000O = %tanks.O0OO000O (IP: $4 $+ )
  }
  elseif (%tanks.OOO00O00 == O000000O) {
    if ($istok(/me /em,$4,32)) {
      %tanks.OOO00O00 = O000O0OO
      %tanks.O0OO000O = (pmsg) -> * $+ $3 $+ * $5-
    }
    else %tanks.O0OO000O = (pmsg) -> * $+ $3 $+ * $4-
  }
  elseif ($istok(O0000O0O O000OO00,%tanks.OOO00O00,32)) {
    if ($istok(/me /em,$4,32)) {
      %tanks.OOO00O00 = O00000O0
      %tanks.O0OO000O = * $3 $5-
    }
    else %tanks.O0OO000O = < $+ $3 $+ > $4-
    if ($1 == O000OO00) {
      if (%tanks.OOO00O00 == O00000O0) %tanks.OOO00O00 = O000O0OO
      %tanks.O0OO000O = (pmsg) %tanks.O0OO000O
      OOO0O0OO 1
    }
    if ($3 === $O0O00OOO(0)) %tanks.O0OO000O = (Server) %tanks.O0OO000O
  }
  elseif (%tanks.OOO00O00 == O00000OO) %tanks.O0OO000O = $3 renamed to $4
  elseif (%tanks.OOO00O00 == O000O0O0) {
    %tanks.OO0000OO = %tanks.OO0000OO $4
    %tanks.O0OO000O = $3 changed color
  }
  elseif (%tanks.OOO00O00 == O0000OO0) {
    %tanks.O0OO000O = $3 left the game $4- %tanks.O0OO0OOO
    if (* !iswm $3) return
  }
  elseif (%tanks.OOO00O00 == O0000000) %tanks.O0OO000O = $3 was kicked out $4- %tanks.O0OO0OOO
  %tanks.O0OO000O = $strip(%tanks.O0OO000O)
  if (%tankslog) && (%tanks.OOO00OOO != 1) {
    tokenize 32 %tanks.OO0000OO %tanks.O0OO000O
    var %tanks.OO0000O0 = $2-
    if (%tanks.OOO00O00 == O000O0O0) %tanks.OO0000O0 = $3-
    if (%tanks.OOO00O00 == O0000O00) %tanks.OO0000O0 = $1-
    if ($istok(O0000O0O O000000O O000OO00 O00000O0,%tanks.OOO00O00,32) != $true) %tanks.OO0000O0 = *** %tanks.OO0000O0
    write " $+ $scriptdir $+ tanks.log" $timestamp %tanks.OO0000O0
  }
  while ($len(%tanks.O0OO000O)) && (* iswm $remove(%tanks.O0OO000O,�)) {
    %tanks.OOO00O0O = 1
    while ($width($mid(%tanks.O0OO000O,1,%tanks.OOO00O0O),%tankschat.O000O00O,%tankschat.O00000O0,0,0) < %tanks.O00O00OO) && (%tanks.OOO00O0O <= $len(%tanks.O0OO000O)) {
      inc %tanks.OOO00O0O
    }
    if ($asc($mid(%tanks.O0OO000O,%tanks.OOO00O0O,1)) != 32) {
      dec %tanks.OOO00O0O
      var %tanks.OO0000O0 = $left(%tanks.O0OO000O,%tanks.OOO00O0O)
      if (%tanks.OOO00O0O < $len(%tanks.O0OO000O)) && ($numtok(%tanks.OO0000O0,32) > 2) %tanks.OOO00O0O = $pos(%tanks.OO0000O0,$chr(32),$count(%tanks.OO0000O0,$chr(32)))
    }
    O00OO0OO %tanks.OOO00O00 %tanks.OO0000OO $left(%tanks.O0OO000O,%tanks.OOO00O0O)
    if ($asc($mid(%tanks.O0OO000O,%tanks.OOO00O0O,1)) == 32) %tanks.O0OO000O = � $right(%tanks.O0OO000O,$calc(0-%tanks.OOO00O0O))
    else %tanks.O0OO000O = �� $+ $right(%tanks.O0OO000O,$calc(0-%tanks.OOO00O0O))
  }
  if (%tanks.O0O00OOO) O0OOO0OO
}
on *:sockopen:tanklist*:{
  if ($sockname !isin tanklistb) return
  if ($sockerr) {
    if (%tanksbackup) {
      unset %tanksbackup
      tanklistmsg Unable to connect.
    }
    else {
      %tanksbackup = 1
      socket tanklist tanks.mircscripts.org
      socket tanklistb tanks.ileet.net
    }
    return
  }
  if (* !iswm %tanksname) %tanksname = $O0OOOO0O(%tanksname,0)
  sockwrite -n $sockname GET /tanks.php?version= $+ $tanksversion(1) $+ &me= $+ $replace(%tanksname,%,$right(.%25,3),+,$right(.%2B,3),$chr(35),$right(.%23,3),&,$right(.%26,3),$chr(32),$right(.%20,3)) $+ &crc= $+ $crc($script) $+ & $+ %tankslistsend HTTP/1.0
  sockwrite -n $sockname IP: $ip
  sockwrite -n $sockname Tanks-server: %tanksserver
  sockwrite -n $sockname Version: $version
  sockwrite -n $sockname Accept: */*
  sockwrite -n $sockname Host: $sock(tanklist).mark
  sockwrite -n $sockname Connection: close
  sockwrite -n $sockname Cache-Control: no-cache
  sockwrite -n $sockname
  sockmark $sockname wait
  if ($sockname == tanklist) && (%tankslisting) && ($dialog(tanklist)) did -r tanklist 1,9,5
}
on *:dialog:tanksban:init,sclick,edit:*:{
  var %tanks.OOOO000O = $dname, %tanks.O0O0OOO0 = $did, %tanks.O000O0OO, %tanks.OOO0OO00
  if ($devent == init) || (%tanks.O0O0OOO0 == 12) {
    did -r %tanks.OOOO000O 1
    did -r %tanks.OOOO000O 2
    var %tanks.OO0O0OOO = %tanks.OO00OOO0
    while (%tanks.OO0O0OOO) {
      if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) {
        if ($sock(tanks. [ $+ [ %tanks.OO0O0OOO ] ] ).ip) {
          did -i %tanks.OOOO000O 2 1 $ifmatch
          did -i %tanks.OOOO000O 1 1 %tanks.O0OO0OO0 [ $+ [ %tanks.OO0O0OOO ] ]
        }
      }
      dec %tanks.OO0O0OOO
    }
  }
  if ($devent == init) {
    did -c %tanks.OOOO000O 4
    did -c %tanks.OOOO000O 2 1
    %tanks.O0O0OOO0 = 2
    did -rz %tanks.OOOO000O 8
    var %tanks.O0O0OO0O = $line(@tanksO0000000,0)
    while (%tanks.O0O0OO0O) {
      var %tanks.O0OO000O = $line(@tanksO0000000,%tanks.O0O0OO0O)
      if (? * !iswm %tanks.O0OO000O) did -az %tanks.OOOO000O 8 %tanks.O0OO000O
      dec %tanks.O0O0OO0O
    }
  }
  if (%tanks.O0O0OOO0 isnum 1-2) {
    did -c %tanks.OOOO000O $iif(%tanks.O0O0OOO0 == 1,3,4)
    did -u %tanks.OOOO000O $iif(%tanks.O0O0OOO0 == 2,3,4)
    %tanks.O000O0OO = %tanks.O0O0OOO0
  }
  if (%tanks.O0O0OOO0 isnum 3-4) && ($did(%tanks.OOOO000O,1,1).sel) %tanks.O000O0OO = $iif(%tanks.O0O0OOO0 == 3,1,2)
  if (%tanks.O000O0OO) {
    var %tanks.OO0000O0 = $did(%tanks.OOOO000O,%tanks.O000O0OO,1).sel
    did -c %tanks.OOOO000O $calc(3-%tanks.O000O0OO) %tanks.OO0000O0
    did -o %tanks.OOOO000O 5 1 $replace($did(%tanks.OOOO000O,%tanks.O000O0OO,%tanks.OO0000O0),�,$chr(32))
    did -o %tanks.OOOO000O 6 1 $replace($did(%tanks.OOOO000O,1,%tanks.OO0000O0),�,$chr(32)) @ $did(%tanks.OOOO000O,2,%tanks.OO0000O0)
  }
  if (%tanks.O0O0OOO0 == 9) {
    while ($did(%tanks.OOOO000O,8,1).sel) {
      did -dz %tanks.OOOO000O 8 $did(%tanks.OOOO000O,8,1).sel
    }
    %tanks.OOO0OO00 = 1
  }
  if (%tanks.O0O0OOO0 == 7) {
    var %tanks.O00OO0OO = $iif($did(%tanks.OOOO000O,3).state,Name:�,IP:�) $$deltok($replace($did(%tanks.OOOO000O,5),$chr(32),�),0,160) � ( $+ $did(%tanks.OOOO000O,6) $+ )
    var %tanks.O0O0OO0O = $did(%tanks.OOOO000O,8).lines
    while (%tanks.O0O0OO0O) {
      if ($did(%tanks.OOOO000O,8,%tanks.O0O0OO0O) == %tanks.O00OO0OO) return
      dec %tanks.O0O0OO0O
    }
    did -az %tanks.OOOO000O 8 %tanks.O00OO0OO
    %tanks.OOO0OO00 = 1
  }
  if (%tanks.OOO0OO00) {
    close -@ @tanksO0000000
    window -hl @tanksO0000000
    %tanks.OOO0OO00 = $did(%tanks.OOOO000O,8).lines
    while (%tanks.OOO0OO00) {
      aline @tanksO0000000 $did(%tanks.OOOO000O,8,%tanks.OOO0OO00)
      dec %tanks.OOO0OO00
    }
    savebuf @tanksO0000000 " $+ $scriptdir $+ tanks.ban"
    OOOO00O0
  }
}
alias -l O0OOO00O {
  tokenize 32 %tanks.OO000OO0 %tanks.O0O0O000 [ $+ [ %tanks.OO000OO0 ] ] %tanks.OO0O0000 [ $+ [ %tanks.OO000OO0 ] ]
  if (%tanks.OO000O0O & 1) tokenize 32 $1 100 $3
  if ($3 !isnum) return
  OOO00000 411 %tanks.O000OO00 [ $+ [ $1 ] ] $iif(%tanks.OO000O0O !& 1 && %tanks.O000OO00 [ $+ [ $1 ] ] > $2,1)
  OOO00000 424 $2
  OOO00000 440 $3 $iif(%tanks.OO000O0O & 1 || %tanks.OOO0O000 [ $+ [ $1 ] ] >= 10 && $3 < 50 || $3 < 30,1)
}
alias -l OO0OOO00 {
  .timertanks.OO00O0O0 -e
  .timertanks.OO00000O2 off
  unset %tanks.OO00OOOO* %tanks.O000OO00*
  if (%tanks.OO000000 == O0000O0O) return
  unset %tanks.OO000000
  var %tanks.O0O0OOO0 = 0, %tanks.OO0O0OOO = %tanks.OO00OOO0
  while (%tanks.OO0O0OOO) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) inc %tanks.O0O0OOO0
    dec %tanks.OO0O0OOO
  }
  if (%tanks.O0O0OOO0 < 2) {
    OOOO00OO
    return
  }
  if ($sock(tanks)) {
    %tanks.OO000000 = O0000O0O
    return
  }
  var %tanks.OOO00O0O = %tanks.OO00OOO0, %tanks.OOOO000O, %tanks.OO0O0OOO = $calc(300+25*%tanks.O0O0OOO0)
  if (%tanks.OO000O0O & 1) %tanks.OO0O0OOO = 0
  while (%tanks.OOO00O0O) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.OOO00O0O ] ] isnum) {
      %tanks.O0O0OOOO [ $+ [ %tanks.OOO00O0O ] ] = 0
      %tanks.OO0O0000 [ $+ [ %tanks.OOO00O0O ] ] = %tanks.OO0O0OOO
      if (%tanks.O000000O == 1) && (%tanks.O00O0OO0 [ $+ [ %tanks.OOO00O0O ] ] >= %tanks.O0000OO0) %tanks.OOOO000O = 1
      elseif (%tanks.O000000O == 2) && (%tanks.OO0O0OO0 > %tanks.O0000OO0) %tanks.OOOO000O = 1
    }
    dec %tanks.OOO00O0O
  }
  if (%tanks.OOOO000O) {
    unset %tanks.OO0O0000*
    OOOO00OO
    return
  }
  %tanks.O00O0000 = $calc($rand(0,198)-99)
  var %tanks.OOO0OO00, %tanks.OO0O0OOO = %tanks.OO00OOO0
  while (%tanks.OO0O0OOO) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) %tanks.OOO0OO00 = %tanks.OO0O0OOO %tanks.OOO0OO00
    dec %tanks.OO0O0OOO
  }
  var %tanks.OO0O0OOO = $numtok(%tanks.OOO0OO00,32), %tanks.OOO00O00, %tanks.O0OO000O = %tanks.OOO0OO00, %tanks.OOO0OO00
  while (%tanks.OO0O0OOO) {
    %tanks.OOO00O00 = $rand(1,$numtok(%tanks.O0OO000O,32))
    %tanks.OOO0OO00 = %tanks.OOO0OO00 $gettok(%tanks.O0OO000O,%tanks.OOO00O00,32)
    %tanks.O0OO000O = $deltok(%tanks.O0OO000O,%tanks.OOO00O00,32)
    dec %tanks.OO0O0OOO
  }
  var %tanks.OO0O0OOO = $numtok(%tanks.OOO0OO00,32), %tanks.O0O0OOO0 = $int($calc(%tankswidth / $numtok(%tanks.OOO0OO00,32))), %tanks.OOO00O00, %tanks.OOO00OO0 = $int($calc(%tanks.O0O0OOO0 /4))
  if ($calc((%tanks.O0O0OOO0 - 17) / 2) < %tanks.OOO00OO0) %tanks.OOO00OO0 = $ifmatch
  while (%tanks.OO0O0OOO) {
    %tanks.OOO00O0O = $int($calc(%tanks.O0O0OOO0 * %tanks.OO0O0OOO - %tanks.O0O0OOO0 / 2 + $rand(0,%tanks.OOO00OO0) - %tanks.OOO00OO0 / 2))
    if (%tanks.OOO00O0O < 9) %tanks.OOO00O0O = 9
    if ($calc(%tankswidth -8) <= %tanks.OOO00O0O) %tanks.OOO00O0O = $ifmatch
    %tanks.OOO00O00 = $calc(%tanks.OOO00O0O -8) %tanks.OOO00O00
    %tanks.O0000O00 [ $+ [ $gettok(%tanks.OOO0OO00,%tanks.OO0O0OOO,32) ] ] = %tanks.OOO00O0O
    dec %tanks.OO0O0OOO
  }
  var %tanks.OO0000O0 = 0, %tanks.OO0O0O0O = $rand($calc(50+%tanks.O0O00O00),$calc(%tanks.O0OO0O0O -80)), %tanks.O0O0OO0O = 0, %tanks.O0O0OOO0 = 1, %tanks.O0O00000, %tanks.OO0O0OOO = 1, %tanks.O0OO000O = $gettok(%tanks.OOO00O00,1,32)
  %tanks.OOOO0000 = %tanks.OO0O0O0O
  O0O00OO0 Generating land...
  while (%tanks.O0O0OOO0 <= %tankswidth) {
    if (%tanks.O0O0OOO0 >= %tanks.O0OO000O) {
      if (%tanks.O0O0OO0O) %tanks.OOOO0000 = %tanks.OOOO0000 %tanks.O0O00000 %tanks.O0O0OO0O
      %tanks.O0O0OO0O = 0
      %tanks.O0O00000 = 0
      %tanks.OO0000O0 = 16
      %tanks.OOO0O00O [ $+ [ $gettok(%tanks.OOO0OO00,%tanks.OO0O0OOO,32) ] ] = $int(%tanks.OO0O0O0O) - 1
      inc %tanks.OO0O0OOO
      %tanks.O0OO000O = $gettok(%tanks.OOO00O00,%tanks.OO0O0OOO,32)
    }
    if (%tanks.O0O0OO0O >= %tanks.OO0000O0) || (%tanks.O0O0OOO0 == %tankswidth) {
      if (%tanks.O0O0OO0O) %tanks.OOOO0000 = %tanks.OOOO0000 %tanks.O0O00000 %tanks.O0O0OO0O
      %tanks.O0O0OO0O = 0
      %tanks.O0O00000 = $calc($rand(0,16)/5-1.6)
      %tanks.OO0000O0 = $rand(12,36)
    }
    if (%tanks.O0O00000 < 0) && (%tanks.OO0O0O0O <= $calc(50+%tanks.O0O00O00)) {
      if (%tanks.O0O0OO0O) %tanks.OOOO0000 = %tanks.OOOO0000 %tanks.O0O00000 %tanks.O0O0OO0O
      %tanks.O0O0OO0O = 0
      %tanks.O0O00000 = $calc($rand(0,8)/5)
      %tanks.OO0000O0 = $rand(12,36)
    }
    if (%tanks.O0O00000 > 0) && (%tanks.OO0O0O0O >= $calc(%tanks.O0OO0O0O -50)) {
      if (%tanks.O0O0OO0O) %tanks.OOOO0000 = %tanks.OOOO0000 %tanks.O0O00000 %tanks.O0O0OO0O
      %tanks.O0O0OO0O = 0
      %tanks.O0O00000 = $calc(-$rand(0,8)/5)
      %tanks.OO0000O0 = $rand(12,36)
    }
    inc %tanks.OO0O0O0O %tanks.O0O00000
    inc %tanks.O0O0OO0O
    inc %tanks.O0O0OOO0
  }
  O0O00OO0
  OO0OO0O0
  if ($sock(tanks.*,0)) {
    var %tanks.OOO00000 = %tanks.OO00OOO0
    while (%tanks.OOO00000) {
      if (%tanks.O00O0OOO [ $+ [ %tanks.OOO00000 ] ] isnum) && (%tanks.OOO00000 != %tanks.O00O0O0O) O000000O %tanks.OOO00000
      dec %tanks.OOO00000
    }
  }
}
alias -l OOOO0000 echo $colour(i) -iat *** $1-
alias -l O00OO000 {
  drawpic -cnt @Tanks 16711935 206 409 202 26 110 23 %tanksbmp
  var %tanks.O0OO000O = $O00OOOO0
  if (%tanks.O0OO000O < %tanks.OO00O0O0) %tanks.O0OO000O = %tanks.OO00O0O0
  drawpic -cnt @Tanks 16711935 208 411 204 102 $calc(1+21*%tanks.O0OO000O) 19 %tanksbmp
  drawpic -cnt @Tanks 16711935 $calc(188+21*%tanks.OO00O0O0) 416 $iif(%tanks.OO000OO0 == %tanks.O00O0O0O,130 104,130 113) 20 9 %tanksbmp
}
alias -l O0O0OO0O {
  var %tanks.OO0000OO = %tanks.O00O0OOO [ $+ [ $1 ] ] , %tanks.O0O0OOO0 = %tanks.O0000O00 [ $+ [ $1 ] ] , %tanks.O0O00000 = %tanks.OOO0O00O [ $+ [ $1 ] ] , %tanks.OO00O0OO = -8, %tanks.O0O0OO00 = 9 + %tankswidth, %tanks.OOO00O0O = %tanks.OO00OOO0, %tanks.OOO0OO00 = %tanks.OOO0O000 [ $+ [ $1 ] ] , %tanks.OO0O0OOO = 120, %tanks.OOO00O00 = %tanks.O00O00O0 [ $+ [ $1 ] ]
  if (%tanks.OO0000OO isnum) && (%tanks.O0O0OOO0) { }
  else return
  while (%tanks.OOO00O0O) {
    if (%tanks.OOO0O000 [ $+ [ %tanks.OOO00O0O ] ] > 0) && (%tanks.O00O0OOO [ $+ [ %tanks.OOO00O0O ] ] isnum) && (%tanks.OOO00O0O != $1) {
      var %tanks.OOOO000O = %tanks.O0000O00 [ $+ [ %tanks.OOO00O0O ] ]
      if (%tanks.OOOO000O < %tanks.O0O0OOO0) && (%tanks.OOOO000O > %tanks.OO00O0OO) %tanks.OO00O0OO = %tanks.OOOO000O
      if (%tanks.OOOO000O > %tanks.O0O0OOO0) && (%tanks.OOOO000O < %tanks.O0O0OO00) %tanks.O0O0OO00 = %tanks.OOOO000O
    }
    dec %tanks.OOO00O0O
  }
  inc %tanks.OO00O0OO 18
  dec %tanks.O0O0OO00 18
  if (%tanks.OOO0OO00 < 1) {
    if (%tanks.OO0OO0O0 [ $+ [ $1 ] ] ) return
    %tanks.OO0000OO = %tanks.O00OOO00
    %tanks.OO0OO0O0 [ $+ [ $1 ] ] = 1
  }
  else %tanks.OO0OO0O0 [ $+ [ $1 ] ] = 0
  var %tanks.OO0OOOOO = drawfill -srn @Tanks %tanks.O00OOO00 %tanks.OO0000OO, %tanks.O000O0OO = drawfill -srn @Tanks %tanks.OO0000OO 16777215
  %tanks.OO0OOOOO %tanks.O0O0OOO0 %tanks.O0O00000
  var %tanks.O0000OOO = %tanks.O0O0OOO0 - 6, %tanks.O0O000OO = %tanks.O0O0OOO0 + 5, %tanks.OOO000O0 = %tanks.O0O0OOO0, %tanks.O0O000O0 = %tanks.O0O0OOO0 + 1, %tanks.OOOO000O, %tanks.OOO00O0O = 1, %tanks.O0OO000O = drawline -rn @Tanks 16777215 1
  if (%tanks.OOO00O00 > $iif(%tanks.O0O0OOO0 > $calc(%tankswidth /2),89,90)) {
    inc %tanks.O0000OOO
    inc %tanks.O0O000OO
    dec %tanks.OOO000O0 2
    dec %tanks.O0O000O0 4
    inc %tanks.OO0O0OOO 15
    %tanks.OOO00O0O = -1
  }
  %tanks.OOO00O00 = $calc(%tanks.OOO00O00 *3.14159/180)
  var %tanks.OOO00OOO = $round($calc(6*$cos(%tanks.OOO00O00)),0), %tanks.O0O00OOO = $round($calc(7+6*$sin(%tanks.OOO00O00)),0), %tanks.OOO00000, %tanks.O0O0OO0O = -1
  if ($2) %tanks.OOO00000 = return $1
  :1
  inc %tanks.O0O0OO0O
  drawrect -rnf @Tanks %tanks.O00OOO00 1 $calc(%tanks.O0O0OOO0 -6) $calc(%tanks.O0O00000 -13) 11 12
  drawpic -cnt @Tanks 16711935 $calc(%tanks.O0O0OOO0 -8) $calc(%tanks.O0O00000 -9) %tanks.OO0O0OOO 122 15 10 %tanksbmp
  %tanks.O0OO000O $calc(%tanks.O0O000O0 +%tanks.OOO00OOO) $calc(1+%tanks.O0O00000 -%tanks.O0O00OOO) %tanks.O0O000O0 $calc(%tanks.O0O00000 -6)
  %tanks.O0OO000O $calc(%tanks.OOO000O0 +%tanks.OOO00O0O +%tanks.OOO00OOO) $calc(%tanks.O0O00000 -%tanks.O0O00OOO) %tanks.OOO000O0 $calc(%tanks.O0O00000 -6)
  %tanks.O0OO000O $calc(%tanks.OOO000O0 +%tanks.OOO00OOO) $calc(%tanks.O0O00000 -%tanks.O0O00OOO) %tanks.OOO000O0 $calc(%tanks.O0O00000 -7)
  %tanks.O000O0OO %tanks.O0O0OOO0 %tanks.O0O00000
  if (%tanks.OO0000OO == %tanks.O00OOO00) {
    var %tanks.OO0000O0 = 21, %tanks.O0OO00OO, %tanks.O0OOO0O0
    while (%tanks.OO0000O0) {
      %tanks.O0OO00OO = $calc(%tanks.O0O0OOO0 +%tanks.OO0000O0 -11)
      %tanks.O0OOO0O0 = %tanks.O0OO00OO - 1
      drawline -rn @Tanks %tanks.O0OOO0OO 1 %tanks.O0OOO0O0 $line(@tanksO0000O0O,%tanks.O0OO00OO) %tanks.O0OOO0O0 %tanks.O0OO0O0O
      dec %tanks.OO0000O0
    }
  }
  if (%tanks.O0O0OO0O) drawdot @Tanks
  if (%tanks.OOO0OO00 < 1) return
  var %tanks.OO0000O0 = $iif(%tanks.O0O00000 >= $line(@tanksO0000O0O,%tanks.O0000OOO),1), %tanks.OOO00OO0 = $iif(%tanks.O0O00000 >= $line(@tanksO0000O0O,%tanks.O0O000OO),1)
  if (%tanks.OO0000O0) && (%tanks.OOO00OO0) goto 3
  if (%tanks.OOO00OO0) && (%tanks.OOOO000O == O000000O) || ((%tanks.OO0000O0) && (%tanks.OOOO000O == O0000000)) {
    %tanks.OOO00000
    %tanks.OO0OOOOO %tanks.O0O0OOO0 %tanks.O0O00000
    inc %tanks.O0O00000
    goto 1
  }
  var %tanks.OO0O00OO = 0 + $line(@tanksO0000O0O,%tanks.O0O0OOO0)
  if ($calc(2+%tanks.O0O00000) > %tanks.OO0O00OO) goto 3
  if (%tanks.OOO00OO0) {
    if (%tanks.O0O0OOO0 > %tanks.OO00O0OO) {
      %tanks.OOO00000
      %tanks.OO0OOOOO %tanks.O0O0OOO0 %tanks.O0O00000
      dec %tanks.OOO000O0
      dec %tanks.O0O000O0
      dec %tanks.O0O0OOO0
      dec %tanks.O0000OOO
      dec %tanks.O0O000OO
      %tanks.OOOO000O = O0000000
      goto 1
    }
  }
  elseif (%tanks.OO0000O0) {
    if (%tanks.O0O0OOO0 < %tanks.O0O0OO00) {
      %tanks.OOO00000
      %tanks.OO0OOOOO %tanks.O0O0OOO0 %tanks.O0O00000
      inc %tanks.OOO000O0
      inc %tanks.O0O000O0
      inc %tanks.O0O0OOO0
      inc %tanks.O0000OOO
      inc %tanks.O0O000OO
      %tanks.OOOO000O = O000000O
      goto 1
    }
  }
  elseif ($calc(2+%tanks.O0O00000) < %tanks.OO0O00OO) {
    %tanks.OOO00000
    %tanks.OO0OOOOO %tanks.O0O0OOO0 %tanks.O0O00000
    inc %tanks.O0O00000 2
    goto 1
  }
  else {
    %tanks.OOO00000
    %tanks.OO0OOOOO %tanks.O0O0OOO0 %tanks.O0O00000
    inc %tanks.O0O00000
    goto 1
  }
  :3
  %tanks.O0000O00 [ $+ [ $1 ] ] = %tanks.O0O0OOO0
  %tanks.OOO0O00O [ $+ [ $1 ] ] = %tanks.O0O00000
}
on ^*:notice:tanks *:*:{
  if ($2 == request) {
    haltdef
    if (%tanksnolisten) return
    var %tanks.O0OO00O0 = OOOO0000 $nick wants to play a game of Tanks $+ $chr(44) but, %tanks.OOO00O0O = OOO0OOO0 0 $nick
    if ($tanksversion(1) < $3) {
      %tanks.O0OO00O0 you have an older version.  Get the newest by typing ' $+ $O0OO0000(/downloadtanks) $+ '.
      %tanks.OOO00O0O old
    }
    elseif ($tanksversion(1) != $3) {
      %tanks.O0OO00O0 they have an older version.
      %tanks.OOO00O0O new
    }
    elseif ($O00OOO00) {
      %tanks.O0OO00O0 Tanks is busy installing the newest version right now.
      %tanks.OOO00O0O installing
    }
    elseif ($sock(tanks)) || ($sock(tanks.*,0)) %tanks.OOO00O0O playing %tanksip %tanksport
    else {
      %tankstempip = $4
      %tankstempport = $5
      %tankstempnick = $nick
      O000OOOO
      var %tanks.O0OO000O = Will you join $nick $+ 's game of Tanks?, %tanks.O00O00OO = $width(%tanks.O0OO000O,fixedsys,15,0,0) + 16
      O00OOO0O @Tanks�request -1 -1 %tanks.O00O00OO 47 Fixedsys 15
      drawrect -rfn @Tanks�request %tanks.15 1 0 0 %tanks.O00O00OO 47
      drawtext -rbn @Tanks�request %tanks.1 %tanks.15 Fixedsys 15 8 8 %tanks.O0OO000O
      O00O0000
    }
    return
  }
  if ($nick == %tankstempnick) {
    if ($2 == playing) {
      if ($sock(tanks.*,0) > 1) || ($sock(tanks)) OOOO0000 $nick is already playing Tanks at $3 $+ : $+ $4 $+ .
      else {
        O00000OO
        tanks $3-4
      }
    }
    elseif ($2 == decline) OOOO0000 $nick declined your Tanks invitation.
    elseif ($2 == installing) OOOO0000 $nick is busy installing the new version of Tanks.
    elseif ($2 == ver) || ($2 == old) OOOO0000 $nick has an older version of Tanks.
    elseif ($2 == new) OOOO0000 $nick has a newer version of Tanks. Download the newest version by typing $O0OO0000(/downloadtanks) $+ .
  }
  haltdef
}
alias -l OO0OO000 {
  if (* !iswm $window(@Tanks)) return
  var %tanks.O0O00OOO = 1
  if ($1 == -) {
    tokenize 32 $2-
    %tanks.O0O00OOO = 0
  }
  %tanksxy = $window(@Tanks).x $window(@Tanks).y
  drawline -rn @Tanks %tanks.1 1 0 %tanks.O0OO0O0O %tankswidth %tanks.O0OO0O0O
  drawline -rn @Tanks %tanks.1 1 320 %tanks.O0OO0O0O 320 %tanksheight
  var %tanks.OO0O0OOO = %tanks.OO00OOO0, %tanks.OOO00O0O = 0, %tanks.OOO00O00 = 0, %tanks.OO0O0O0O = 0, %tanks.OO0000OO = 0
  while (%tanks.OO0O0OOO) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) {
      if (%tanks.OOO0O000 [ $+ [ %tanks.OO0O0OOO ] ] > 0) inc %tanks.OOO00O00
      if (%tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] isnum 0-4) inc %tanks.OO0O0O0O
      elseif (%tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] !isnum) inc %tanks.OO0000OO
      inc %tanks.OOO00O0O
    }
    dec %tanks.OO0O0OOO
  }
  if (%tanks.OOO00O0O < 2) unset %tanks.OO000000
  elseif (%tanks.OOO00O00 == 1) || (* !iswm %tanks.OO000000) && (* !iswm $sock(tanks)) %tanks.OO000000 = O00000O0
  if ($1) { }
  elseif (%tanks.OO000000 !isin O000000O O00000OO O0000000) {
    drawrect -rfn @Tanks %tanks.15 1 0 380 320 80
    if (%tanks.OO000000 == O00000O0) {
      if (%tanks.OO0000OO) OO00OOO0
      elseif (%tanks.OO0O0O0O == %tanks.OOO00O0O) && (%tanksstopbots) unset %tanks.OO000000
      else {
        drawtext -rn @Tanks %tanks.1 Fixedsys 15 56 404 Double-click here or press
        drawtext -rn @Tanks %tanks.1 Fixedsys 15 64 420 enter to start the game.
      }
      if (%tanks.O0O00OOO) drawdot @Tanks
    }
    return
  }
  var %tanks.OO0000OO = %tanks.O00O0OOO [ $+ [ %tanks.OO000OO0 ] ]
  if (%tanks.OO0000OO !isnum) return
  drawrect -rfn @Tanks %tanks.OO0000OO 1 0 380 320 80
  drawpic -cnt @Tanks 16711935 4 383 0 0 312 74 %tanksbmp
  O0O0O00O
  var %tanks.OO0O0OOO = %tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ] 
  OOO00000 398 %tanks.OO0O0OOO 0 $iif(%tanks.O0O0O00O && %tanks.OO0O0OOO > 80,$iif(%tanks.OO0O0OOO > 90,8421631,12632319))
  O0OOO00O
  O00OO000
  drawpic -cnt @Tanks 16711935 81 440 77 $iif(%tanksinc == 1,131,57) 16 17 %tanksbmp
  drawpic -cnt @Tanks 16711935 99 440 95 $iif(%tanksinc == 1,57,131) 16 17 %tanksbmp
  if (%tanks.O00O0O0O != %tanks.OO000OO0) {
    drawrect -rfn @Tanks %tanks.OO0000OO 1 0 380 117 80 206 383 110 25 206 433 110 24
    drawpic -cn @Tanks 5 409 202 26 110 23 %tanksbmp
    drawrect -rfn @Tanks 0 1 7 411 106 19
    var %tanks.OOO00O00 = $calc(+$round($calc(100*%tanks.O0OOO000 [ $+ [ %tanks.OO000OO0 ] ] /%tanks.O000O000 [ $+ [ %tanks.OO000OO0 ] ] ),0)) $+ %
    drawtext -rn @Tanks 16777215 %tankschat.O000OO00 %tankschat.O00000O0 $calc(11+%tankstahoma) $calc(414-%tankstahoma) Accuracy:
    drawtext -rn @Tanks 16777215 Fixedsys 15 $calc(108-$width(%tanks.OOO00O00,fixedsys,15,0,0)) 413 %tanks.OOO00O00
  }
  OOO00OOO
}
alias -l O0O000OO {
  if (%tankschat.O00O0OO0) return
  var %tanks.O0O0OOO0 = %tankschat.O0000O0O
  dec %tankschat.O0000O0O $1
  if (%tankschat.O0000O0O < 0) %tankschat.O0000O0O = 0
  if (%tanks.O0O0OOO0 != %tankschat.O0000O0O) O0OOO0OO
}
on *:sockclose:tanks:{
  close -@ @Tanks�request
  if ($window(@Tanks)) O0OOOOO0 O0000O00 The server closed the connection
  else OOOO0000 Tanks: Server closed the connection
  O00000OO
}
alias -l menu_ if (%tanksnomenu) return | return 1
dialog tanksignore {
  title "Tanks ignore list"
  option dbu
  size -1 -1 319 146
  box "Add ignore entry" 18,4 2 133 140
  text "Select a user to copy info below" 17,10 15 88 8
  button "Refresh" 12,102 11 29 12
  list 1,10 25 68 56, size
  list 2,81 25 50 56, size
  radio "Ignore by name" 3,20 84 51 10
  radio "Ignore by IP" 4,85 84 43 10
  text "Ignore mask:" 13,10 99 32 8
  edit "" 5,44 97 87 12, autohs
  text "Display as:" 19,10 113 32 8
  edit "" 11,44 111 87 12, autohs
  text "Comment:" 14,10 127 32 8
  edit "" 6,44 125 50 12, autohs
  button "Add ignore" 7,97 125 34 12, default
  box "Ignore list" 15,144 4 171 121
  list 8,150 14 159 91, sort size extsel hsbar vsbar
  button "&Remove selected" 9,255 108 54 12
  text "Wildcards may be used where necessary." 16,154 132 114 8, center
  button "Close" 10,285 129 30 13, cancel
}
alias -l OOOO000O {
  if ($sock(tanks)) return
  var %tanks.OO0O0O0O, %tanks.OO0O0OOO = $1, %tanks.O0O0OO0O = $2, %tanks.OOO00O0O = $3, %tanks.O0O0OOO0 = $line(@tanksO0000000,0)
  while (%tanks.O0O0OOO0) {
    tokenize 32 $line(@tanksO0000000,%tanks.O0O0OOO0)
    var %tanks.O0O00OOO = $iif($right($1,-1) != 0,(banned))
    if (n isin $1) && ($2 iswm %tanks.OOO00O0O) {
      %tanks.OO0O0O0O = 1
      if (%tanks.O0O00OOO) && ($3 != �) %tanks.OO0O0O0O = $iif($3 iswm %tanks.O0O0OO0O,1)
    }
    elseif (m isin $1) && ($2 iswm %tanks.O0O0OO0O) && (%tanks.OO0O0OOO) sockmark tanks. $+ %tanks.OO0O0OOO 1
    elseif (n !isin $1) && ($2 iswm %tanks.O0O0OO0O) %tanks.OO0O0O0O = 1
    if (%tanks.OO0O0O0O) {
      if (%tanks.OO0O0OOO) OO0O00OO $iif(%tanks.O0O00OOO || $4,O0000O00) %tanks.OO0O0OOO %tanks.O0O00OOO
      return 1
    }
    dec %tanks.O0O0OOO0
  }
}
alias -l O0O0O0OO {
  if ($dialog(tankschat)) {
    dialog -ev tankschat
    return
  }
  if ($dialog(tanksbots)) && ($timer(tanks.O0O0O0OO)) {
    dialog -ev tanksbots
    var %tanks.OOO00O0O = $dialog(tankschat,tanksname,-4)
    if ($did(tanksbots,22,1).sel) {
      var %tanks.O0OO000O = $did(tanksbots,20,$ifmatch), %tanks.OOO00O0O = $O0OOOO0O($left(%tanks.OOO00O0O,21),%tanks.O0OO000O)
      if (* iswm %tanks.OOO00O0O) O0OO0OO0 %tanks.O0OO000O %tanks.OOO00O0O
    }
    return
  }
  if ($0) var %tanks.OOO00O0O = $1-
  else var %tanks.OOO00O0O = $dialog(tankschat,tanksname,@Tanks)
  if (%tanks.O00O0O0O) %tanksname = %tanks.OOO00O0O
  else %tanksserver = %tanks.OOO00O0O
  %tanks.OOO00O0O = $O0OOOO0O($left(%tanks.OOO00O0O,64),%tanks.O00O0O0O)
  if (* iswm %tanks.OOO00O0O) {
    if ($sock(tanks)) O000O00O O00000O0 %tanks.OOO00O0O
    else O0OO0OO0 %tanks.O00O0O0O %tanks.OOO00O0O
  }
}
alias downloadtanks {
  if ($show) O0O00000
  $O00OOO00
  OOO000OO Downloading...
  if ($show) {
    var %tanks.O000O0OOlags = -BhaCdfopk0
    if ($version >= 6.20) %tanks.O000O0OOlags = -Bw0aCdfopk0
    window %tanks.O000O0OOlags +Ldf $O00OO0O0 -1 -1 152 24
  }
  else window -h $O00OO0O0
  O00OO0O0
  sockopen downloadtanks pages.cthome.net 80
}
alias -l OO0O0OOO {
  if ($1 == 1) {
    if (%tanks.O00O0OOO [ $+ [ $2 ] ] !isnum) && ($sock($3).ip == $4) sockclose $3
  }
  elseif ($1 == 2) {
    if ($window($2)) $3-
  }
  elseif ($1 == 3) {
    if ($window(@Tanks)) && (%tanks.OO000000 == O00000OO) %tanks.OO000000 = O0000000
  }
  elseif ($1 == 4) {
    OO00O0O0
    if ($window(@Tanks)) drawdot @Tanks
  }
}
alias -l OOO0OO0O {
  if ($dialog(tanksbots)) {
    did $iif($did(tanksbots,22,0).sel == 1,-e,-b) tanksbots 23
    did $iif($did(tanksbots,22,0).sel,-e,-b) tanksbots 24,25
  }
}
alias -l OOOO00O0 {
  tokenize 32 %tanks.OO0O00O0
  var %tanks.OOO00OO0 = $1-
  while ($1) {
    var %tanks.O0O0OO0O = $sock(tanks. [ $+ [ $1 ] ] ).ip
    if (%tanks.O0O0OO0O) OOOO000O $1 %tanks.O0O0OO0O %tanks.O0OO0OO0 [ $+ [ $1 ] ]
    tokenize 32 $2-
  }
  if (%tanks.OOO00OO0 != %tanks.OO0O00O0) O0OO0OOO
}
on *:load:tanks.init
dialog tanksban {
  title "Tanks ban list"
  option dbu
  size -1 -1 319 132
  box "Add a ban" 11,4 2 133 126
  text "Select a user to copy info below" 17,10 15 88 8
  button "Refresh" 12,102 11 29 12
  list 1,10 25 68 56, size
  list 2,81 25 50 56, size
  radio "Ban by name" 3,24 84 51 10
  radio "Ban by IP" 4,89 84 43 10
  text "Ban mask:" 13,10 99 26 8
  edit "" 5,38 97 61 12, autohs
  text "Comment:" 14,10 113 26 8
  edit "" 6,38 111 93 12, autohs
  button "Add ban" 7,102 97 29 12, default
  box "Ban list" 15,144 2 171 109
  list 8,150 12 159 79, sort size extsel hsbar vsbar
  button "&Remove selected" 9,255 94 54 12
  text "Wildcards may be used where necessary." 16,154 118 114 8, center
  button "Close" 10,285 115 30 13, cancel
}
alias -l O000000O {
  var %tanks.O0O00OOO = 1
  if ($1 == -) {
    %tanks.O0O00OOO = 0
    tokenize 32 $2-
  }
  else {
    OOO000O0 $1
    OO0OOOO0 $1 O000OO00 %tanks.O00O0000 $2
  }
  var %tanks.OO0O0OOO = %tanks.OO00OOO0, %tanks.O00O00OO = 1
  while (%tanks.OO0O0OOO) {
    OO0OOOO0 $1 O00OO0O0 $calc(+%tanks.OO00OOOO [ $+ [ %tanks.OO0O0OOO ] ] ) $iif(%tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] isnum,%tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] ,-) %tanks.OO0O0OOO $O0000O00(%tanks.OO0O0OOO)
    dec %tanks.OO0O0OOO
  }
  if (%tanks.O0O00OOO) {
    while (%tanks.O00O00OO <= %tankswidth) {
      OO0OOOO0 $1 O00O000O $line(@tanksO0000O0O,%tanks.O00O00OO) $line(@tanksO0000O0O,$calc(1+%tanks.O00O00OO)) $line(@tanksO0000O0O,$calc(2+%tanks.O00O00OO)) $line(@tanksO0000O0O,$calc(3+%tanks.O00O00OO)) $line(@tanksO0000O0O,$calc(4+%tanks.O00O00OO)) $line(@tanksO0000O0O,$calc(5+%tanks.O00O00OO)) $line(@tanksO0000O0O,$calc(6+%tanks.O00O00OO)) $line(@tanksO0000O0O,$calc(7+%tanks.O00O00OO)) $line(@tanksO0000O0O,$calc(8+%tanks.O00O00OO)) $line(@tanksO0000O0O,$calc(9+%tanks.O00O00OO))
      inc %tanks.O00O00OO 10
    }
  }
}
dialog tanksbots {
  title "Tanks bots and local players"
  size -1 -1 230 116
  option dbu
  box "Add local players", 1, 6 4 106 28
  edit "", 2, 13 14 59 12
  button "&Join", 3, 75 14 30 12
  box "Bots", 11, 6 40 106 65
  button "Skill 0", 12, 13 50 30 12
  button "Skill 1", 13, 44 50 30 12
  button "Skill 2", 14, 75 50 30 12
  button "Skill 3", 15, 13 65 30 12
  button "Skill 4", 16, 44 65 30 12
  button "R&andom", 17, 75 65 30 12
  check "Bots play when humans are gone" 18,13 80 92 10
  check "Bots play ''Left vs Right''", 19, 13 91 70 10
  box "Bots and local players", 21, 123 4 101 90
  list 22, 130 14 54 74, size extsel vsbar
  button "&Name...", 23, 187 14 30 12
  button "&Color...", 24, 187 28 30 12
  button "&Remove", 25, 187 42 30 12
  list 20, 187 56 30 32, hide size
  text "", 100, 0 0 0 0, hide
  button "Ok", 99, 194 100 30 12, ok
}
alias -l O0OO0000 return  $+ $colour(h) $+ $1- $+ 
on *:sockclose:tanks.*:if ($gettok($sockname,2,46) isnum) OO0O00OO $ifmatch
alias tanksi %tanksmode = 1 | tanks $1-
alias -l O00OOO00 if ($sock(downloadtanks).name) || ($timer(installtanks)) return return
on *:sockread:tanks.*:{
  var %tanks.OOO00OO0, %tanks.OO0O0OOO = $deltok($sockname,1,46), %tanks.O0O0OO0O = $sock($sockname).ip, %tanks.O00OO0OO = $sock($sockname).mark
  if ($sockerr) {
    if ($gettok($sockname,2,46) isnum) OO0O00OO $ifmatch
    O00O00OO $ifmatch $sockname sockread
    return
  }
  if (%tanks.OO0O0OOO !isnum) return
  while ($sock($sockname)) {
    sockread %tanks.OOO00OO0
    if ($sockbr !isnum 1-) return
    tokenize 32 %tanks.OOO00OO0
    if (O000OOO0 $tanksversion(1) * * iswm $1-) {
      if (* iswm %tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] ) {
        OO0O00OO O0000O00 %tanks.OO0O0OOO (Join error)
        return
      }
      O0OOO0O0 %tanks.OO0O0OOO $3 $O0OOOO0O($left($4,%tanks.O0OOOO00),%tanks.OO0O0OOO) %tanks.O0O0OO0O
      continue
    }
    elseif (* !iswm %tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] ) {
      OO000O00 $sockname ver $tanksversion(1)
      return
    }
    if (%tanks.OO000OO0 == %tanks.OO0O0OOO) && ($1 != O00OO0OO) OOO0O000
    if ($1 == O00OO00O) %tanks.O0O0OOOO [ $+ [ %tanks.OO0O0OOO ] ] = 1
    elseif ($1 == O00OOOOO) {
      if (%tanks.OO0O0OOO != %tanks.OO000OO0) continue
      O00000O0 %tanks.OO0O0OOO $1-
      OO0000O0 0 $2-
    }
    elseif ($1 == O000OOOO) {
      if (%tanks.OO0O0OOO != %tanks.OO000OO0) || (%tanks.O0O0OOOO [ $+ [ %tanks.OO0O0OOO ] ] != 1) continue
      %tanks.OO00O0O0 = $2
      %tanks.O00O00O0 [ $+ [ %tanks.OO0O0OOO ] ] = $3
      %tanks.O00000O0 [ $+ [ %tanks.OO0O0OOO ] ] = $4
      var %tanks.O0OO000O = %tanks.O00O000O [ $+ [ %tanks.OO0O0OOO ] ] - 1
      %tanks.O00O000O [ $+ [ %tanks.OO0O0OOO ] ] = $iif(%tanks.O0OO000O < 0,0,%tanks.O0OO000O)
      OO00000O
    }
    elseif ($1 == O00OOO00) OO0O00OO %tanks.OO0O0OOO $2-
    else {
      inc -z %tanks.OO000O00 [ $+ [ %tanks.OO0O0OOO ] ]
      if (%tanks.OO000O00 [ $+ [ %tanks.OO0O0OOO ] ] > 3) {
        inc -z %tanks.OO000O00 [ $+ [ %tanks.OO0O0OOO ] ] 10
        OO0OOOO0 %tanks.OO0O0OOO O00O0O00 0 0 Your message was not sent (too many too fast), please wait $duration($calc(%tanks.OO000O00 [ $+ [ %tanks.OO0O0OOO ] ] -3))
        continue
      }
    }
    if ($1 == O000O000) && (%tanks.OOO0O000 [ $+ [ %tanks.OO0O0OOO ] ] > 0) && (%tanks.OO000000 != O00000O0) && ($numtok(%tanks.OO0O00O0,32) > 1) O0OO000O %tanks.OO0O0OOO $iif(%tanks.OO00OOOO [ $+ [ %tanks.OO0O0OOO ] ] ,0,1)
    elseif ($1 == O000O00O) OO0OOOO0 %tanks.OO0O0OOO O00OO0OO $2
    elseif ($1 == O00OO0OO) {
      var %tanks.O0OO000O = $ctime - $2
      if (%tanks.O0OO000O) O0OOOOO0 O0000O00 Lag for %tanks.O0OO0OO0 [ $+ [ %tanks.OO0O0OOO ] ] is $duration(%tanks.O0OO000O)
      else O0OOOOO0 O0000O00 There is no lag for %tanks.O0OO0OO0 [ $+ [ %tanks.OO0O0OOO ] ]
    }
    elseif ($1 == O00OOOO0) O000OOO0 %tanks.OO0O0OOO $2
    elseif ($1 == O00000O0) {
      var %tanks.O0OO000O = $left($O0OOOO0O($2,%tanks.OO0O0OOO),%tanks.O0OOOO00)
      if (%tanks.O00OO0OO) OO0OOOO0 %tanks.OO0O0OOO O00000O0 %tanks.OO0O0OOO %tanks.O0OO000O
      else O0OO0OO0 %tanks.OO0O0OOO %tanks.O0OO000O
    }
    elseif ($1 == O00O00O0) && (%tanks.O00OO0OO != 1) {
      O0OOOOO0 O0000O0O %tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] %tanks.O0OO0OO0 [ $+ [ %tanks.OO0O0OOO ] ] $left($2-,200)
      O00000O0 %tanks.OO0O0OOO O00O00O0 %tanks.OO0O0OOO $left($2-,200)
    }
    elseif ($1 == O00000OO) {
      var %tanks.O0OO000O = 1
      while ($gettok($2,%tanks.O0OO000O,44) isnum) {
        var %tanks.OO0000OO = $gettok($2,%tanks.O0OO000O,44), %tanks.OOO0OO00 = tanks. $+ %tanks.OO0000OO, %tanks.OOO00O0O
        if (%tanks.O00OO0OO != 1) || (%tanks.OO0O0OOO == %tanks.OO0000OO) {
          if (* !iswm $sock(%tanks.OOO0OO00)) || (%tanks.OO0000OO == 0) %tanks.OOO00O0O = 1
          else OO0OOOO0 %tanks.OO0000OO O00000OO %tanks.OO0O0OOO $left($3-,200)
        }
        inc %tanks.O0OO000O
      }
      if (%tanks.OOO00O0O) O0OOOOO0 O000OO00 %tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] %tanks.O0OO0OO0 [ $+ [ %tanks.OO0O0OOO ] ] $3-
    }
  }
}
menu @Tanks�scores {
  &Refresh:.timertanks.O0000OOO -o 1 0 O0000OOO
}
alias -l OOO0OOO0 {
  if ($1 == 0) !.notice $2 tanks $3-
  else !.notice %tankstempnick tanks $1-
}
alias -l O0OOOO0O {
  var %tanks.OOO00O0O = $deltok($replace($remove($strip($1),$chr(1)),$chr(32),�),0,160), %tanks.O0O0OOO0 = 1
  while (%tanks.O0O0OOO0 <= $len(%tanks.OOO00O0O)) {
    if ($asc($mid(%tanks.OOO00O0O,%tanks.O0O0OOO0,1)) < 33) {
      %tanks.OOO00O0O = $left(%tanks.OOO00O0O,$calc(%tanks.O0O0OOO0 -1))
      break
    }
    inc %tanks.O0O0OOO0
  }
  if (* !iswm %tanks.OOO00O0O) {
    if (%tanks.O0OO0OO0 [ $+ [ $2 ] ] != $null) %tanks.OOO00O0O = $ifmatch
    elseif ($me) %tanks.OOO00O0O = $me
    else %tanks.OOO00O0O = Tank $+ $right($ticks,5)
  }
  if ($left(%tanks.OOO00O0O,-1) === Skill�) && ($right(%tanks.OOO00O0O,1) isnum 0-4) && (%tanks.O00O0O00 [ $+ [ $2 ] ] != $right(%tanks.OOO00O0O,1)) %tanks.OOO00O0O = %tanks.OOO00O0O $+ $rand(0,9)
  %tanks.O0O0OOO0 = 0
  while (%tanks.O0O0OOO0 <= %tanks.OO00OOO0) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.O0O0OOO0 ] ] isnum) && (%tanks.OOO00O0O === %tanks.O0OO0OO0 [ $+ [ %tanks.O0O0OOO0 ] ] ) && (%tanks.O0O0OOO0 != $2) {
      %tanks.OOO00O0O = %tanks.OOO00O0O $+ $rand(0,9)
      %tanks.O0O0OOO0 = 0
      continue
    }
    inc %tanks.O0O0OOO0
  }
  return %tanks.OOO00O0O
}
alias -l O000OOOO {
  drawpic -c
  tokenize 32 15790320 0 8388608 32768 240 128 8388736 10526880 6316128 11579568 3158064 20644 15728640 16496 8421504 13684944 8388688 8411136 2121760
  close -@ @tanksO000000O
  if ($version < 5.71) window -pd @tanksO000000O
  else window -Bhp @tanksO000000O
  var %tanks.O0O0OOO0 = 0, %tanks.OO0000OO
  while ($1 isnum) {
    drawdot -r @tanksO000000O $1 0 1 1
    %tanks. [ $+ [ %tanks.O0O0OOO0 ] ] = $getdot(@tanksO000000O,1,1)
    tokenize 32 $2-
    inc %tanks.O0O0OOO0
  }
  close -@ @tanksO000000O
  if (%tanks.14 == %tanks.8) %tanks.8 = $rgb(128,128,0)
}
alias -l OO00OO00 {
  if (%tanks.OO000000 !isin O000000O O00000OO O0000000) return
  drawrect -rfn @Tanks %tanks.O00OOO00 1 0 0 %tankswidth %tanks.O0O00O00
  if (%tanks.OOO0OOO0 == 0) return
  var %tanks.OOOO000O = � $iif(%tanks.OOO0OOO0 == 2,Changing wind:,Wind:) $abs(%tanks.O00O0000) �, %tanks.O00OO0OO = $int($calc(%tankswidth /2)), %tanks.O0O0OOO0 = $int($calc(.5+(100+%tanks.O00O0000)/100*%tanks.O00OO0OO))
  if (%tanks.O00O0000 < 0) drawtext -rn @Tanks %tanks.OOO0OO0O Fixedsys 15 %tanks.O00OO0OO 4 %tanks.OOOO000O
  if (%tanks.O00O0000 > 0) drawtext -rn @Tanks %tanks.OOO0OO0O Fixedsys 15 $calc(%tanks.O00OO0OO -$width(%tanks.OOOO000O,fixedsys,15,0,0)) 4 %tanks.OOOO000O
  if (%tanks.O00O0000) {
    drawline -rn @Tanks %tanks.OOO0OO0O 1 %tanks.O00OO0OO 6 %tanks.O00OO0OO 17
    drawline -rn @Tanks %tanks.OOO0OO0O 1 %tanks.O00OO0OO 11 %tanks.O0O0OOO0 11
    drawtext -rn @Tanks %tanks.OOO0OO0O Fixedsys 15 $iif(%tanks.O00O0000 < 0,%tanks.O0O0OOO0,$calc(%tanks.O0O0OOO0 -7)) 4 $iif(%tanks.O00O0000 < 0,<,>)
  }
}
alias -l O0000OOO {
  if ($version != 6.02) window -h @tanksO0000OO0
  var %tanks.OOO00OOO = @tankscore, %tanks.O0O00OOO = @Tanks�scores, %tanks.OOO00O0O = $timer(tanks.O0000OOO), %tanks.OOO00000 = $window(%tanks.O0O00OOO).x $window(%tanks.O0O00OOO).y, %tanks.OOO00OO0 = $numtok(%tanks.OO0O00O0,32)
  close -@ %tanks.OOO00OOO
  window -hls %tanks.OOO00OOO
  var %tanks.OO0O0OOO = %tanks.OO00OOO0
  while (%tanks.OO0O0OOO) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) {
      var %tanks.OOO00O00 = $calc($round($calc(100*%tanks.O0OOO000 [ $+ [ %tanks.OO0O0OOO ] ] /%tanks.O000O000 [ $+ [ %tanks.OO0O0OOO ] ] ),0) +50000), %tanks.OOOO000O = $calc(%tanks.O0OOO000 [ $+ [ %tanks.OO0O0OOO ] ] +50000), %tanks.O0OO000O = $calc(%tanks.O00000OO [ $+ [ %tanks.OO0O0OOO ] ] +50000), %tanks.O000O0OO = $calc(%tanks.O00O0OO0 [ $+ [ %tanks.OO0O0OOO ] ] +50000)
      if (\ 50000 50000 50000 50000 \ != \ %tanks.OOO00O00 %tanks.OOOO000O %tanks.O0OO000O %tanks.O000O0OO \) %tanks.OOO00O0O = 1
      if ($sock(tanks.*,0)) || ($sock(tanks)) && (%tanks.OO000O0O !& 1) && (%tanks.O00000OO [ $+ [ %tanks.OO0O0OOO ] ] < 5) %tanks.OOO00O00 = 50000 !
      aline %tanks.OOO00OOO $str(!,$calc(6-$len($gettok(%tanks.OOO00O00,1,32)))) $+ %tanks.OOO00O00 $str(!,$calc(6-$len(%tanks.OOOO000O))) $+ %tanks.OOOO000O $str(!,$calc(6-$len(%tanks.O000O0OO))) $+ %tanks.O000O0OO $str(!,$calc(6-$len(%tanks.O0OO000O))) $+ %tanks.O0OO000O %tanks.OO0O0OOO
    }
    dec %tanks.OO0O0OOO
  }
  if ($line(%tanks.OOO00OOO,0)) && (%tanks.OOO00O0O) {
    %tanks.OOO00OO0 = 580 $calc(16 * $iif(%tanks.OOO00OO0 < 8,8,%tanks.OOO00OO0) + 20)
    if (* * iswm %tanks.OOO00000) {
      window -fa %tanks.O0O00OOO %tanks.OOO00000 %tanks.OOO00OO0
      filter -wwcx %tanks.O0O00OOO %tanks.O0O00OOO
    }
    else window $iif(%tanksontop,-fzdok0,-fzdk0) %tanks.O0O00OOO -1 -1 %tanks.OOO00OO0 Fixedsys 15
    while ($line(%tanks.OOO00OOO,0)) {
      %tanks.O0OO000O = $line(%tanks.OOO00OOO,1)
      tokenize 32 $remove(%tanks.O0OO000O,!)
      if (* ! * iswm %tanks.O0OO000O) %tanks.OOO00O00 = [Wait]
      else %tanks.OOO00O00 = $calc($1 -50000) $+ %
      %tanks.O0OO000O = iline %tanks.O0O00OOO 1 Accuracy: %tanks.OOO00O00 $+ ;�
      if (%tanks.OO000O0O !& 1) %tanks.O0OO000O = %tanks.O0OO000O Damage: $calc($2 -50000) $+ ;�
      %tanks.O0OO000O Frags: $calc($3 -50000) $+ ;� Turns: $calc($4 -50000) $+ ;� $O0O00OOO($5)
      dline %tanks.OOO00OOO 1
    }
    while (1) {
      aline %tanks.O0O00OOO  
      if ($line(%tanks.O0O00OOO,0) >= 9) break
    }
  }
  else close -@ %tanks.O0O00OOO
  close -@ %tanks.OOO00OOO
}
ctcp *:tanks:if ($server) && (%tanksnoctcp != 1) && ($calc($ctime -%tanksctime) > 60) ctcpreply $nick Tanks $tanksversion(1)
on *:close:@tanksO00000O0:O0O00000
on *:dialog:tanksignore:init,sclick,edit:*:{
  var %tanks.OOOO000O = $dname, %tanks.O0O0OOO0 = $did, %tanks.O000O0OO, %tanks.OOO0OO00
  if ($devent == init) || (%tanks.O0O0OOO0 == 12) {
    did -r %tanks.OOOO000O 1
    did -r %tanks.OOOO000O 2
    OOO0O00O
    var %tanks.OO0O0OOO = 0
    while (%tanks.OO0O0OOO <= %tanks.OO00OOO0) {
      if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) && (%tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] !isnum 0-4) {
        if ($OO0O0O00(%tanks.OO0O0OOO,1)) {
          var %tanks.O0OO000O = *!*@ $+ $ifmatch
          did -a %tanks.OOOO000O 1 %tanks.O0OO0OO0 [ $+ [ %tanks.OO0O0OOO ] ]
          did -a %tanks.OOOO000O 2 $gettok($mask(%tanks.O0OO000O,4),2,64)
        }
      }
      inc %tanks.OO0O0OOO
    }
  }
  if ($devent == init) {
    did -c %tanks.OOOO000O 4
    did -c %tanks.OOOO000O 2 1
    %tanks.O0O0OOO0 = 2
    did -rz %tanks.OOOO000O 8
    var %tanks.O0O0OO0O = $line(@tanksO00000O0,0)
    while (%tanks.O0O0OO0O) {
      var %tanks.O0OO000O = $line(@tanksO00000O0,%tanks.O0O0OO0O)
      if (? * !iswm %tanks.O0OO000O) did -az %tanks.OOOO000O 8 %tanks.O0OO000O
      dec %tanks.O0O0OO0O
    }
  }
  if (%tanks.O0O0OOO0 isnum 1-2) {
    did -c %tanks.OOOO000O $iif(%tanks.O0O0OOO0 == 1,3,4)
    did -u %tanks.OOOO000O $iif(%tanks.O0O0OOO0 == 2,3,4)
    %tanks.O000O0OO = %tanks.O0O0OOO0
  }
  if (%tanks.O0O0OOO0 isnum 3-4) && ($did(%tanks.OOOO000O,1,1).sel) %tanks.O000O0OO = $iif(%tanks.O0O0OOO0 == 3,1,2)
  if (%tanks.O000O0OO) {
    var %tanks.OO0000O0 = $did(%tanks.OOOO000O,%tanks.O000O0OO,1).sel
    did -c %tanks.OOOO000O $calc(3-%tanks.O000O0OO) %tanks.OO0000O0
    if (%tanks.O000O0OO == 1) did -o %tanks.OOOO000O 5 1 $replace($did(%tanks.OOOO000O,%tanks.O000O0OO,%tanks.OO0000O0),*,?,�,$chr(32))
    else did -o %tanks.OOOO000O 5 1 $did(%tanks.OOOO000O,%tanks.O000O0OO,%tanks.OO0000O0)
    did -o %tanks.OOOO000O 11 1 $replace($did(%tanks.OOOO000O,1,%tanks.OO0000O0),�,$chr(32))
    did -o %tanks.OOOO000O 6 1 $replace($did(%tanks.OOOO000O,1,%tanks.OO0000O0),�,$chr(32)) @ $did(%tanks.OOOO000O,2,%tanks.OO0000O0)
  }
  if (%tanks.O0O0OOO0 == 9) {
    while ($did(%tanks.OOOO000O,8,1).sel) {
      did -dz %tanks.OOOO000O 8 $did(%tanks.OOOO000O,8,1).sel
    }
    %tanks.OOO0OO00 = 1
  }
  if (%tanks.O0O0OOO0 == 7) {
    var %tanks.O00OO0OO = $$deltok($replace($did(%tanks.OOOO000O,11),$chr(32),�),0,160) $iif($did(%tanks.OOOO000O,3).state,����Match�Name:�,����Match�IP:�) $$deltok($replace($did(%tanks.OOOO000O,5),$chr(32),�),0,160) � ( $+ $did(%tanks.OOOO000O,6) $+ )
    var %tanks.O0O0OO0O = $did(%tanks.OOOO000O,8).lines
    while (%tanks.O0O0OO0O) {
      if ($did(%tanks.OOOO000O,8,%tanks.O0O0OO0O) == %tanks.O00OO0OO) return
      dec %tanks.O0O0OO0O
    }
    did -az %tanks.OOOO000O 8 %tanks.O00OO0OO
    %tanks.OOO0OO00 = 1
  }
  if (%tanks.OOO0OO00) {
    close -@ @tanksO00000O0
    window -hl @tanksO00000O0
    %tanks.OOO0OO00 = $did(%tanks.OOOO000O,8).lines
    while (%tanks.OOO0OO00) {
      aline @tanksO00000O0 $did(%tanks.OOOO000O,8,%tanks.OOO0OO00)
      dec %tanks.OOO0OO00
    }
    savebuf @tanksO00000O0 " $+ $scriptdir $+ tanks.ign"
    OOO0O00O
    if (%tanks.O00O0OOO [ $+ [ %tanks.O00O0O0O ] ] isnum) && ($sock(tanks)) {
      O0OO0O00
      drawdot @Tanks
    }
  }
}
menu @Downloading�Tanks {
  sclick:O000OO0O $calc($mouse.dx -$window($O00OO0O0).x) $calc($mouse.dy -$window($O00OO0O0).y)
  &Cancel:{
    close -@ $O00OO0O0
    sockclose downloadtanks
  }
}
alias -l OO0OO0OO O00OOO0O @Tanks $iif(%tanksnoxy || * * !iswm %tanksxy,-1 -1,%tanksxy) %tankswidth %tanksheight Fixedsys 15
alias -l O00O00OO {
  if ($1 == 3) OOOO0000 Tanks $3- error (server not found)
  else OOOO0000 Tanks $3- error $1 $sock($2).wsmsg
  sockclose $2
}
alias -l O0OO0OOO {
  if (* !iswm $window(@Tanks)) return
  var %tanks.O0OO000O, %tanks.OO0O0OOO = %tanks.OO00OOO0, %tanks.OOO00O0O = 0, %tanks.OOO0OO00 = 0
  while (%tanks.OO0O0OOO) {
    if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) {
      if (%tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] == 5) %tanks.OOO0OO00 = 1
      inc %tanks.OOO00O0O
      if ($len(%tanks.O0OO000O) < 800) {
        var %tanks.O0O0OO0O = $sock(tanks. [ $+ [ %tanks.OO0O0OOO ] ] ).ip
        %tanks.O0OO000O = � $iif(%tanks.O0O0OO0O,%tanks.O0O0OO0O,%tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] ) $replace(%tanks.O0OO0OO0 [ $+ [ %tanks.OO0O0OOO ] ] ,%,$right(.%25,3),+,$right(.%2B,3),$chr(35),$right(.%23,3),&,$right(.%26,3)) %tanks.O0OO000O
      }
    }
    dec %tanks.OO0O0OOO
  }
  %tanks.O0OO000O = %tanks.O0OO0OO00 %tanksport %tanks.OOO0OO00 %tanks.OOO00O0O %tanksplayerlimit %tanks.OO000O0O %tanks.OOO0OOO0 %tanks.O000000O %tanks.O0000OO0 %tanks.O0OO000O
  OO0OOOOO action=add&game= $+ $replace(%tanks.O0OO000O,$chr(32),$right(.%20,3))
  if ($sock(tanks.0)) .timertanks.O0OO0OOO -o 1 285 O0OO0OOO
}
alias tanksd {
  .timer_tanksd -o 1 0 return
  tanks $calc(+$1)
}
menu @Tank�info {
  sclick:close -@ @Tank�info
}
alias -l OOO0OO00 {
  %tanks.OO000000 = O000000O
  OO0000OO 0
  OO00OOOO h1
  unset %tanks.OO000000
  O0OOOO00
}
on *:socklisten:tanks.0:{
  var %tanks.O0O0OOO0 = 1, %tanks.OOO0OO00, %tanks.O0OO000O
  if ($sockerr) {
    O00O00OO $ifmatch tanks.0 socket listening
    return
  }
  while (1) {
    %tanks.OOO0OO00 = tanks. $+ %tanks.O0O0OOO0
    if ($sock(%tanks.OOO0OO00)) || (%tanks.O00O0OOO [ $+ [ %tanks.O0O0OOO0 ] ] isnum) inc %tanks.O0O0OOO0
    else break
  }
  sockaccept %tanks.OOO0OO00
  var %tanks.O0O0OO0O = $sock(%tanks.OOO0OO00).ip, %tanks.OO0000OO = tanksconnect $+ %tanks.O0O0OO0O
  if (%tanks.O0O0OOO0 > %tanksplayerlimit) %tanks.O0OO000O = O00OO000
  elseif (%tanksallowclones) && ($timer(%tanks.OO0000OO)) && (%tanks.O0O0OO0O) %tanks.O0OO000O = O0000000
  else .timer $+ %tanks.OO0000OO -o 1 10 return
  if ($OOOO000O(0,%tanks.O0O0OO0O)) %tanks.O0OO000O = O000000O
  else {
    var %tanks.OO0O0OOO = %tanks.OO00OOO0
    while (%tanks.OO0O0OOO) && (%tanksallowclones != 1) {
      if (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) && (%tanks.O0O0OO0O == $sock(tanks. [ $+ [ %tanks.OO0O0OOO ] ] ).ip) {
        %tanks.O0OO000O = O00O00OO
        break
      }
      dec %tanks.OO0O0OOO
    }
  }
  if (%tanks.O0OO000O) OO000O00 %tanks.OOO0OO00 ver $tanksversion(1) %tanks.O0OO000O
  else .timertanks.OO0O0OOO $+ %tanks.O0O0OOO0 -o 1 15 OO0O0OOO 1 %tanks.O0O0OOO0 %tanks.OOO0OO00 %tanks.O0O0OO0O
}
alias -l OOO0O0O0 {
  if (%tanks.O00O0O00 [ $+ [ %tanks.OO000OO0 ] ] isnum 0-4) {
    %tanks.OOO0O0OO [ $+ [ %tanks.OO000OO0 ] ] = $1 - %tanks.O0000O00 [ $+ [ %tanks.OO000OO0 ] ]
    %tanks.OO00O000 [ $+ [ %tanks.OO000OO0 ] ] = $2 - %tanks.OOO0O00O [ $+ [ %tanks.OO000OO0 ] ]
  }
  var %tanks.O0OO000O, %tanks.OO0O0OOO = %tanks.O00000O0 [ $+ [ %tanks.OO000OO0 ] ]
  if (%tanks.OO00O0O0 == 1) {
    if (%tanks.O0O0O00O) && (%tanks.OO0O0OOO > 90) %tanks.O0OO000O = 5 4 4 3 1
    elseif (%tanks.O0O0O00O) && (%tanks.OO0O0OOO > 80) %tanks.O0OO000O = 6 5 5 4 3 1
    else %tanks.O0OO000O = 7 7 6 6 5 4 2
  }
  elseif (%tanks.OO00O0O0 == 2) {
    if (%tanks.O0O0O00O) && (%tanks.OO0O0OOO > 90) %tanks.O0OO000O = 8 8 7 7 6 5 4 2
    elseif (%tanks.O0O0O00O) && (%tanks.OO0O0OOO > 80) %tanks.O0OO000O = 10 10 9 9 8 8 7 6 4 2
    else %tanks.O0OO000O = 12 12 12 11 11 10 10 9 8 7 5 3
  }
  elseif (%tanks.OO00O0O0 == 3) {
    if (%tanks.O0O0O00O) && (%tanks.OO0O0OOO > 90) %tanks.O0OO000O = 13 13 13 12 12 11 11 10 9 8 7 5 3
    elseif (%tanks.O0O0O00O) && (%tanks.OO0O0OOO > 80) %tanks.O0OO000O = 15 15 15 14 14 13 13 12 12 11 10 9 7 5 3
    else %tanks.O0OO000O = 17 17 17 17 16 16 15 15 14 14 13 12 11 10 8 6 4
  }
  elseif (%tanks.OO00O0O0 == 4) {
    if (%tanks.O0O0O00O) && (%tanks.OO0O0OOO > 90) %tanks.O0OO000O = 18 18 18 17 17 17 16 16 15 15 14 13 12 11 10 8 6 3
    elseif (%tanks.O0O0O00O) && (%tanks.OO0O0OOO > 80) %tanks.O0OO000O = 20 20 20 20 19 19 19 18 18 17 16 16 15 14 13 12 10 9 7 4
    else %tanks.O0OO000O = 22 22 22 22 21 21 21 20 20 20 19 18 18 17 16 15 14 13 11 10 7 4
  }
  else {
    if (%tanks.O0O0O00O) && (%tanks.OO0O0OOO > 90) %tanks.O0OO000O = 23 23 23 23 22 22 22 21 21 20 20 19 18 18 17 16 15 14 12 11 9 7 4
    elseif (%tanks.O0O0O00O) && (%tanks.OO0O0OOO > 80) %tanks.O0OO000O = 25 25 25 25 25 24 24 24 23 23 22 22 21 20 19 19 18 17 16 14 13 12 10 8 5
    else %tanks.O0OO000O = 27 27 27 27 27 26 26 26 25 25 25 24 24 23 22 22 21 20 19 18 17 16 14 13 11 8 5
  }
  var %tanks.O0O0OO0O = 1- $+ %tankswidth, %tanks.O0000OOO = $numtok(%tanks.O0OO000O,32), %tanks.OO0000O0, %tanks.O0O000OO, %tanks.O0OO00OO, %tanks.OO0O00OO, %tanks.OO0O000O = %tanks.O0OO0O0O - 1
  while (%tanks.O0000OOO) {
    %tanks.O0OO00OO = $gettok(%tanks.O0OO000O,%tanks.O0000OOO,32)
    %tanks.O0O000OO = $1 + %tanks.O0000OOO
    if (%tanks.O0O000OO isnum %tanks.O0O0OO0O) {
      %tanks.OO0000O0 = $line(@tanksO0000O0O,%tanks.O0O000OO)
      %tanks.OO0O00OO = $2 + %tanks.O0OO00OO
      if (%tanks.OO0000O0 < $calc($2 -%tanks.O0OO00OO)) {
        if (%tanks.OO0O00OO >= %tanks.OO0O000O) %tanks.OO0000O0 = $calc(%tanks.OO0O000O +%tanks.OO0000O0 +%tanks.O0OO00OO -$2)
        else %tanks.OO0000O0 = $calc(%tanks.OO0000O0 +1+2*%tanks.O0OO00OO)
      }
      elseif (%tanks.OO0000O0 <= %tanks.OO0O00OO) %tanks.OO0000O0 = 1 + %tanks.OO0O00OO
      if (%tanks.OO0000O0 > %tanks.OO0O000O) OOO00O00 %tanks.O0O000OO %tanks.OO0O000O
      else OOO00O00 %tanks.O0O000OO %tanks.OO0000O0
    }
    %tanks.O0O000OO = $1 - %tanks.O0000OOO
    if (%tanks.O0O000OO isnum %tanks.O0O0OO0O) {
      %tanks.OO0000O0 = $line(@tanksO0000O0O,%tanks.O0O000OO)
      %tanks.OO0O00OO = $2 + %tanks.O0OO00OO
      if (%tanks.OO0000O0 < $calc($2 -%tanks.O0OO00OO)) {
        if (%tanks.OO0O00OO >= %tanks.OO0O000O) %tanks.OO0000O0 = $calc(%tanks.OO0O000O +%tanks.OO0000O0 +%tanks.O0OO00OO -$2)
        else %tanks.OO0000O0 = $calc(%tanks.OO0000O0 +1+2*%tanks.O0OO00OO)
      }
      elseif (%tanks.OO0000O0 <= %tanks.OO0O00OO) %tanks.OO0000O0 = 1 + %tanks.OO0O00OO
      if (%tanks.OO0000O0 > %tanks.OO0O000O) OOO00O00 %tanks.O0O000OO %tanks.OO0O000O
      else OOO00O00 %tanks.O0O000OO %tanks.OO0000O0
    }
    dec %tanks.O0000OOO
  }
  if ($1 isnum %tanks.O0O0OO0O) {
    %tanks.OO0000O0 = $line(@tanksO0000O0O,$1)
    %tanks.OO0O00OO = $2 + %tanks.O0OO00OO
    if (%tanks.OO0000O0 < $calc($2 -%tanks.O0OO00OO)) {
      if (%tanks.OO0O00OO >= %tanks.OO0O000O) %tanks.OO0000O0 = $calc(%tanks.OO0O000O +%tanks.OO0000O0 +%tanks.O0OO00OO -$2)
      else %tanks.OO0000O0 = $calc(%tanks.OO0000O0 +1+2*%tanks.O0OO00OO)
    }
    elseif (%tanks.OO0000O0 <= %tanks.OO0O00OO) %tanks.OO0000O0 = 1 + %tanks.OO0O00OO
    if (%tanks.OO0000O0 > %tanks.OO0O000O) OOO00O00 $1 %tanks.OO0O000O
    else OOO00O00 $1 %tanks.OO0000O0
  }
  drawline -rn @Tanks %tanks.1 1 0 %tanks.O0OO0O0O %tankswidth %tanks.O0OO0O0O
}
alias tanks {
  if (* !iswm $window(@Tanks)) O00000OO
  else {
    window -a @Tanks
    if (* !iswm $1) return
  }
  $O00OOO00
  tokenize 32 $replace($1-,:,$chr(32))
  if (. isin $1) || ($1 isnum) && ($1 !ischan) && ($2 isnum 1-) {
    if ($1 isnum) tokenize 32 $longip($1) $2
    %tanksip = $1
    %tanksport = $2
    O00000OO
    sockopen tanks %tanksip %tanksport
    OOOO0000 Tanks: Connecting to %tanksip $+ : $+ %tanksport . . .
    return
  }
  if ($sock(tanks.*,0)) && ($1 isnum 1-65534) OO0OOO0O /port $1
  var %tanks.O0O00OOO = $1, %tanks.OO0O0OOO = 1
  if ($1 == $me) tokenize 32 $2-
  elseif ($1 !isnum) && (. !isin $1) && ($1) {
    if (* !iswm $server) || (* !iswm $ip) {
      OOOO0000 Tanks: You are not connected to IRC.
      return
    }
    %tankstempnick = $1
    OOO0OOO0 request $tanksversion(1) %tanksip %tanksport
    OOOO0000 Tanks invitation sent to $1 $+ .
    %tanks.OO0O0OOO = 0
    tokenize 32 $2-
  }
  if ($sock(tanks.*,0)) || ($sock(tanks)) return
  O00000OO
  $O0O0OO00
  tankscheck
  %tanks.O00O0O0O = 0
  %tanks.O0OO0OO00 = %tanksserver
  O000O0O0 0 %tankscolor
  if (* !iswm $timer(_tanksd)) {
    %tanks.O00O0O0O = 1
    O000O0O0 1 %tankscolor
    %tanks.O00O0O001 = 5
    %tanks.O0OO0OO01 = $O0OOOO0O(%tanksname,1)
    O0000O00 1 $O0000O00
  }
  if (* !iswm %tanks.O0O00OOO) {
    O00OO00O %tanksskill
    %tankspublic = 0
  }
  else %tankspublic = %tanks.OO0O0OOO
  OO0OO0OO
  OO0000OO
  sockclose tanks.0
  %tanksip = $ip
  if (%tankssavedport !isnum 1-65534) %tankssavedport = $rand(3000,60000)
  if ($1 isnum 1-65534) %tankssavedport = $1
  %tanksport = %tankssavedport
  O00O0O00 0 1
  O0O00OO0
}
dialog abouttanks {
  title "Tanks"
  option dbu
  size -1 -1 72 77
  button "&Check for a new version"3,2 49 68 12
  button "Install &newest version"4,2 63 68 12
  edit ""1,2 2 68 17,centereadmulti
  button "&Website"99,2 21 33 12
  button "&Readme"97,37 21 33 12
  button ""98,0 0 0 0,okcancelhidden
  edit ""2,2 35 68 12,centeread
}
alias -l O000O0O0 {
  if (, isin $2) var %tanks.OO0O0O0O = $getdot(@tanksO00000OO, [ $2 ] )
  else var %tanks.OO0O0O0O = %tanks. [ $+ [ $2 ] ]
  %tanks.O00OO000 [ $+ [ $1 ] ] = $2
  if (%tanks.O00O0OOO [ $+ [ $1 ] ] == %tanks.OO0O0O0O) return return
  %tanks.O00O0OOO [ $+ [ $1 ] ] = %tanks.OO0O0O0O
}
alias -l OO0O00O0 .timertanks $+ $rand(0,999999) $+ $ticks -o 1 0 $1-
alias -l O000O000 {
  if ($mouse.key & 2) || ($mouse.key & 4) && ($istok(O0000O0O O00000O0 O00000OO O000O00O,$1,32)) return $1 $iif(%tanksinc == 1,5,1)
  return $1 %tanksinc
}
alias -l OO000O0O {
  %tanks.O000O00O = $1
  if ($version != 6.02) window -h @tanksO0000OO0
  var %tanks.O0OO000O, %tanks.OO0000OO = 1, %tanks.OOO00O0O = $numtok(%tanks.O0O00O0O,32), %tanks.O00O00OO = $calc(94+8*%tanks.O0000000), %tanks.O0OOO0O0 = $calc(20+8*%tanks.O00OOOO0)
  close -@ @Tanks�color
  window -Bhdofpk +Ltf @Tanks�color $int($calc($window(@Tanks).x +(%tankswidth -%tanks.O00O00OO)/2)) $int($calc($window(@Tanks).y +(%tanksheight -%tanks.O0OOO0O0)/2)) %tanks.O00O00OO %tanks.O0OOO0O0
  drawrect -rfn @Tanks�color %tanks.15 1 0 0 %tanks.O00O00OO %tanks.O0OOO0O0
  tokenize 32 %tanks.O0000000 %tanks.O00OOOO0
  if ($version < 6.02) tokenize 32 $calc($1 -1) $calc($2 -1)
  drawcopy -nt @tanksO00000OO 16711935 0 0 $1-2 @Tanks�color 10 10 $calc(8*%tanks.O0000000 -1) $calc(8*%tanks.O00OOOO0 -1)
  var %tanks.O0O0OOO0 = $calc(20+8*%tanks.O0000000), %tanks.O0O00000 = $calc(8*%tanks.O00OOOO0 -54)
  drawtext -rn @Tanks�color 0 Fixedsys 15 %tanks.O0O0OOO0 10 Selected
  drawrect -r @Tanks�color %tanks.14 1 %tanks.O0O0OOO0 %tanks.O0O00000 64 64
  drawdot @Tanks�color
  window -a @Tanks�color
}
alias abouttanks {
  if ($dialog(abouttanks)) {
    dialog -e abouttanks
    return
  }
  dialog $iif(%tanksontop,-dmo,-dm) abouttanks abouttanks
}
menu @Tanks�IP�addresses {
  &Refresh:O0000O0O
}
alias -l OO00O0O0 {
  if ($window(@Tanks)) && (* iswm %tanks.O0OOOOO0) && (* iswm %tanks.O00OOO00) {
    drawfill -nrs @Tanks %tanks.O0OOOOO0 %tanks.O00OOO00 0 0
    drawfill -nrs @Tanks %tanks.O00OOO00 %tanks.O0OOOOO0 0 0
    drawfill -nrs @Tanks %tanks.O0OOOOO0 %tanks.O00OOO00 0 0
    drawfill -nrs @Tanks %tanks.O00OOO00 %tanks.O0OOOOO0 0 0
    if (%tanks.OO000000 isin O000000O O00000OO O0000000) OO00OO00
  }
}
alias -l O00O0OO0 {
  var %tanks.OO0O0OOO = 1
  while (1) {
    var %tanks.OOO0OO00 = tanks. $+ %tanks.OO0O0OOO
    if ($sock(%tanks.OOO0OO00)) || (%tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] isnum) inc %tanks.OO0O0OOO
    else break
  }
  if (%tanks.OO0O0OOO > %tanks.OO00OOO0) return 1
  %tanks.O00O0O00 [ $+ [ %tanks.OO0O0OOO ] ] = 5
  if (%tanks.O00O0O0O == 0) %tanks.O00O0O0O = %tanks.OO0O0OOO
  O0OOO0O0 0 5 %tanks.OO0O0OOO $O0O00O0O(%tankscolor) $O0OOOO0O($iif($0,$1-,%tanks.O0OO0OO0 [ $+ [ %tanks.O00O0O0O ] ] ),%tanks.OO0O0OOO)
}
alias -l O000OO0O {
  if ($window($O00OO0O0)) {
    window $O00OO0O0 $calc($mouse.dx -$1) $calc($mouse.dy -$2)
    if ($mouse.key & 1) .timertanks.O00OO0O0 -o 1 0 O000OO0O $1-
  }
}
alias tanksdn %tanksmode = 0 | tanksd $1-
alias -l OO0O0000 {
  var %tanks.O0000OOO = $1 - $3, %tanks.O0OO00OO = $2 - $4, %tanks.O0O0OOO0 = $3, %tanks.O0O00000 = $4, %tanks.OO0000OO = $5, %tanks.OO0O0OOO
  tokenize 32 $gettok(%tanks.OO0O00O0, [ [ $calc(1+%tanks.O0OO0O00) ] $+ ] -,32)
  if (%tanks.O0O00000 < %tanks.O0OO0O0O) {
    tokenize 32 %tanks.OO0O00O0
    var %tanks.O0OO000O = a
    while (%tanks.OOO0O000 [ $+ [ $1 ] ] > 0) {
      if ($calc((%tanks.O0000O00 [ $+ [ $1 ] ] -%tanks.O0O0OOO0)^2+(%tanks.OOO0O00O [ $+ [ $1 ] ] -%tanks.O0O00000)^2) < %tanks.O0OO000O) {
        %tanks.O0OO000O = $ifmatch
        if (%tanks.O0OO000O < 1600) %tanks.OO0O0OOO = $1
      }
      tokenize 32 $2-
    }
  }
  elseif (%tanks.O00O0OOO [ $+ [ $1 ] ] isnum) && (%tanks.OOO0O000 [ $+ [ $1 ] ] > 0) && ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,2,315,158,13)) %tanks.OO0O0OOO = $1
  elseif (%tanks.O00O0OOO [ $+ [ $2 ] ] isnum) && (%tanks.OOO0O000 [ $+ [ $2 ] ] > 0) && ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,160,315,158,13)) %tanks.OO0O0OOO = $2
  elseif (%tanks.O00O0OOO [ $+ [ $3 ] ] isnum) && (%tanks.OOO0O000 [ $+ [ $3 ] ] > 0) && ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,2,328,158,13)) %tanks.OO0O0OOO = $3
  elseif (%tanks.O00O0OOO [ $+ [ $4 ] ] isnum) && (%tanks.OOO0O000 [ $+ [ $4 ] ] > 0) && ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,160,328,158,13)) %tanks.OO0O0OOO = $4
  elseif (%tanks.O00O0OOO [ $+ [ $5 ] ] isnum) && (%tanks.OOO0O000 [ $+ [ $5 ] ] > 0) && ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,2,341,158,13)) %tanks.OO0O0OOO = $5
  elseif (%tanks.O00O0OOO [ $+ [ $6 ] ] isnum) && (%tanks.OOO0O000 [ $+ [ $6 ] ] > 0) && ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,160,341,158,13)) %tanks.OO0O0OOO = $6
  elseif (%tanks.O00O0OOO [ $+ [ $7 ] ] isnum) && (%tanks.OOO0O000 [ $+ [ $7 ] ] > 0) && ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,2,354,158,13)) %tanks.OO0O0OOO = $7
  elseif (%tanks.O00O0OOO [ $+ [ $8 ] ] isnum) && (%tanks.OOO0O000 [ $+ [ $8 ] ] > 0) && ($inrect(%tanks.O0O0OOO0,%tanks.O0O00000,160,354,158,13)) %tanks.OO0O0OOO = $8
  if (%tanks.OO0O0OOO) && (%tanks.OO0000OO == 0) O0OOOOOO %tanks.OO0O0OOO
  if ($window(@Tank�info)) || ($dialog(tanksbots).active) || ($dialog(tanksserver).active) || ($dialog(abouttanks).active) || ($dialog(tankschat).active) || ($dialog(tanklist).active) || ($dialog(tanksban).active) || ($dialog(tanksignore).active) || (%tanks.OO0O0OOO !isnum) && ($version != 6.02) window -h @tanksO0000OO0
  if (%tanks.OO0O0OOO !isnum) || (%tanks.OO0000OO == 0) {
    unset %tanks.O0O0O0OO
    if (%tanks.OO0000OO == 0) close -@ @Tanks�color
    return
  }
  if ($version == 6.02) || (%tanks.OO0O0OOO == %tanks.O0O0O0OO) || ($window(@Tank�info)) return
  %tanks.O0O0O0OO = %tanks.OO0O0OOO
  var %tanks.OOO00O0O = $O0O00OOO(%tanks.OO0O0OOO), %tanks.O00O00OO = $calc(7+$width(%tanks.OOO00O0O,%tankschat.O000O00O,%tankschat.O00000O0,0,0)), %tanks.O0OOO0O0 = $iif(%tanks.OO000O0O & 1,17,23), %tanks.O0O0OOO00 = 3
  if (%tanks.O00O00OO < 37) && (%tanks.O0OOO0O0 > 17) var %tanks.O0O0OOO00 = $int($calc(3 + (37 - %tanks.O00O00OO) / 2)), %tanks.O00O00OO = 37
  var %tanks.O0O0OOO0 = $int($calc(%tanks.O0000OOO + %tanks.O0000O00 [ $+ [ %tanks.OO0O0OOO ] ] - %tanks.O00O00OO / 2)), %tanks.O0O00000 = $calc(%tanks.O0OO00OO + %tanks.OOO0O00O [ $+ [ %tanks.OO0O0OOO ] ] - $iif(%tanks.O0OOO0O0 > 17,41,36))
  if (%tanks.O0O0OOO0 < %tanks.O0000OOO) %tanks.O0O0OOO0 = %tanks.O0000OOO
  if ($calc(%tanks.O0000OOO + %tankswidth - %tanks.O00O00OO) < %tanks.O0O0OOO0) %tanks.O0O0OOO0 = $ifmatch
  window @tanksO0000OO0 -1 -1 %tanks.O00O00OO %tanks.O0OOO0O0
  drawrect -rf @tanksO0000OO0 %tanks.O00OOO00 1 0 0 %tanks.O00O00OO %tanks.O0OOO0O0
  window -o @tanksO0000OO0 %tanks.O0O0OOO0 %tanks.O0O00000 %tanks.O00O00OO %tanks.O0OOO0O0
  drawdot @Tanks
  drawrect -rn @tanksO0000OO0 %tanks.O00O0OOO [ $+ [ %tanks.OO0O0OOO ] ] 1 0 0 %tanks.O00O00OO %tanks.O0OOO0O0
  drawtext -rn @tanksO0000OO0 0 %tankschat.O000OO00 %tankschat.O00000O0 $calc(%tanks.O0O0OOO00 +%tankstahoma) 2 %tanks.OOO00O0O
  if (%tanks.O0OOO0O0 > 17) {
    if (%tanks.O0O0O0OO == %tanks.OO000OO0) {
      var %tanks.OO0000OO = 1
      tokenize 32 %tanks.OO0O00O0
      while (%tanks.OOO0O000 [ $+ [ $1 ] ] > 0) {
        if ($1 != %tanks.OO000OO0) if ($O00OOOO0($1) > %tanks.OO0000OO) %tanks.OO0000OO = $ifmatch
        tokenize 32 $2-
      }
    }
    else var %tanks.OO0000OO = $O00OOOO0
    %tanks.OO0000OO = $iif(%tanks.OOO0O000 [ $+ [ %tanks.OO0O0OOO ] ] > %tanks.OO0000OO,%tanks.0,255)
    var %tanks.O0O0OOO0 = $int($calc(%tanks.O00O00OO /2-15))
    if (%tanks.OOO0O000 [ $+ [ %tanks.O0O0O0OO ] ] == 11) {
      drawrect -rnf @tanksO0000OO0 %tanks.OO0000OO 1 %tanks.O0O0OOO0 16 31 4
      drawrect -rn @tanksO0000OO0 %tanks.1 1 %tanks.O0O0OOO0 16 31 4
    }
    else {
      drawrect -rnf @tanksO0000OO0 %tanks.OO0O0O00 1 %tanks.O0O0OOO0 16 31 4
      drawrect -rnf @tanksO0000OO0 %tanks.OO0000OO 1 %tanks.O0O0OOO0 16 $calc(%tanks.OOO0O000 [ $+ [ %tanks.O0O0O0OO ] ] *3) 4
      drawpic -cnt @tanksO0000OO0 16711935 %tanks.O0O0OOO0 16 120 76 31 4 %tanksbmp
      drawfill -srn @tanksO0000OO0 %tanks.1 16777215 %tanks.O0O0OOO0 16
    }
  }
  drawdot @tanksO0000OO0
}
alias -l O0O00OO0 {
  if ($window(@Tanks)) {
    var %tanks.O0OO000O, %tanks.OO0O0OOO = $iif(%tanks.OO000000 isin O000000O O00000OO O0000000,1)
    if (%tanks.OO0O0OOO) && (%tankstitle & 1) {
      if (%tanks.O000000O == 2) %tanks.O0OO000O = �-� Round %tanks.OO0O0OO0 of %tanks.O0000OO0
      else %tanks.O0OO000O = �-� Round %tanks.OO0O0OO0
    }
    if (%tanks.OO0O0OOO) && (%tankstitle & 2) {
      if (%tanks.O00O0O0O != 0) %tanks.O0OO000O = %tanks.O0OO000O �-� Frags: %tanks.O00O0OO0 [ $+ [ %tanks.O00O0O0O ] ]
      if (%tanks.O000000O == 1) %tanks.O0OO000O = %tanks.O0OO000O �-� Frag limit: %tanks.O0000OO0
    }
    if ($0) %tanks.O0OO000O = �-� $1-
    else {
      if (%tankstitle & 4) && (%tanks.O000O000 [ $+ [ %tanks.O00O0O0O ] ] > 0) && (%tanks.OO0O0OOO) %tanks.O0OO000O = %tanks.O0OO000O �-� Accuracy: $calc(+$round($calc(100 * %tanks.O0OOO000 [ $+ [ %tanks.O00O0O0O ] ] / %tanks.O000O000 [ $+ [ %tanks.O00O0O0O ] ] ),0)) $+ %
      var %tanks.OOO0OO00 = $iif(%tanks.O00O0OOO0 isnum,$O0O00OOO(0),%tanks.O0OO0OO01)
      if ($sock(tanks)) || ($sock(tanks.*,0)) && (%tankstitle & 8) && (* iswm %tanks.OOO0OO00) %tanks.O0OO000O = %tanks.O0OO000O �-� Server: %tanks.OOO0OO00
    }
    titlebar @Tanks $iif(%tanks.OO000O0O & 1,instagib) %tanks.O0OO000O
  }
}
alias -l OO0O0O00 {
  if ($2) && (%tanks.O00O0O00 [ $+ [ $1 ] ] == 5) || ($1 == 0) return $iif($sock(tanks),$sock(tanks).ip)
  if ($2 != 1) {
    if (%tanks.O00O0O00 [ $+ [ $1 ] ] == 5) return (Admin)
    if (%tanks.O00O0O00 [ $+ [ $1 ] ] isnum) return (Bot)
  }
  if ($sock(tanks. [ $+ [ $1 ] ] ).ip) return $ifmatch
  return %tanks.O00OO00O [ $+ [ $1 ] ]
}
alias -l OOO00000 {
  if (%tanks.OO000000 !isin O000000O O00000OO O0000000) return
  drawrect -rfn @Tanks 0 1 172 $calc(1+$1) 25 13
  if ($2 isnum) drawtext -rn @Tanks $iif($4 isnum,$4,$iif($3,10921638,16777215)) Fixedsys 15 $calc(196-$width($2,fixedsys,15,0,0)) $1 $2
}
alias -l OOOO00OO {
  if ($sock(tanks.*,0)) O000O00O O0000O0O
  if (%tanks.OO000000 != O0000O0O) unset %tanks.OO000000
  .timertanks.OOO00O0O off
  .timertanks.OO00000O2 off
  OO0000OO 0
  if (%tanks.O00O0O0O != 0) O0000OOO
}
alias -l O0O00O0O {
  if ($istok(%tanks.O0O00O0O,$1,32)) return $1
  if (, isin $1) {
    var %tanks.O0O00OOO = $1, %tanks.O0OO000O = 1
    tokenize 44 $rgb($getdot(@tanksO00000OO, [ $1 ] ))
    if ($1 > 222) && ($2 < 32) && ($3 > 222) %tanks.O0OO000O = 0
    if ($gettok(%tanks.O0O00OOO,1,44) isnum 0- [ $+ [ $calc(%tanks.O0000000 -1) ] ] ) if ($gettok(%tanks.O0O00OOO,2,44) isnum 0- [ $+ [ $calc(%tanks.O00OOOO0 -1) ] ] ) if (%tanks.O0OO000O) return %tanks.O0O00OOO
  }
  return $gettok(%tanks.O0O00O0O,$rand(1,$numtok(%tanks.O0O00O0O,32)),32)
}
alias -l O000O0OO {
  if ($isfile($remove($O0OO00OO,")) != $true) || ($1 > 20) {
    if ($dialog(abouttanks)) dialog -c abouttanks
    if ($dialog(tanks)) dialog -c tanks
    if ($2 != hidden) .timer -o 1 0 tanks.init
    .reload -rs " $+ $script $+ "
  }
  else .timertanks -om 1 200 O000O0OO $calc(1+$1) $2
}
